#include "engine/graphics/Primitives.h"
#include "engine/graphics/VertexLayout.h"

#include <glm/gtc/constants.hpp>
#include <glm/glm.hpp>

#include <cmath>
#include <cstdint>
#include <algorithm>
#include <vector>


namespace engine {
namespace primitives{
namespace {
// Shared layout for every primitive: position, normal, texcoord.
VertexLayout PNT() { return VertexLayout{ {3}, {3}, {2} }; }
} // anonymous namespace

Mesh Cube() {
    const std::vector<float> v = {
        // front (+Z)
        -0.5f,-0.5f, 0.5f,   0.0f, 0.0f, 1.0f,   0.0f,0.0f,
         0.5f,-0.5f, 0.5f,   0.0f, 0.0f, 1.0f,   1.0f,0.0f,
         0.5f, 0.5f, 0.5f,   0.0f, 0.0f, 1.0f,   1.0f,1.0f,
        -0.5f, 0.5f, 0.5f,   0.0f, 0.0f, 1.0f,   0.0f,1.0f,
        // back (-Z)
         0.5f,-0.5f,-0.5f,   0.0f, 0.0f,-1.0f,   0.0f,0.0f,
        -0.5f,-0.5f,-0.5f,   0.0f, 0.0f,-1.0f,   1.0f,0.0f,
        -0.5f, 0.5f,-0.5f,   0.0f, 0.0f,-1.0f,   1.0f,1.0f,
         0.5f, 0.5f,-0.5f,   0.0f, 0.0f,-1.0f,   0.0f,1.0f,
        // left (-X)
        -0.5f,-0.5f,-0.5f,  -1.0f, 0.0f, 0.0f,   0.0f,0.0f,
        -0.5f,-0.5f, 0.5f,  -1.0f, 0.0f, 0.0f,   1.0f,0.0f,
        -0.5f, 0.5f, 0.5f,  -1.0f, 0.0f, 0.0f,   1.0f,1.0f,
        -0.5f, 0.5f,-0.5f,  -1.0f, 0.0f, 0.0f,   0.0f,1.0f,
        // right (+X)
         0.5f,-0.5f, 0.5f,   1.0f, 0.0f, 0.0f,   0.0f,0.0f,
         0.5f,-0.5f,-0.5f,   1.0f, 0.0f, 0.0f,   1.0f,0.0f,
         0.5f, 0.5f,-0.5f,   1.0f, 0.0f, 0.0f,   1.0f,1.0f,
         0.5f, 0.5f, 0.5f,   1.0f, 0.0f, 0.0f,   0.0f,1.0f,
        // bottom (-Y)
        -0.5f,-0.5f,-0.5f,   0.0f,-1.0f, 0.0f,   0.0f,0.0f,
         0.5f,-0.5f,-0.5f,   0.0f,-1.0f, 0.0f,   1.0f,0.0f,
         0.5f,-0.5f, 0.5f,   0.0f,-1.0f, 0.0f,   1.0f,1.0f,
        -0.5f,-0.5f, 0.5f,   0.0f,-1.0f, 0.0f,   0.0f,1.0f,
        // top (+Y)
        -0.5f, 0.5f, 0.5f,   0.0f, 1.0f, 0.0f,   0.0f,0.0f,
         0.5f, 0.5f, 0.5f,   0.0f, 1.0f, 0.0f,   1.0f,0.0f,
         0.5f, 0.5f,-0.5f,   0.0f, 1.0f, 0.0f,   1.0f,1.0f,
        -0.5f, 0.5f,-0.5f,   0.0f, 1.0f, 0.0f,   0.0f,1.0f,
    };
    std::vector<std::uint32_t> idx;
    idx.reserve(36);
    for (std::uint32_t f = 0; f < 6; ++f) {
        const std::uint32_t o = f * 4;
        idx.insert(idx.end(), { o + 0, o + 1, o + 2, o + 2, o + 3, o + 0 });
    }
    return Mesh(v, idx, PNT());
}

Mesh Quad() {
    const std::vector<float> v = {
        //  position           normal           uv
        -0.5f,-0.5f, 0.0f,   0.0f,0.0f,1.0f,   0.0f,0.0f,
         0.5f,-0.5f, 0.0f,   0.0f,0.0f,1.0f,   1.0f,0.0f,
         0.5f, 0.5f, 0.0f,   0.0f,0.0f,1.0f,   1.0f,1.0f,
        -0.5f, 0.5f, 0.0f,   0.0f,0.0f,1.0f,   0.0f,1.0f,
    };
    const std::vector<std::uint32_t> idx = { 0, 1, 2, 2, 3, 0 };
    return Mesh(v, idx, PNT());
}

Mesh Plane(float size, float uvTiling) {
    const float h = size * 0.5f;
    const float t = uvTiling;
    const std::vector<float> v = {
        //  position          normal           uv
        -h, 0.0f, -h,   0.0f,1.0f,0.0f,   0.0f, 0.0f,
         h, 0.0f, -h,   0.0f,1.0f,0.0f,   t,    0.0f,
         h, 0.0f,  h,   0.0f,1.0f,0.0f,   t,    t,
        -h, 0.0f,  h,   0.0f,1.0f,0.0f,   0.0f, t,
    };
    const std::vector<std::uint32_t> idx = { 0, 2, 1, 0, 3, 2 };
    Mesh mesh(v, idx, PNT());
    mesh.SetTwoSided(true);   // a flat plane is visible from both sides (no backface cull)
    return mesh;
}

Mesh Cone(int segments)
{
        if (segments < 3) segments = 3;
    const float R = 0.5f;
    const float H = 1.0f;
    const float PI = glm::pi<float>();

    std::vector<float> v;
    std::vector<std::uint32_t> idx;
    v.reserve(static_cast<std::size_t>(segments * 2 + 2) * 8);

    const std::uint32_t tip = 0;
    v.insert(v.end(), {
        0.0f, H * 0.5f, 0.0f,
        0.0f, 1.0f, 0.0f,
        0.5f, 1.0f
    });

    const std::uint32_t baseCenter = 1;
    v.insert(v.end(), {
        0.0f, -H * 0.5f, 0.0f,
        0.0f, -1.0f, 0.0f,
        0.5f, 0.5f
    });

    const std::uint32_t sideStart = 2;
    for (int i = 0; i < segments; ++i) {
        const float t = (static_cast<float>(i) / static_cast<float>(segments)) * 2.0f * PI;
        const float x = std::cos(t) * R;
        const float z = std::sin(t) * R;
        const glm::vec3 normal = glm::normalize(glm::vec3(x, R, z));
        v.insert(v.end(), {
            x, -H * 0.5f, z,
            normal.x, normal.y, normal.z,
            static_cast<float>(i) / static_cast<float>(segments), 0.0f
        });
    }

    const std::uint32_t capStart = sideStart + static_cast<std::uint32_t>(segments);
    for (int i = 0; i < segments; ++i) {
        const float t = (static_cast<float>(i) / static_cast<float>(segments)) * 2.0f * PI;
        const float x = std::cos(t) * R;
        const float z = std::sin(t) * R;
        v.insert(v.end(), {
            x, -H * 0.5f, z,
            0.0f, -1.0f, 0.0f,
            x + 0.5f, z + 0.5f
        });
    }

    for (int i = 0; i < segments; ++i) {
        const std::uint32_t sideCurrent = sideStart + static_cast<std::uint32_t>(i);
        const std::uint32_t sideNext = sideStart + static_cast<std::uint32_t>((i + 1) % segments);
        const std::uint32_t capCurrent = capStart + static_cast<std::uint32_t>(i);
        const std::uint32_t capNext = capStart + static_cast<std::uint32_t>((i + 1) % segments);
        idx.insert(idx.end(), {tip, sideNext, sideCurrent});
        idx.insert(idx.end(), {baseCenter, capCurrent, capNext});
    }

    return Mesh(v, idx, PNT());
}
Mesh Cylinder(int segments)
{
        if (segments < 3) segments = 3;
    const float R = 0.5f;
    const float H = 1.0f;
    const float PI = glm::pi<float>();

    std::vector<float> v;
    std::vector<std::uint32_t> idx;
    v.reserve(static_cast<std::size_t>(segments * 4 + 2) * 8);

    const std::uint32_t topCenter = 0;
    v.insert(v.end(), {
        0.0f, H * 0.5f, 0.0f,
        0.0f, 1.0f, 0.0f,
        0.5f, 0.5f
    });

    const std::uint32_t bottomCenter = 1;
    v.insert(v.end(), {
        0.0f, -H * 0.5f, 0.0f,
        0.0f, -1.0f, 0.0f,
        0.5f, 0.5f
    });

    const std::uint32_t sideStart = 2;
    for (int i = 0; i < segments; ++i) {
        const float t = (static_cast<float>(i) / static_cast<float>(segments)) * 2.0f * PI;
        const float x = std::cos(t) * R;
        const float z = std::sin(t) * R;
        const glm::vec3 normal = glm::normalize(glm::vec3(x, 0.0f, z));
        const float u = static_cast<float>(i) / static_cast<float>(segments);
        v.insert(v.end(), {
            x, H * 0.5f, z,
            normal.x, normal.y, normal.z,
            u, 1.0f,
            x, -H * 0.5f, z,
            normal.x, normal.y, normal.z,
            u, 0.0f
        });
    }

    const std::uint32_t topStart = sideStart + static_cast<std::uint32_t>(segments * 2);
    for (int i = 0; i < segments; ++i) {
        const float t = (static_cast<float>(i) / static_cast<float>(segments)) * 2.0f * PI;
        const float x = std::cos(t) * R;
        const float z = std::sin(t) * R;
        v.insert(v.end(), {
            x, H * 0.5f, z,
            0.0f, 1.0f, 0.0f,
            x + 0.5f, z + 0.5f
        });
    }

    const std::uint32_t bottomStart = topStart + static_cast<std::uint32_t>(segments);
    for (int i = 0; i < segments; ++i) {
        const float t = (static_cast<float>(i) / static_cast<float>(segments)) * 2.0f * PI;
        const float x = std::cos(t) * R;
        const float z = std::sin(t) * R;
        v.insert(v.end(), {
            x, -H * 0.5f, z,
            0.0f, -1.0f, 0.0f,
            x + 0.5f, z + 0.5f
        });
    }

    for (int i = 0; i < segments; ++i) {
        const std::uint32_t currentTop = sideStart + static_cast<std::uint32_t>(i * 2);
        const std::uint32_t currentBottom = currentTop + 1;
        const std::uint32_t nextTop = sideStart + static_cast<std::uint32_t>(((i + 1) % segments) * 2);
        const std::uint32_t nextBottom = nextTop + 1;
        idx.insert(idx.end(), {currentTop, nextBottom, currentBottom, nextBottom, currentTop, nextTop});

        const std::uint32_t capTopCurrent = topStart + static_cast<std::uint32_t>(i);
        const std::uint32_t capTopNext = topStart + static_cast<std::uint32_t>((i + 1) % segments);
        const std::uint32_t capBottomCurrent = bottomStart + static_cast<std::uint32_t>(i);
        const std::uint32_t capBottomNext = bottomStart + static_cast<std::uint32_t>((i + 1) % segments);
        idx.insert(idx.end(), {topCenter, capTopNext, capTopCurrent});
        idx.insert(idx.end(), {bottomCenter, capBottomCurrent, capBottomNext});
    }

    return Mesh(v, idx, PNT());
}
Mesh Sphere(int segments)
{
    if (segments < 3) segments = 3;
    const int    stacks  = segments;        // latitude bands (pole to pole)
    const int    sectors = segments * 2;    // longitude bands (around)
    const float  R       = 0.5f;            // radius -> unit diameter
    const float  PI      = glm::pi<float>();

    std::vector<float> v;
    v.reserve(static_cast<size_t>((stacks + 1) * (sectors + 1) * 8));
    for (int i = 0; i <= stacks; ++i) {
        const float phi = PI * (0.5f - static_cast<float>(i) / stacks); // +pi/2..-pi/2
        const float y   = std::sin(phi);
        const float r   = std::cos(phi);
        for (int j = 0; j <= sectors; ++j) {
            const float theta = 2.0f * PI * static_cast<float>(j) / sectors;
            const float x = r * std::cos(theta);
            const float z = r * std::sin(theta);
            // position (scaled), normal (already unit length), uv
            v.insert(v.end(), {
                x * R, y * R, z * R,
                x, y, z,
                static_cast<float>(j) / sectors, static_cast<float>(i) / stacks,
            });
        }
    }

    std::vector<std::uint32_t> idx;
    const std::uint32_t cols = static_cast<std::uint32_t>(sectors + 1);
    for (int i = 0; i < stacks; ++i) {
        for (int j = 0; j < sectors; ++j) {
            const std::uint32_t k1 = static_cast<std::uint32_t>(i) * cols + static_cast<std::uint32_t>(j);
            const std::uint32_t k2 = k1 + cols;
            // Skip the degenerate triangles at the two poles.
            if (i != 0)             idx.insert(idx.end(), { k1, k1 + 1, k2});
            if (i != stacks - 1)    idx.insert(idx.end(), { k1 + 1, k2 + 1, k2});
        }
    }
    return Mesh(v, idx, PNT());
}

Mesh Capsule(float radius, float height, int segments)
{
    if (segments < 3) segments = 3;
    if (height < 2.0f * radius) height = 2.0f * radius;   // degenerate -> sphere
    const int   sectors   = segments * 2;                 // longitude bands (around)
    const int   capStacks = std::max(segments / 2, 2);    // latitude bands per hemisphere
    const float PI = glm::pi<float>();
    const float cylHalf = height * 0.5f - radius;         // hemisphere-centre offset from origin

    // One vertical strip of rings, top pole -> bottom pole. The two hemispheres'
    // equator rings (normal purely radial, y = +/-cylHalf) double as the cylinder
    // wall's end rings, so connecting them spans the tube with correct side
    // normals -- no separate cylinder geometry needed and the seam is watertight.
    std::vector<float> v;
    std::vector<std::uint32_t> idx;

    // Emit one ring given the vertical normal component `ny`, the ring's world y,
    // and a v texture coordinate. Radial component follows from the unit normal.
    auto emitRing = [&](float ny, float y, float vCoord) {
        const float rr = std::sqrt(std::max(1.0f - ny * ny, 0.0f));   // radial normal magnitude
        for (int j = 0; j <= sectors; ++j) {
            const float theta = 2.0f * PI * static_cast<float>(j) / sectors;
            const float cx = std::cos(theta), cz = std::sin(theta);
            v.insert(v.end(), {
                cx * rr * radius, y, cz * rr * radius,   // position
                cx * rr, ny, cz * rr,                    // unit normal
                static_cast<float>(j) / sectors, vCoord, // uv
            });
        }
    };

    // Top hemisphere: ny from +1 (pole) to 0 (equator at y = +cylHalf).
    for (int i = 0; i <= capStacks; ++i) {
        const float phi = (PI * 0.5f) * (1.0f - static_cast<float>(i) / capStacks);
        const float ny = std::sin(phi);
        emitRing(ny, cylHalf + ny * radius, 0.25f * static_cast<float>(i) / capStacks);
    }
    // Bottom hemisphere: ny from 0 (equator at y = -cylHalf) to -1 (pole). This
    // ring set starts at the tube's bottom; the quad strip joining the last top
    // ring to this first ring IS the cylinder wall.
    for (int i = 0; i <= capStacks; ++i) {
        const float phi = -(PI * 0.5f) * (static_cast<float>(i) / capStacks);
        const float ny = std::sin(phi);
        emitRing(ny, -cylHalf + ny * radius, 0.75f + 0.25f * static_cast<float>(i) / capStacks);
    }

    const std::uint32_t cols = static_cast<std::uint32_t>(sectors + 1);
    const int totalRings = 2 * (capStacks + 1);
    for (int r = 0; r < totalRings - 1; ++r) {
        for (int j = 0; j < sectors; ++j) {
            const std::uint32_t k1 = static_cast<std::uint32_t>(r) * cols + static_cast<std::uint32_t>(j);
            const std::uint32_t k2 = k1 + cols;
            idx.insert(idx.end(), { k1, k1 + 1, k2, k1 + 1, k2 + 1, k2 });
        }
    }
    return Mesh(v, idx, PNT());
}

Mesh Pyramid()
{
    const glm::vec3 apex(0.0f, 0.5f, 0.0f);
    const glm::vec3 corners[] = {
        {-0.5f, -0.5f, -0.5f}, {0.5f, -0.5f, -0.5f},
        {0.5f, -0.5f, 0.5f}, {-0.5f, -0.5f, 0.5f}
    };
    std::vector<float> v;
    std::vector<std::uint32_t> idx;
    auto triangle = [&](const glm::vec3& a, const glm::vec3& b, const glm::vec3& c) {
        const glm::vec3 n = glm::normalize(glm::cross(b - a, c - a));
        const std::uint32_t start = static_cast<std::uint32_t>(v.size() / 8);
        const glm::vec2 uv[] = {{0.0f, 0.0f}, {1.0f, 0.0f}, {0.5f, 1.0f}};
        const glm::vec3 points[] = {a, b, c};
        for (int i = 0; i < 3; ++i) {
            v.insert(v.end(), {points[i].x, points[i].y, points[i].z,
                               n.x, n.y, n.z, uv[i].x, uv[i].y});
        }
        idx.insert(idx.end(), {start, start + 1, start + 2});
    };
    triangle(corners[0], corners[1], corners[2]);
    triangle(corners[0], corners[2], corners[3]);
    triangle(corners[0], apex, corners[1]);
    triangle(corners[1], apex, corners[2]);
    triangle(corners[2], apex, corners[3]);
    triangle(corners[3], apex, corners[0]);
    return Mesh(v, idx, PNT());
}

Mesh Torus(float majorRadius, float minorRadius, int majorSegments, int minorSegments)
{
    majorRadius = std::max(majorRadius, 0.001f);
    minorRadius = std::max(minorRadius, 0.001f);
    majorSegments = std::max(majorSegments, 3);
    minorSegments = std::max(minorSegments, 3);
    const float twoPi = glm::two_pi<float>();
    std::vector<float> v;
    std::vector<std::uint32_t> idx;
    for (int i = 0; i <= majorSegments; ++i) {
        const float u = static_cast<float>(i) / majorSegments;
        const float a = u * twoPi;
        const float ca = std::cos(a), sa = std::sin(a);
        for (int j = 0; j <= minorSegments; ++j) {
            const float t = static_cast<float>(j) / minorSegments;
            const float b = t * twoPi;
            const float cb = std::cos(b), sb = std::sin(b);
            const glm::vec3 normal(ca * cb, sb, sa * cb);
            const float ring = majorRadius + minorRadius * cb;
            v.insert(v.end(), {ring * ca, minorRadius * sb, ring * sa,
                               normal.x, normal.y, normal.z, u, t});
        }
    }
    const std::uint32_t cols = static_cast<std::uint32_t>(minorSegments + 1);
    for (int i = 0; i < majorSegments; ++i) {
        for (int j = 0; j < minorSegments; ++j) {
            const std::uint32_t a = static_cast<std::uint32_t>(i) * cols + static_cast<std::uint32_t>(j);
            const std::uint32_t b = a + cols;
            idx.insert(idx.end(), {a, a + 1, b, a + 1, b + 1, b});
        }
    }
    return Mesh(v, idx, PNT());
}

Mesh Staircase(int steps)
{
    steps = std::max(steps, 1);
    std::vector<float> v;
    std::vector<std::uint32_t> idx;
    auto appendBox = [&](const glm::vec3& minimum, const glm::vec3& maximum) {
        const glm::vec3 center = (minimum + maximum) * 0.5f;
        const glm::vec3 half = (maximum - minimum) * 0.5f;
        const glm::vec3 normals[] = {{0,0,1},{0,0,-1},{-1,0,0},{1,0,0},{0,-1,0},{0,1,0}};
        const glm::vec3 face[6][4] = {
            {{-1,-1,1},{1,-1,1},{1,1,1},{-1,1,1}},
            {{1,-1,-1},{-1,-1,-1},{-1,1,-1},{1,1,-1}},
            {{-1,-1,-1},{-1,-1,1},{-1,1,1},{-1,1,-1}},
            {{1,-1,1},{1,-1,-1},{1,1,-1},{1,1,1}},
            {{-1,-1,-1},{1,-1,-1},{1,-1,1},{-1,-1,1}},
            {{-1,1,1},{1,1,1},{1,1,-1},{-1,1,-1}}
        };
        for (int f = 0; f < 6; ++f) {
            const std::uint32_t start = static_cast<std::uint32_t>(v.size() / 8);
            for (int p = 0; p < 4; ++p) {
                const glm::vec3 pos = center + face[f][p] * half;
                const float u = (p == 1 || p == 2) ? 1.0f : 0.0f;
                const float texV = p >= 2 ? 1.0f : 0.0f;
                v.insert(v.end(), {pos.x, pos.y, pos.z, normals[f].x, normals[f].y,
                                   normals[f].z, u, texV});
            }
            idx.insert(idx.end(), {start, start + 1, start + 2, start + 2, start + 3, start});
        }
    };
    const float depth = 1.0f / steps;
    for (int i = 0; i < steps; ++i) {
        const float z0 = -0.5f + depth * i;
        const float z1 = z0 + depth;
        const float y1 = -0.5f + static_cast<float>(i + 1) / steps;
        appendBox(glm::vec3(-0.5f, -0.5f, z0), glm::vec3(0.5f, y1, z1));
    }
    return Mesh(v, idx, PNT());
}
} // namespace primitives
} // namespace engine
