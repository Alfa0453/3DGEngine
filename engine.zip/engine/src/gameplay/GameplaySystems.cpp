#include "engine/gameplay/GameplaySystems.h"

#include "engine/gameplay/GameplayComponents.h"
#include "engine/ecs/Registry.h"
#include "engine/ecs/Components.h"
#include "engine/animation/AnimatedModel.h"
#include "engine/graphics/SkinnedModel.h"
#include "engine/physics/PhysicsComponents.h"
#include "engine/physics/PhysicsWorld.h"

#include <glm/gtc/matrix_transform.hpp>

#include <algorithm>
#include <cmath>
#include <vector>

namespace engine {

void UpdateHealth(ecs::Registry& reg) {
    auto healthView = reg.view<Health>();
    if (healthView.empty()) return;
    healthView.each([](ecs::Entity, Health& h) {
        h.justDied = false;
        if (h.alive && h.hp <= 0.0f) { h.hp = 0.0f; h.alive = false; h.justDied = true; }
    });
}

namespace {
void UpdateProjectilesImpl(ecs::Registry& reg, float dt,
                           std::vector<ProjectileHit>* hitOutput) {
    thread_local std::vector<ecs::Entity> spentStorage;
    spentStorage.clear();
    std::vector<ecs::Entity>& spent = spentStorage;
    auto projectileView = reg.view<ecs::Transform, Projectile>();
    if (projectileView.empty()) return;
    static const PhysicsWorld collisionQueries;

    projectileView.each([&](ecs::Entity pe, ecs::Transform& pt, Projectile& pr) {
        const glm::vec3 start = pt.position;
        const float step = std::max(pr.speed * dt, 0.0f);
        const glm::vec3 end = start + pr.dir * step;
        pr.traveled += step;

        // Sweep the projectile through the physics scene. This tests the actual
        // target collider instead of measuring distance to its transform origin,
        // prevents tunnelling, respects collision response masks, and lets walls
        // stop a shot before it can damage a character behind them.
        const RaycastHit contact = collisionQueries.SphereCast(
            reg, start, end, std::max(pr.radius, 0.0f), pr.owner,
            ecs::CollisionLayer::All, ecs::CollisionLayer::Projectile, pe);
        if (contact.hit) {
            pt.position = contact.point;
            if (Health* health = reg.TryGet<Health>(contact.entity);
                health && health->alive) {
                health->Damage(pr.damage);
                if (hitOutput) {
                    ProjectileHit hit;
                    hit.projectile = pe;
                    hit.target = contact.entity;
                    hit.point = contact.point;
                    hit.damage = pr.damage;
                    hit.lethal = health->hp <= 0.0f;
                    hitOutput->push_back(hit);
                }
            }
            spent.push_back(pe);
        } else {
            pt.position = end;
        }

        if (!contact.hit && pr.traveled >= pr.range) {
            spent.push_back(pe);
        }
    });

    for (ecs::Entity e : spent) if (reg.Valid(e)) reg.Destroy(e);
}
} // namespace

std::vector<ProjectileHit> UpdateProjectiles(ecs::Registry& reg, float dt) {
    std::vector<ProjectileHit> hits;
    UpdateProjectilesImpl(reg, dt, &hits);
    return hits;
}

void UpdateProjectilesInPlace(ecs::Registry& reg, float dt) {
    UpdateProjectilesImpl(reg, dt, nullptr);
}

void UpdateAttachments(ecs::Registry& reg) {
    auto attachmentView = reg.view<ecs::Transform, Attachment>();
    if (attachmentView.empty()) return;
    attachmentView.each([&](ecs::Entity, ecs::Transform& t, Attachment& a) {
        if (!reg.Valid(a.parent)) return;
        const ecs::Transform* pt = reg.TryGet<ecs::Transform>(a.parent);
        if (!pt) return;

        glm::mat4 parentWorld = pt->Model();
        if (a.boneIndex >= 0) {
            if (const AnimatedModel* pm = reg.TryGet<AnimatedModel>(a.parent)) {
                if (pm->model && a.boneIndex < static_cast<int>(pm->pose.size())) {
                    const glm::mat4 offInv = 
                        glm::inverse(pm->model->GetSkeleton().bones[static_cast<std::size_t>(a.boneIndex)].offset);
                    parentWorld = pt->Model() * pm->pose[static_cast<std::size_t>(a.boneIndex)] * offInv;
                }
            }
        }

        const glm::mat4 w = parentWorld * a.offset;
        // Decompose (rigid + uniform scale) into the child Transform.
        const glm::vec3 T(w[3]);
        const glm::vec3 c0(w[0]), c1(w[1]), c2(w[2]);
        const glm::vec3 S(glm::length(c0), glm::length(c1), glm::length(c2));
        const glm::mat3 R(c0 / std::max(S.x, 1e-8f), c1 / std::max(S.y, 1e-8f), c2 / std::max(S.z, 1e-8f));
        t.position = T;
        t.scale    = S;
        t.rotation = glm::quat_cast(R);
    });
}

} // namespace engine
