#include "engine/assets/MaterialAssetLoader.h"

#include "engine/assets/AssetReference.h"
#include "engine/assets/AssetRegistry.h"

#include <cstdlib>
#include <algorithm>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <sstream>

namespace engine {
namespace {

std::string EscapeJson(const std::string& value) {
    std::string escaped;
    escaped.reserve(value.size());
    for (const char c : value) {
        switch (c) {
        case '\\': escaped += "\\\\"; break;
        case '"': escaped += "\\\""; break;
        case '\n': escaped += "\\n"; break;
        case '\r': escaped += "\\r"; break;
        case '\t': escaped += "\\t"; break;
        default: escaped += c; break;
        }
    }
    return escaped;
}

std::string StoredMapPath(const std::string& materialPath,
                          const std::string& mapPath) {
    if (mapPath.empty()) return {};
    std::error_code ec;
    const std::filesystem::path relative = std::filesystem::relative(
        std::filesystem::path(mapPath),
        std::filesystem::path(materialPath).parent_path(), ec);
    return ec ? std::filesystem::path(mapPath).generic_string()
              : relative.generic_string();
}

std::string ReadTextFile(const std::string& path, std::string* error) {
    std::ifstream in(path);
    if (!in) {
        if (error) {
            *error = "Could not open material file: " + path;
        }
        return {};
    }

    std::ostringstream out;
    out << in.rdbuf();
    return out.str();
}

std::string UnescapeJsonString(std::string value) {
    std::string out;
    out.reserve(value.size());
    for (std::size_t i = 0; i < value.size(); ++i) {
        if (value[i] == '\\' && i + 1 < value.size()) {
            ++i;
            switch (value[i]) {
            case 'n': out.push_back('\n'); break;
            case 'r': out.push_back('\r'); break;
            case 't': out.push_back('\t'); break;
            default: out.push_back(value[i]); break;
            }
        } else {
            out.push_back(value[i]);
        }
    }
    return out;
}

bool FindStringFrom(const std::string& text, const std::string& key, std::size_t start, std::string* value) {
    const std::string marker = "\"" + key + "\"";
    std::size_t pos = text.find(marker, start);
    if (pos == std::string::npos) {
        return false;
    }
    pos = text.find(':', pos + marker.size());
    if (pos == std::string::npos) {
        return false;
    }
    pos = text.find('"', pos + 1);
    if (pos == std::string::npos) {
        return false;
    }

    std::string raw;
    bool escaped = false;
    for (++pos; pos < text.size(); ++pos) {
        const char c = text[pos];
        if (!escaped && c == '"') {
            if (value) {
                *value = UnescapeJsonString(raw);
            }
            return true;
        }
        escaped = !escaped && c == '\\';
        raw.push_back(c);
        if (c != '\\') {
            escaped = false;
        }
    }
    return false;
}

bool FindString(const std::string& text, const std::string& key, std::string* value) {
    return FindStringFrom(text, key, 0, value);
}

bool FindFloat(const std::string& text, const std::string& key, float* value) {
    const std::string marker = "\"" + key + "\"";
    std::size_t pos = text.find(marker);
    if (pos == std::string::npos) {
        return false;
    }
    pos = text.find(':', pos + marker.size());
    if (pos == std::string::npos) {
        return false;
    }

    char* end = nullptr;
    const float parsed = std::strtof(text.c_str() + pos + 1, &end);
    if (end == text.c_str() + pos + 1) {
        return false;
    }
    if (value) {
        *value = parsed;
    }
    return true;
}

bool FindVec3(const std::string& text, const std::string& key, glm::vec3* value) {
    const std::string marker = "\"" + key + "\"";
    std::size_t pos = text.find(marker);
    if (pos == std::string::npos) {
        return false;
    }
    pos = text.find('[', pos + marker.size());
    if (pos == std::string::npos) {
        return false;
    }

    char* end = nullptr;
    const char* start = text.c_str() + pos + 1;
    const float x = std::strtof(start, &end);
    if (end == start) {
        return false;
    }
    const float y = std::strtof(end + 1, &end);
    const float z = std::strtof(end + 1, &end);
    if (value) {
        *value = glm::vec3(x, y, z);
    }
    return true;
}

bool FindVec2(const std::string& text, const std::string& key, glm::vec2* value) {
    const std::string marker = "\"" + key + "\"";
    std::size_t pos = text.find(marker);
    if (pos == std::string::npos || (pos = text.find('[', pos + marker.size())) == std::string::npos) return false;
    char* end = nullptr;
    const char* start = text.c_str() + pos + 1;
    const float x = std::strtof(start, &end); if (end == start) return false;
    start = end + 1; const float y = std::strtof(start, &end); if (end == start) return false;
    if (value) *value = glm::vec2(x, y);
    return true;
}

std::string ResolveMapPath(const std::string& materialPath, const std::string& mapPath) {
    if (mapPath.empty()) {
        return {};
    }

    const std::filesystem::path path(mapPath);
    if (path.is_absolute()) {
        return path.string();
    }
    return (std::filesystem::path(materialPath).parent_path() / path).string();
}

} // namespace

bool SaveMaterialAssetFile(const std::string& path,
                           RuntimeMaterialAsset material,
                           std::string* error) {
    if (!material.id.Valid()) material.id = AssetHandle::Generate();
    const std::filesystem::path destination(path);
    std::error_code ec;
    if (destination.has_parent_path())
        std::filesystem::create_directories(destination.parent_path(), ec);
    if (ec) {
        if (error) *error = "Could not create material directory: " + ec.message();
        return false;
    }
    const std::filesystem::path temporary = destination.string() + ".tmp";
    std::ofstream output(temporary, std::ios::binary | std::ios::trunc);
    if (!output) {
        if (error) *error = "Could not open material for writing: " + path;
        return false;
    }
    const auto& p = material.material;
    const auto idText = [](AssetHandle id) {
        return id.Valid() ? id.ToString()
                          : std::string("00000000000000000000000000000000");
    };
    output << std::fixed << std::setprecision(6);
    output << "3DG_MATERIAL 5 " << material.id.ToString() << '\n'
           << "{\n"
           << "  \"schema\": \"3DGEngine.PbrMaterial\",\n"
           << "  \"version\": 5,\n"
           << "  \"assetId\": \"" << material.id.ToString() << "\",\n"
           << "  \"name\": \"" << EscapeJson(material.name) << "\",\n"
           << "  \"albedo\": [" << p.albedo.r << ", " << p.albedo.g << ", " << p.albedo.b << "],\n"
           << "  \"metallic\": " << p.metallic << ",\n"
           << "  \"roughness\": " << p.roughness << ",\n"
           << "  \"ao\": " << p.ao << ",\n"
           << "  \"emissive\": [" << p.emissive.r << ", " << p.emissive.g << ", " << p.emissive.b << "],\n"
           << "  \"blendMode\": " << static_cast<int>(p.blendMode) << ",\n"
           << "  \"opacity\": " << p.opacity << ",\n"
           << "  \"alphaCutoff\": " << p.alphaCutoff << ",\n"
           << "  \"uvScale\": [" << p.uvScale.x << ", " << p.uvScale.y << "],\n"
           << "  \"uvOffset\": [" << p.uvOffset.x << ", " << p.uvOffset.y << "],\n"
           << "  \"uvRotation\": " << p.uvRotation << ",\n"
           << "  \"worldSpaceUv\": " << (p.worldSpaceUv ? 1 : 0) << ",\n"
           << "  \"normalStrength\": " << p.normalStrength << ",\n"
           << "  \"heightScale\": " << p.heightScale << ",\n"
           << "  \"clearcoat\": " << p.clearcoat << ",\n"
           << "  \"clearcoatRoughness\": " << p.clearcoatRoughness << ",\n"
           << "  \"transmission\": " << p.transmission << ",\n"
           << "  \"ior\": " << p.ior << ",\n"
           << "  \"thickness\": " << p.thickness << ",\n"
           << "  \"anisotropy\": " << p.anisotropy << ",\n"
           << "  \"anisotropyRotation\": " << p.anisotropyRotation << ",\n"
           << "  \"sheenColor\": [" << p.sheenColor.r << ", " << p.sheenColor.g << ", " << p.sheenColor.b << "],\n"
           << "  \"sheenRoughness\": " << p.sheenRoughness << ",\n"
           << "  \"specularLevel\": " << p.specularLevel << ",\n"
           << "  \"subsurface\": " << p.subsurface << ",\n"
           << "  \"subsurfaceColor\": [" << p.subsurfaceColor.r << ", " << p.subsurfaceColor.g << ", " << p.subsurfaceColor.b << "],\n"
           << "  \"shader\": \"" << EscapeJson(material.shaderPath) << "\",\n"
           << "  \"shaderAssetId\": \"" << idText(material.shaderAssetId) << "\",\n"
           << "  \"shaderParameters\": [],\n"
           << "  \"maps\": {\n"
           << "    \"albedo\": \"" << EscapeJson(StoredMapPath(path, material.albedoMapPath)) << "\",\n"
           << "    \"normal\": \"" << EscapeJson(StoredMapPath(path, material.normalMapPath)) << "\",\n"
           << "    \"metalRough\": \"" << EscapeJson(StoredMapPath(path, material.metalRoughMapPath)) << "\",\n"
           << "    \"height\": \"" << EscapeJson(StoredMapPath(path, material.heightMapPath)) << "\",\n"
           << "    \"emissive\": \"" << EscapeJson(StoredMapPath(path, material.emissiveMapPath)) << "\"\n"
           << "  },\n"
           << "  \"mapAssetIds\": {\n"
           << "    \"albedoAssetId\": \"" << idText(material.albedoMapAssetId) << "\",\n"
           << "    \"normalAssetId\": \"" << idText(material.normalMapAssetId) << "\",\n"
           << "    \"metalRoughAssetId\": \"" << idText(material.metalRoughMapAssetId) << "\",\n"
           << "    \"heightAssetId\": \"" << idText(material.heightMapAssetId) << "\",\n"
           << "    \"emissiveAssetId\": \"" << idText(material.emissiveMapAssetId) << "\"\n"
           << "  }\n"
           << "}\n";
    std::vector<AssetHandle> dependencies;
    for (AssetHandle id : {material.albedoMapAssetId, material.normalMapAssetId,
                           material.metalRoughMapAssetId, material.heightMapAssetId,
                           material.emissiveMapAssetId,
                           material.shaderAssetId})
        if (id.Valid() && std::find(dependencies.begin(), dependencies.end(), id)
                              == dependencies.end())
            dependencies.push_back(id);
    output << "ASSET_DEPS " << dependencies.size();
    for (AssetHandle id : dependencies) output << ' ' << id.ToString();
    output << '\n';
    output.close();
    if (!output) {
        std::filesystem::remove(temporary, ec);
        if (error) *error = "Could not finish writing material: " + path;
        return false;
    }
    const std::filesystem::path backup = destination.string() + ".bak";
    std::filesystem::remove(backup, ec);
    ec.clear();
    if (std::filesystem::exists(destination, ec)) {
        std::filesystem::rename(destination, backup, ec);
        if (ec) {
            std::filesystem::remove(temporary);
            if (error) *error = "Could not replace material: " + ec.message();
            return false;
        }
    }
    std::filesystem::rename(temporary, destination, ec);
    if (ec) {
        std::error_code rollback;
        if (std::filesystem::exists(backup, rollback))
            std::filesystem::rename(backup, destination, rollback);
        if (error) *error = "Could not commit material: " + ec.message();
        return false;
    }
    std::filesystem::remove(backup, ec);
    if (error) error->clear();
    return true;
}

bool LoadMaterialAssetFile(const std::string& path, RuntimeMaterialAsset* material, std::string* error) {
    if (!material) {
        if (error) {
            *error = "Material output pointer was null.";
        }
        return false;
    }

    const std::string text = ReadTextFile(path, error);
    if (text.empty()) {
        return false;
    }

    RuntimeMaterialAsset loaded;
    std::string idText;
    if (FindString(text, "assetId", &idText))
        AssetHandle::Parse(idText, &loaded.id);
    if (!loaded.id.Valid()) {
        std::istringstream header(text);
        std::string magic;
        int version = 0;
        if (header >> magic >> version >> idText && magic == "3DG_MATERIAL")
            AssetHandle::Parse(idText, &loaded.id);
    }
    std::string schema;
    if (!FindString(text, "schema", &schema) || schema != "3DGEngine.PbrMaterial") {
        if (error) {
            *error = "Material file has an unknown schema.";
        }
        return false;
    }

    FindString(text, "name", &loaded.name);
    FindVec3(text, "albedo", &loaded.material.albedo);
    FindFloat(text, "metallic", &loaded.material.metallic);
    FindFloat(text, "roughness", &loaded.material.roughness);
    FindFloat(text, "ao", &loaded.material.ao);
    FindVec3(text, "emissive", &loaded.material.emissive);
    float blendMode = 0.0f;
    if (FindFloat(text, "blendMode", &blendMode))
        loaded.material.blendMode = static_cast<ecs::PbrMaterial::BlendMode>(static_cast<int>(blendMode));
    FindFloat(text, "opacity", &loaded.material.opacity);
    FindFloat(text, "alphaCutoff", &loaded.material.alphaCutoff);
    FindVec2(text, "uvScale", &loaded.material.uvScale);
    FindVec2(text, "uvOffset", &loaded.material.uvOffset);
    FindFloat(text, "uvRotation", &loaded.material.uvRotation);
    float worldSpaceUv = 0.0f;
    if (FindFloat(text, "worldSpaceUv", &worldSpaceUv))
        loaded.material.worldSpaceUv = worldSpaceUv > 0.5f;
    FindFloat(text, "normalStrength", &loaded.material.normalStrength);
    FindFloat(text, "heightScale", &loaded.material.heightScale);
    FindFloat(text, "clearcoat", &loaded.material.clearcoat);
    FindFloat(text, "clearcoatRoughness", &loaded.material.clearcoatRoughness);
    FindFloat(text, "transmission", &loaded.material.transmission);
    FindFloat(text, "ior", &loaded.material.ior);
    FindFloat(text, "thickness", &loaded.material.thickness);
    FindFloat(text, "anisotropy", &loaded.material.anisotropy);
    FindFloat(text, "anisotropyRotation", &loaded.material.anisotropyRotation);
    FindVec3(text, "sheenColor", &loaded.material.sheenColor);
    FindFloat(text, "sheenRoughness", &loaded.material.sheenRoughness);
    FindFloat(text, "specularLevel", &loaded.material.specularLevel);
    FindFloat(text, "subsurface", &loaded.material.subsurface);
    FindVec3(text, "subsurfaceColor", &loaded.material.subsurfaceColor);

    std::string albedoMap;
    std::string normalMap;
    std::string metalRoughMap;
    std::string heightMap;
    std::string emissiveMap;
    const std::size_t mapsStart = text.find("\"maps\"");
    if (mapsStart != std::string::npos) {
        FindStringFrom(text, "albedo", mapsStart, &albedoMap);
        FindStringFrom(text, "normal", mapsStart, &normalMap);
        FindStringFrom(text, "metalRough", mapsStart, &metalRoughMap);
        FindStringFrom(text, "height", mapsStart, &heightMap);
        FindStringFrom(text, "emissive", mapsStart, &emissiveMap);
    }
    loaded.albedoMapPath = ResolveMapPath(path, albedoMap);
    loaded.normalMapPath = ResolveMapPath(path, normalMap);
    loaded.metalRoughMapPath = ResolveMapPath(path, metalRoughMap);
    loaded.heightMapPath = ResolveMapPath(path, heightMap);
    loaded.emissiveMapPath = ResolveMapPath(path, emissiveMap);
    if (FindString(text, "albedoAssetId", &idText))
        AssetHandle::Parse(idText, &loaded.albedoMapAssetId);
    if (FindString(text, "normalAssetId", &idText))
        AssetHandle::Parse(idText, &loaded.normalMapAssetId);
    if (FindString(text, "metalRoughAssetId", &idText))
        AssetHandle::Parse(idText, &loaded.metalRoughMapAssetId);
    if (FindString(text, "heightAssetId", &idText))
        AssetHandle::Parse(idText, &loaded.heightMapAssetId);
    if (FindString(text, "emissiveAssetId", &idText))
        AssetHandle::Parse(idText, &loaded.emissiveMapAssetId);
    std::string shaderPath;
    if (FindString(text, "shader", &shaderPath))
        loaded.shaderPath = ResolveMapPath(path, shaderPath);
    if (FindString(text, "shaderAssetId", &idText))
        AssetHandle::Parse(idText, &loaded.shaderAssetId);
    std::size_t parameterCursor = 0;
    while ((parameterCursor = text.find("\"parameterName\"", parameterCursor))
           != std::string::npos) {
        RuntimeShaderParameter parameter;
        if (!FindStringFrom(text, "parameterName", parameterCursor, &parameter.name)
            || !FindStringFrom(text, "parameterValue", parameterCursor, &parameter.value)) break;
        const std::size_t typeKey = text.find("\"parameterType\"", parameterCursor);
        const std::size_t colon = typeKey == std::string::npos
            ? std::string::npos : text.find(':', typeKey);
        if (colon == std::string::npos) break;
        parameter.type = static_cast<int>(
            std::strtol(text.c_str() + colon + 1, nullptr, 10));
        std::string parameterId;
        if (FindStringFrom(
                text, "parameterAssetId", parameterCursor, &parameterId))
            AssetHandle::Parse(parameterId, &parameter.assetId);
        if (parameter.type == 7)
            parameter.value = ResolveMapPath(path, parameter.value);
        loaded.shaderParameters.push_back(std::move(parameter));
        parameterCursor = colon + 1;
    }

    const std::string contentRoot = FindContentRootForAsset(path);
    AssetRegistry registry;
    std::string registryError;
    if (!contentRoot.empty()
        && registry.Load(
            AssetRegistry::DefaultRegistryPath(contentRoot), &registryError)) {
        auto resolve = [&](AssetHandle id, std::string& fallback,
                           AssetType type) {
            if (!id.Valid()) return;
            const std::string resolved = ResolveAssetReference(
                &registry, contentRoot, {id, fallback}, type);
            if (!resolved.empty()) fallback = resolved;
        };
        resolve(loaded.albedoMapAssetId, loaded.albedoMapPath,
                AssetType::Texture);
        resolve(loaded.normalMapAssetId, loaded.normalMapPath,
                AssetType::Texture);
        resolve(loaded.metalRoughMapAssetId, loaded.metalRoughMapPath,
                AssetType::Texture);
        resolve(loaded.heightMapAssetId, loaded.heightMapPath,
                AssetType::Texture);
        resolve(loaded.emissiveMapAssetId, loaded.emissiveMapPath,
                AssetType::Texture);
        resolve(loaded.shaderAssetId, loaded.shaderPath, AssetType::Shader);
        for (RuntimeShaderParameter& parameter : loaded.shaderParameters) {
            if (parameter.type == 7)
                resolve(parameter.assetId, parameter.value, AssetType::Texture);
        }
    }

    *material = loaded;
    if (error) {
        error->clear();
    }
    return true;
}

} // namespace engine
