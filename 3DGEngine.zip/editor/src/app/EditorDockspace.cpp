#include "EditorDockspace.h"
#include "EditorScriptTools.h"
#include "EditorGeneratedScriptTools.h"
#include "EditorAssetIcons.h"
#include "EditorIcons.h"
#include "NativeDialog.h"
#include "ParticlePresets.h"
#include "ParticleAsset.h"

#include <engine/ecs/Components.h>
#include <engine/audio/AudioEditing.h>
#include <engine/graphics/Camera.h>
#include <engine/graphics/SkinnedModel.h>
#include <engine/graphics/ImageDecode.h>
#include <engine/assets/ShaderAsset.h>
#include <engine/assets/FoliageAsset.h>
#include <engine/math/Spline.h>
#include <engine/physics/PhysicsComponents.h>

#include <glm/gtc/quaternion.hpp>
#include <imgui.h>
#include <imgui_internal.h>   // DockBuilder API for the default layout

#include <algorithm>
#include <array>
#include <cctype>
#include <cmath>
#include <cstddef>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <filesystem>
#include <sstream>
#include <string>
#include <vector>

namespace {

std::array<char, 128> g_objectNameBuffer{};
std::array<char, 128> g_scriptClassBuffer{};
engine::ecs::Entity g_objectNameEntity = engine::ecs::kNull;
engine::ecs::Entity g_scriptEntity = engine::ecs::kNull;
int g_scriptTemplateIndex = 0;
int g_scriptLanguageIndex = 0; // 0 = native C++, 1 = Lua
constexpr std::size_t kScriptSourceCapacity = 128u * 1024u;
std::vector<char> g_scriptSourceBuffer(kScriptSourceCapacity, '\0');
std::string g_scriptSourcePath;
bool g_scriptSourceLoaded = false;
bool g_scriptSourceDirty = false;
bool g_scriptEditorWindowOpen = false;
bool g_scriptEditorSettingsLoaded = false;
int g_preferredCodeEditor = static_cast<int>(PreferredCodeEditor::BuiltIn);
std::array<char, 512> g_customCodeEditorPath{};
std::string g_scriptBuildLog;
bool g_scriptBuildLogOpen = false;
int g_scriptEditorTargetLine = 0;
int g_scriptEditorTargetColumn = 0;
ImGuiTextFilter g_hierarchyFilter;
// When on, clicking rows in the Hierarchy does not change the scene selection. This
// keeps a viewport selection safe from a stray hierarchy click (and the delete that
// might follow) while you work in the scene.
bool g_hierarchyLockSelection = false;
std::array<char, 96> g_componentSearch{};
bool g_componentPopupOpenRequested = false;
int g_cameraPresetSelection = -1;
std::array<char, 128> g_cameraPresetName{};
int g_cameraPresetNameSelection = -1;
int g_cameraSequenceSelection = -1;
int g_cameraSequenceShotSelection = -1;
int g_cameraSequenceCueSelection = -1;
int g_cameraSequenceNameSelection = -1;
std::array<char, 128> g_cameraSequenceName{};
engine::FoliageAssetData g_foliageDraft;
std::string g_foliageDraftPath;
bool g_foliageDraftDirty = false;
int g_foliageInstanceSelection = -1;

struct CollisionChannelDesc {
    const char* name;
    std::uint32_t bit;
};

constexpr CollisionChannelDesc kCollisionChannels[] = {
    {"Default", engine::ecs::CollisionLayer::Default},
    {"World Static", engine::ecs::CollisionLayer::WorldStatic},
    {"World Dynamic", engine::ecs::CollisionLayer::WorldDynamic},
    {"Player", engine::ecs::CollisionLayer::Player},
    {"Enemy", engine::ecs::CollisionLayer::Enemy},
    {"Collectible", engine::ecs::CollisionLayer::Collectible},
    {"Projectile", engine::ecs::CollisionLayer::Projectile},
    {"Camera Blocker", engine::ecs::CollisionLayer::CameraBlocker},
    {"Trigger", engine::ecs::CollisionLayer::Trigger},
};

struct CollisionPresetDesc {
    const char* name;
    std::uint32_t layer;
    std::uint32_t mask;
    bool trigger;
};

constexpr CollisionPresetDesc kCollisionPresets[] = {
    {"Default", engine::ecs::CollisionLayer::Default, engine::ecs::CollisionLayer::All, false},
    {"World Static", engine::ecs::CollisionLayer::WorldStatic, engine::ecs::CollisionLayer::All, false},
    {"World Dynamic", engine::ecs::CollisionLayer::WorldDynamic, engine::ecs::CollisionLayer::All, false},
    {"Player", engine::ecs::CollisionLayer::Player, engine::ecs::CollisionLayer::All, false},
    {"Enemy", engine::ecs::CollisionLayer::Enemy, engine::ecs::CollisionLayer::All, false},
    {"Collectible", engine::ecs::CollisionLayer::Collectible,
        engine::ecs::CollisionLayer::Player, true},
    {"Projectile", engine::ecs::CollisionLayer::Projectile, engine::ecs::CollisionLayer::All, false},
    {"Camera Blocker", engine::ecs::CollisionLayer::CameraBlocker, engine::ecs::CollisionLayer::All, false},
    {"Trigger Volume", engine::ecs::CollisionLayer::Trigger, engine::ecs::CollisionLayer::All, true},
    {"No Collision", engine::ecs::CollisionLayer::Default, 0u, false},
};

int CollisionChannelIndex(std::uint32_t layer) {
    for (int i = 0; i < static_cast<int>(IM_ARRAYSIZE(kCollisionChannels)); ++i)
        if (layer == kCollisionChannels[i].bit) return i;
    return 0;
}

int CollisionPresetIndex(const engine::ecs::Collider& collider) {
    for (int i = 0; i < static_cast<int>(IM_ARRAYSIZE(kCollisionPresets)); ++i) {
        const CollisionPresetDesc& preset = kCollisionPresets[i];
        if (collider.layer == preset.layer && collider.mask == preset.mask
            && collider.isTrigger == preset.trigger) return i + 1;
    }
    return 0; // Custom
}

struct GaeaImportSettings {
    float worldSize = 1000.0f;
    float maxHeight = 250.0f;
    int maxResolutionIndex = 1; // 256, 512, 1024
    bool flipX = false;
    bool flipZ = true;
    bool invertHeight = false;
    bool rawBigEndian = false;
    int maskLayer = 1;
    float maskThreshold = 0.5f;
    bool invertMask = false;
    bool clearLayerBeforeMask = true;
};
GaeaImportSettings g_gaeaImport;

struct GaeaRaster {
    int width = 0;
    int height = 0;
    int bitDepth = 0;
    std::vector<float> values;
};

std::string LowerExtension(const std::string& path) {
    std::string ext = std::filesystem::path(path).extension().string();
    std::transform(ext.begin(), ext.end(), ext.begin(),
        [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return ext;
}

bool LoadGaeaRaster(const std::string& path, bool rawBigEndian,
                    GaeaRaster& out, std::string& error) {
    try {
        const std::string ext = LowerExtension(path);
        if (ext == ".png") {
            const engine::image::Image image = engine::image::DecodePNG(path);
            if (image.width <= 1 || image.height <= 1 || image.luminance16.empty()) {
                error = "PNG contains no usable height samples.";
                return false;
            }
            out.width = image.width;
            out.height = image.height;
            out.bitDepth = image.sourceBitDepth;
            out.values.resize(image.luminance16.size());
            for (std::size_t i = 0; i < image.luminance16.size(); ++i)
                out.values[i] = static_cast<float>(image.luminance16[i]) / 65535.0f;
            return true;
        }
        if (ext == ".raw" || ext == ".r16") {
            std::ifstream input(path, std::ios::binary);
            if (!input) { error = "Could not open RAW16 heightmap."; return false; }
            const std::vector<unsigned char> bytes(
                (std::istreambuf_iterator<char>(input)), std::istreambuf_iterator<char>());
            if (bytes.empty() || (bytes.size() & 1u) != 0u) {
                error = "RAW16 size must contain complete 16-bit samples.";
                return false;
            }
            const std::size_t sampleCount = bytes.size() / 2;
            const int side = static_cast<int>(std::llround(std::sqrt(static_cast<double>(sampleCount))));
            if (side < 2 || static_cast<std::size_t>(side) * side != sampleCount) {
                error = "RAW16 import requires a square heightmap; its resolution could not be inferred.";
                return false;
            }
            out.width = out.height = side;
            out.bitDepth = 16;
            out.values.resize(sampleCount);
            for (std::size_t i = 0; i < sampleCount; ++i) {
                const unsigned char a = bytes[i * 2], b = bytes[i * 2 + 1];
                const std::uint16_t sample = rawBigEndian
                    ? static_cast<std::uint16_t>((a << 8) | b)
                    : static_cast<std::uint16_t>((b << 8) | a);
                out.values[i] = static_cast<float>(sample) / 65535.0f;
            }
            return true;
        }
        error = "Select a Gaea 16-bit PNG, .raw, or .r16 heightmap.";
    } catch (const std::exception& exception) {
        error = exception.what();
    }
    return false;
}

float SampleGaeaRaster(const GaeaRaster& raster, float u, float v) {
    const float x = std::clamp(u, 0.0f, 1.0f) * static_cast<float>(raster.width - 1);
    const float y = std::clamp(v, 0.0f, 1.0f) * static_cast<float>(raster.height - 1);
    const int x0 = static_cast<int>(std::floor(x)), y0 = static_cast<int>(std::floor(y));
    const int x1 = std::min(x0 + 1, raster.width - 1), y1 = std::min(y0 + 1, raster.height - 1);
    const float fx = x - x0, fy = y - y0;
    const auto at = [&](int px, int py) { return raster.values[static_cast<std::size_t>(py) * raster.width + px]; };
    return glm::mix(glm::mix(at(x0, y0), at(x1, y0), fx),
                    glm::mix(at(x0, y1), at(x1, y1), fx), fy);
}

std::vector<float> ResampleGaeaRaster(const GaeaRaster& raster, int resolution,
                                      bool flipX, bool flipZ, bool invert) {
    std::vector<float> values(static_cast<std::size_t>(resolution) * resolution);
    const float denom = static_cast<float>(std::max(resolution - 1, 1));
    for (int z = 0; z < resolution; ++z) {
        for (int x = 0; x < resolution; ++x) {
            float u = static_cast<float>(x) / denom;
            float v = static_cast<float>(z) / denom;
            if (flipX) u = 1.0f - u;
            if (flipZ) v = 1.0f - v;
            float value = SampleGaeaRaster(raster, u, v);
            if (invert) value = 1.0f - value;
            values[static_cast<std::size_t>(z) * resolution + x] = std::clamp(value, 0.0f, 1.0f);
        }
    }
    return values;
}

struct AudioEditorState {
    engine::AudioBuffer buffer;
    engine::AudioBuffer original;
    engine::AudioBuffer undo;
    engine::AudioBuffer clipboard;
    std::vector<engine::AudioBuffer> undoStack;
    std::vector<engine::AudioBuffer> redoStack;
    std::string sourcePath;
    std::array<char, 320> outputPath{};
    float selectionStart = 0.0f;
    float selectionEnd = 0.0f;
    float gainDb = 0.0f;
    float fadeInSeconds = 0.05f;
    float fadeOutSeconds = 0.10f;
    int generator = 0;
    float generatorFrequency = 440.0f;
    float generatorDuration = 1.0f;
    float generatorAmplitude = 0.5f;
    bool dirty = false;
    float waveformZoom = 1.0f;
    float waveformOffset = 0.0f;
    engine::AudioCueAsset cue;
    std::array<char, 320> cuePath{};
    int selectedCueClip = -1;
    engine::AdaptiveMusicAsset music;
    std::array<char, 320> musicPath{};
    int selectedMusicState = -1;
};

AudioEditorState g_audioEditor;

enum class AddableComponent {
    LinearVelocity,
    AngularVelocity,
    RigidBody,
    Collider,
    Rotator,
    Mover,
    PlayerController,
    CameraZone,
    Health,
    NavAgent,
    Script,
    AudioSource,
    ParticleSystem
};

struct ComponentCatalogEntry {
    const char* name;
    const char* category;
    const char* description;
    AddableComponent component;
};

constexpr ComponentCatalogEntry kComponentCatalog[] = {
    {"Linear Velocity", "Motion", "Constant directional movement", AddableComponent::LinearVelocity},
    {"Angular Velocity", "Motion", "Constant rotation around an axis", AddableComponent::AngularVelocity},
    {"Rigid Body", "Physics", "Mass, gravity, velocity, and simulation", AddableComponent::RigidBody},
    {"Collider", "Physics", "Collision shape fitted to this object", AddableComponent::Collider},
    {"Rotator", "Gameplay", "Continuous configurable rotation", AddableComponent::Rotator},
    {"Mover", "Gameplay", "Movement along an axis", AddableComponent::Mover},
    {"Player Controller", "Gameplay", "Player movement and camera controls", AddableComponent::PlayerController},
    {"Camera Zone", "Gameplay", "Blend to a saved camera inside a trigger volume", AddableComponent::CameraZone},
    {"Health", "Gameplay", "Hit points and alive state", AddableComponent::Health},
    {"Navigation Agent", "AI", "Patrol, perception, and chase behavior", AddableComponent::NavAgent},
    // Script is added via the dedicated "+ Add Script" button, not this catalog.
    {"Audio Source", "Audio", "2D or spatial sound playback", AddableComponent::AudioSource},
    {"Particle System", "Effects", "Animated billboard particle emitter", AddableComponent::ParticleSystem},
};

struct PrimitiveCreatorState {
    EditorScene::Primitive type = EditorScene::Primitive::Cube;
    std::array<char, 128> name{};
    glm::vec3 position{0.0f, 0.5f, 0.0f};
    glm::vec3 rotationDegrees{0.0f};
    glm::vec3 dimensions{1.0f};
    float radius = 0.5f;
    float height = 1.0f;
    int staircaseSteps = 6;
    bool addCollider = true;
    bool frameAfterCreate = true;
    bool openRequested = false;
};

PrimitiveCreatorState g_primitiveCreator;
bool g_creationPaletteOpenRequested = false;
std::array<char, 96> g_creationSearch{};

const char* PrimitiveName(EditorScene::Primitive primitive) {
    if (primitive == EditorScene::Primitive::Empty) {
        return "Empty";
    }
    if (primitive == EditorScene::Primitive::Plane) {
        return "Plane";
    }
    if (primitive == EditorScene::Primitive::Sphere) {
        return "Sphere";
    }
    if (primitive == EditorScene::Primitive::Capsule) {
        return "Capsule";
    }
    if (primitive == EditorScene::Primitive::Cylinder) {
        return "Cylinder";
    }
    if (primitive == EditorScene::Primitive::Cone) {
        return "Cone";
    }
    if (primitive == EditorScene::Primitive::Pyramid) return "Pyramid";
    if (primitive == EditorScene::Primitive::Torus) return "Torus";
    if (primitive == EditorScene::Primitive::Staircase) return "Staircase";
    return "Cube";
}

void ResetPrimitiveCreator(EditorScene::Primitive type) {
    g_primitiveCreator.type = type;
    g_primitiveCreator.name.fill('\0');
    g_primitiveCreator.rotationDegrees = glm::vec3(0.0f);
    g_primitiveCreator.addCollider = true;
    g_primitiveCreator.dimensions = glm::vec3(1.0f);
    g_primitiveCreator.radius = type == EditorScene::Primitive::Capsule ? 0.4f : 0.5f;
    g_primitiveCreator.height = type == EditorScene::Primitive::Capsule ? 1.8f : 1.0f;
    g_primitiveCreator.staircaseSteps = 6;
    if (type == EditorScene::Primitive::Torus) {
        g_primitiveCreator.radius = 0.5f;
        g_primitiveCreator.height = 0.3f;
    }
    if (type == EditorScene::Primitive::Staircase) {
        g_primitiveCreator.dimensions = glm::vec3(2.0f, 1.0f, 3.0f);
    }
    if (type == EditorScene::Primitive::Plane) {
        g_primitiveCreator.position = glm::vec3(0.0f);
        g_primitiveCreator.dimensions = glm::vec3(3.0f, 1.0f, 3.0f);
        g_primitiveCreator.addCollider = false;
    } else {
        g_primitiveCreator.position = glm::vec3(0.0f, g_primitiveCreator.height * 0.5f, 0.0f);
    }
    g_primitiveCreator.openRequested = true;
}

bool MatchesCreationSearch(const char* label, const char* category) {
    std::string query(g_creationSearch.data());
    if (query.empty()) return true;
    std::string haystack = std::string(category) + " " + label;
    std::transform(query.begin(), query.end(), query.begin(),
        [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    std::transform(haystack.begin(), haystack.end(), haystack.begin(),
        [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return haystack.find(query) != std::string::npos;
}

float PrimitiveGroundHeight() {
    switch (g_primitiveCreator.type) {
    case EditorScene::Primitive::Empty: return 0.0f;
    case EditorScene::Primitive::Plane: return 0.0f;
    case EditorScene::Primitive::Sphere: return g_primitiveCreator.radius;
    case EditorScene::Primitive::Capsule:
    case EditorScene::Primitive::Cylinder:
    case EditorScene::Primitive::Cone: return g_primitiveCreator.height * 0.5f;
    case EditorScene::Primitive::Torus: return g_primitiveCreator.height * 0.5f;
    case EditorScene::Primitive::Cube:
    case EditorScene::Primitive::Pyramid:
    case EditorScene::Primitive::Staircase: return g_primitiveCreator.dimensions.y * 0.5f;
    }
    return 0.0f;
}

const char* ObjectTypeName(const EditorScene::Object& object) {
    if (object.navMeshBoundsVolume) {
        return "Nav Mesh Bounds Volume";
    }
    if (object.light) {
        return "Light";
    }
    if (object.skeletalModel) {
        return "Skeletal Model";
    }
    return object.modelAssetPath.empty() ? PrimitiveName(object.primitive) : "Model";
}

const char* LightTypeName(engine::ecs::Light::Type type) {
    switch (type) {
    case engine::ecs::Light::Type::Directional: return "Directional";
    case engine::ecs::Light::Type::Point: return "Point";
    case engine::ecs::Light::Type::Spot: return "Spot";
    case engine::ecs::Light::Type::Area: return "Area";
    }
    return "Point";
}

engine::ecs::Light::Type LightTypeFromIndex(int index) {
    switch (index) {
    case 0: return engine::ecs::Light::Type::Directional;
    case 1: return engine::ecs::Light::Type::Point;
    case 2: return engine::ecs::Light::Type::Spot;
    case 3: return engine::ecs::Light::Type::Area;
    }
    return engine::ecs::Light::Type::Point;
}

int LightTypeIndex(engine::ecs::Light::Type type) {
    switch (type) {
    case engine::ecs::Light::Type::Directional: return 0;
    case engine::ecs::Light::Type::Point: return 1;
    case engine::ecs::Light::Type::Spot: return 2;
    case engine::ecs::Light::Type::Area: return 3;
    }
    return 1;
}

int ColliderShapeIndex(engine::ecs::ColliderShape shape) {
    switch (shape) {
    case engine::ecs::ColliderShape::Sphere: return 0;
    case engine::ecs::ColliderShape::Box: return 1;
    case engine::ecs::ColliderShape::Plane: return 2;
    case engine::ecs::ColliderShape::Capsule: return 3;
    case engine::ecs::ColliderShape::Cylinder: return 4;
    case engine::ecs::ColliderShape::Cone: return 5;
    case engine::ecs::ColliderShape::Pyramid: return 6;
    case engine::ecs::ColliderShape::Torus: return 7;
    case engine::ecs::ColliderShape::Staircase: return 8;
    }
    return 0;
}

engine::ecs::ColliderShape ColliderShapeFromIndex(int index) {
    switch (index) {
    case 1: return engine::ecs::ColliderShape::Box;
    case 2: return engine::ecs::ColliderShape::Plane;
    case 3: return engine::ecs::ColliderShape::Capsule;
    case 4: return engine::ecs::ColliderShape::Cylinder;
    case 5: return engine::ecs::ColliderShape::Cone;
    case 6: return engine::ecs::ColliderShape::Pyramid;
    case 7: return engine::ecs::ColliderShape::Torus;
    case 8: return engine::ecs::ColliderShape::Staircase;
    default: return engine::ecs::ColliderShape::Sphere;
    }
}

const char* ColliderShapeName(engine::ecs::ColliderShape shape) {
    switch (shape) {
    case engine::ecs::ColliderShape::Sphere: return "Sphere";
    case engine::ecs::ColliderShape::Box: return "Box";
    case engine::ecs::ColliderShape::Plane: return "Plane";
    case engine::ecs::ColliderShape::Capsule: return "Capsule";
    case engine::ecs::ColliderShape::Cylinder: return "Cylinder";
    case engine::ecs::ColliderShape::Cone: return "Cone";
    case engine::ecs::ColliderShape::Pyramid: return "Pyramid";
    case engine::ecs::ColliderShape::Torus: return "Torus";
    case engine::ecs::ColliderShape::Staircase: return "Staircase";
    }
    return "Unknown";
}

const char* TriggerActionModeName(EditorScene::TriggerActionMode mode) {
    switch (mode) {
    case EditorScene::TriggerActionMode::None: return "None";
    case EditorScene::TriggerActionMode::Enable: return "Enable";
    case EditorScene::TriggerActionMode::Disable: return "Disable";
    case EditorScene::TriggerActionMode::Toggle: return "Toggle";
    }
    return "None";
}

const char* CameraSequenceTriggerActionName(
    EditorScene::CameraSequenceTriggerAction action) {
    switch (action) {
    case EditorScene::CameraSequenceTriggerAction::Play: return "Play";
    case EditorScene::CameraSequenceTriggerAction::Stop: return "Stop";
    case EditorScene::CameraSequenceTriggerAction::Skip: return "Skip";
    case EditorScene::CameraSequenceTriggerAction::None:
    default: return "None";
    }
}

bool DrawCameraSequenceTriggerActionCombo(
    const char* label, EditorScene::CameraSequenceTriggerAction* action) {
    bool changed = false;
    if (ImGui::BeginCombo(label, CameraSequenceTriggerActionName(*action))) {
        const EditorScene::CameraSequenceTriggerAction actions[] = {
            EditorScene::CameraSequenceTriggerAction::None,
            EditorScene::CameraSequenceTriggerAction::Play,
            EditorScene::CameraSequenceTriggerAction::Stop,
            EditorScene::CameraSequenceTriggerAction::Skip,
        };
        for (const auto candidate : actions) {
            const bool selected = candidate == *action;
            if (ImGui::Selectable(CameraSequenceTriggerActionName(candidate), selected)) {
                *action = candidate;
                changed = true;
            }
            if (selected) ImGui::SetItemDefaultFocus();
        }
        ImGui::EndCombo();
    }
    return changed;
}

const char* AudioActionName(engine::ecs::AudioAction action) {
    switch (action) {
    case engine::ecs::AudioAction::None: return "None";
    case engine::ecs::AudioAction::Play: return "Play";
    case engine::ecs::AudioAction::Restart: return "Restart";
    case engine::ecs::AudioAction::Pause: return "Pause";
    case engine::ecs::AudioAction::Resume: return "Resume";
    case engine::ecs::AudioAction::Stop: return "Stop";
    }
    return "None";
}

const char* ParticleActionName(engine::ParticleAction action) {
    switch (action) {
    case engine::ParticleAction::None: return "None";
    case engine::ParticleAction::Play: return "Play";
    case engine::ParticleAction::Restart: return "Restart";
    case engine::ParticleAction::Stop: return "Stop";
    case engine::ParticleAction::Burst: return "Burst";
    case engine::ParticleAction::Clear: return "Clear";
    }
    return "None";
}

const char* ScriptFieldTypeName(EditorScene::ScriptField::Type type) {
    switch (type) {
    case EditorScene::ScriptField::Type::Float: return "Float";
    case EditorScene::ScriptField::Type::Int: return "Int";
    case EditorScene::ScriptField::Type::Bool: return "Bool";
    case EditorScene::ScriptField::Type::String: return "String";
    case EditorScene::ScriptField::Type::Vec3: return "Vec3";
    case EditorScene::ScriptField::Type::Color: return "Color";
    case EditorScene::ScriptField::Type::Entity: return "Entity";
    case EditorScene::ScriptField::Type::Asset: return "Asset";
    }
    return "Float";
}

EditorScene::ScriptField::Type ScriptFieldTypeFromIndex(int index) {
    switch (index) {
    case 1: return EditorScene::ScriptField::Type::Int;
    case 2: return EditorScene::ScriptField::Type::Bool;
    case 3: return EditorScene::ScriptField::Type::String;
    case 4: return EditorScene::ScriptField::Type::Vec3;
    case 5: return EditorScene::ScriptField::Type::Color;
    case 6: return EditorScene::ScriptField::Type::Entity;
    case 7: return EditorScene::ScriptField::Type::Asset;
    default: return EditorScene::ScriptField::Type::Float;
    }
}

int ScriptFieldTypeIndex(EditorScene::ScriptField::Type type) {
    switch (type) {
    case EditorScene::ScriptField::Type::Float: return 0;
    case EditorScene::ScriptField::Type::Int: return 1;
    case EditorScene::ScriptField::Type::Bool: return 2;
    case EditorScene::ScriptField::Type::String: return 3;
    case EditorScene::ScriptField::Type::Vec3: return 4;
    case EditorScene::ScriptField::Type::Color: return 5;
    case EditorScene::ScriptField::Type::Entity: return 6;
    case EditorScene::ScriptField::Type::Asset: return 7;
    }
    return 0;
}

// Auto-detect a script's fields by scanning its source for GetFieldXxx("Name", ...) calls.
// The field name is the first string-literal argument; the type comes from the accessor.
std::vector<EditorScene::ScriptField> DetectScriptFields(const std::string& source) {
    using FT = EditorScene::ScriptField::Type;
    struct Accessor { const char* call; FT type; const char* defaultValue; };
    static const Accessor accessors[] = {
        {"GetFieldFloat",  FT::Float,  "0"},
        {"GetFieldInt",    FT::Int,    "0"},
        {"GetFieldBool",   FT::Bool,   "0"},
        {"GetFieldString", FT::String, "-"},
        {"GetFieldVec3",   FT::Vec3,   "0 0 0"},
        {"GetFieldColor",  FT::Color,  "1 1 1"},
        {"GetFieldEntity", FT::Entity, "-"},
        {"GetFieldAsset",  FT::Asset,  "-"},
    };
    std::vector<EditorScene::ScriptField> fields;
    const auto seen = [&](const std::string& name) {
        return std::any_of(fields.begin(), fields.end(),
            [&](const EditorScene::ScriptField& f) { return f.name == name; });
    };
    for (const Accessor& accessor : accessors) {
        const std::string call = accessor.call;
        for (std::size_t pos = 0; (pos = source.find(call, pos)) != std::string::npos; ) {
            pos += call.size();
            const std::size_t open = source.find('(', pos);
            if (open == std::string::npos) break;
            const std::size_t nameStart = source.find('"', open);
            if (nameStart == std::string::npos) break;
            const std::size_t nameEnd = source.find('"', nameStart + 1);
            if (nameEnd == std::string::npos) break;
            const std::string name = source.substr(nameStart + 1, nameEnd - nameStart - 1);
            pos = nameEnd + 1;
            if (name.empty() || seen(name)) continue;
            EditorScene::ScriptField field;
            field.name = name;
            field.type = accessor.type;
            field.value = accessor.defaultValue;
            fields.push_back(std::move(field));
        }
    }
    return fields;
}

enum class ScriptTemplate {
    Empty = 0,
    PlayerMovement = 1,
    DoorOpener = 2,
    Pickup = 3,
    DamageZone = 4,
    AiTask = 5,
    AiDecorator = 6,
    AiService = 7,
    Patrol = 8,
    Follow = 9,
    Projectile = 10
};

ScriptTemplate ScriptTemplateFromIndex(int index) {
    switch (index) {
    case 1: return ScriptTemplate::PlayerMovement;
    case 2: return ScriptTemplate::DoorOpener;
    case 3: return ScriptTemplate::Pickup;
    case 4: return ScriptTemplate::DamageZone;
    case 5: return ScriptTemplate::Patrol;
    case 6: return ScriptTemplate::Follow;
    case 7: return ScriptTemplate::Projectile;
    case 8: return ScriptTemplate::AiTask;
    case 9: return ScriptTemplate::AiDecorator;
    case 10: return ScriptTemplate::AiService;
    default: return ScriptTemplate::Empty;
    }
}

bool IsBehaviorTreeTemplate(ScriptTemplate scriptTemplate) {
    return scriptTemplate == ScriptTemplate::AiTask
        || scriptTemplate == ScriptTemplate::AiDecorator
        || scriptTemplate == ScriptTemplate::AiService;
}

const char* BehaviorTreeTemplateFile(ScriptTemplate scriptTemplate) {
    switch (scriptTemplate) {
    case ScriptTemplate::AiTask:      return "TaskTemplate.h";
    case ScriptTemplate::AiDecorator: return "DecoratorTemplate.h";
    case ScriptTemplate::AiService:   return "ServiceTemplate.h";
    default:                          return "";
    }
}

const char* BehaviorTreeTemplatePlaceholder(ScriptTemplate scriptTemplate) {
    switch (scriptTemplate) {
    case ScriptTemplate::AiTask:      return "MyTask";
    case ScriptTemplate::AiDecorator: return "MyDecorator";
    case ScriptTemplate::AiService:   return "MyService";
    default:                          return "";
    }
}

std::vector<EditorScene::ScriptField> DefaultFieldsForTemplate(ScriptTemplate scriptTemplate) {
    using Field = EditorScene::ScriptField;
    std::vector<Field> fields;
    auto add = [&fields](const char* name, Field::Type type, const char* value) {
        Field field;
        field.name = name;
        field.type = type;
        field.value = value;
        fields.push_back(field);
    };

    switch (scriptTemplate) {
    case ScriptTemplate::PlayerMovement:
        add("speed", Field::Type::Float, "4.0");
        break;
    case ScriptTemplate::DoorOpener:
        add("target", Field::Type::String, "Door");
        add("speed", Field::Type::Float, "2.0");
        add("height", Field::Type::Float, "3.0");
        break;
    case ScriptTemplate::Pickup:
        add("target", Field::Type::String, "PlayerStart");
        add("score", Field::Type::Int, "10");
        add("particleBurst", Field::Type::Int, "16");
        break;
    case ScriptTemplate::DamageZone:
        add("target", Field::Type::String, "PlayerStart");
        add("damagePerSecond", Field::Type::Float, "10.0");
        break;
    case ScriptTemplate::Patrol:
        add("axis", Field::Type::Vec3, "1 0 0");
        add("distance", Field::Type::Float, "3.0");
        add("speed", Field::Type::Float, "2.0");
        break;
    case ScriptTemplate::Follow:
        add("target", Field::Type::Entity, "");
        add("speed", Field::Type::Float, "3.0");
        add("stopDistance", Field::Type::Float, "1.5");
        break;
    case ScriptTemplate::Projectile:
        add("direction", Field::Type::Vec3, "0 0 -1");
        add("speed", Field::Type::Float, "12.0");
        add("lifetime", Field::Type::Float, "3.0");
        break;
    case ScriptTemplate::AiTask:
    case ScriptTemplate::AiDecorator:
    case ScriptTemplate::AiService:
    case ScriptTemplate::Empty:
        break;
    }
    return fields;
}

std::string ScriptTemplateDescription(ScriptTemplate scriptTemplate) {
    switch (scriptTemplate) {
    case ScriptTemplate::PlayerMovement: return "Moves this object with WASD using the `speed` field.";
    case ScriptTemplate::DoorOpener: return "Moves a named target upward while E is held.";
    case ScriptTemplate::Pickup: return "Collects on a trigger overlap, awards score, and plays audio and particles.";
    case ScriptTemplate::DamageZone: return "Damages a named Health target every update.";
    case ScriptTemplate::Patrol: return "Moves back and forth along an axis around its start position.";
    case ScriptTemplate::Follow: return "Moves toward a target object, stopping within a distance.";
    case ScriptTemplate::Projectile: return "Moves along a direction and self-destructs after a lifetime.";
    case ScriptTemplate::AiTask: return "Behavior-tree Task that performs an action and returns Running, Success, or Failure.";
    case ScriptTemplate::AiDecorator: return "Behavior-tree Decorator that allows or blocks its attached node.";
    case ScriptTemplate::AiService: return "Behavior-tree Service that updates background state while its branch is active.";
    case ScriptTemplate::Empty: return "Blank script with helper comments.";
    }
    return "Blank script with helper comments.";
}

void WriteTemplateUpdateBody(std::ostringstream& source, ScriptTemplate scriptTemplate) {
    switch (scriptTemplate) {
    case ScriptTemplate::PlayerMovement:
        source << "    const float speed = GetFieldFloat(\"speed\", 4.0f);\n"
               << "    auto* transform = Transform();\n"
               << "    if (!transform) {\n"
               << "        return;\n"
               << "    }\n"
               << "    glm::vec3 move(0.0f);\n"
               << "    if (IsKeyDown('W')) move.z -= 1.0f;\n"
               << "    if (IsKeyDown('S')) move.z += 1.0f;\n"
               << "    if (IsKeyDown('A')) move.x -= 1.0f;\n"
               << "    if (IsKeyDown('D')) move.x += 1.0f;\n"
               << "    if (glm::length(move) > 0.0f) {\n"
               << "        transform->position += glm::normalize(move) * speed * dt;\n"
               << "    }\n";
        break;
    case ScriptTemplate::DoorOpener:
        source << "    const std::string targetName = GetFieldString(\"target\", \"Door\");\n"
               << "    const float speed = GetFieldFloat(\"speed\", 2.0f);\n"
               << "    const float height = GetFieldFloat(\"height\", 3.0f);\n"
               << "    auto* target = FindTransform(targetName);\n"
               << "    if (!target || !IsKeyDown('E')) {\n"
               << "        return;\n"
               << "    }\n"
               << "    if (target->position.y < height) {\n"
               << "        target->position.y = std::min(height, target->position.y + speed * dt);\n"
               << "    }\n";
        break;
    case ScriptTemplate::Pickup:
        source << "    if (m_collected) return;\n"
               << "    const engine::ecs::Entity target = FindObject(GetFieldString(\"target\", \"PlayerStart\"));\n"
               << "    if (target == engine::ecs::kNull || !WasTriggerEntered(target)) return;\n\n"
               << "    m_collected = true;\n"
               << "    if (auto* game = Game()) game->AddScore(GetFieldInt(\"score\", 10));\n"
               << "    PlayAudio(true);\n"
               << "    BurstParticles(GetFieldInt(\"particleBurst\", 16));\n"
               << "    Delay(0.12f, [this] { DestroySelf(); });\n";
        break;
    case ScriptTemplate::DamageZone:
        source << "    const std::string targetName = GetFieldString(\"target\", \"PlayerStart\");\n"
               << "    const float damage = GetFieldFloat(\"damagePerSecond\", 10.0f) * dt;\n"
               << "    const engine::ecs::Entity target = FindObject(targetName);\n"
               << "    if (target == engine::ecs::kNull) {\n"
               << "        return;\n"
               << "    }\n"
               << "    if (!IsTriggerTouching(target)) {\n"
               << "        return;\n"
               << "    }\n"
               << "    if (auto* health = TryGet<engine::Health>(target)) {\n"
               << "        health->Damage(damage);\n"
               << "    }\n";
        break;
    case ScriptTemplate::Patrol:
        source << "    auto* transform = Transform();\n"
               << "    if (!transform) return;\n"
               << "    if (!m_started) { m_origin = transform->position; m_started = true; }\n"
               << "    glm::vec3 axis = GetFieldVec3(\"axis\", glm::vec3(1.0f, 0.0f, 0.0f));\n"
               << "    if (glm::length(axis) < 1e-4f) axis = glm::vec3(1.0f, 0.0f, 0.0f);\n"
               << "    axis = glm::normalize(axis);\n"
               << "    transform->position += axis * (m_dir * GetFieldFloat(\"speed\", 2.0f) * dt);\n"
               << "    const float offset = glm::dot(transform->position - m_origin, axis);\n"
               << "    if (offset > GetFieldFloat(\"distance\", 3.0f)) m_dir = -1.0f;\n"
               << "    else if (offset < 0.0f) m_dir = 1.0f;\n";
        break;
    case ScriptTemplate::Follow:
        source << "    auto* self = Transform();\n"
               << "    const engine::ecs::Entity target = GetFieldEntity(\"target\");\n"
               << "    if (!self || target == engine::ecs::kNull) return;\n"
               << "    auto* targetTransform = TryGet<engine::ecs::Transform>(target);\n"
               << "    if (!targetTransform) return;\n"
               << "    const glm::vec3 toTarget = targetTransform->position - self->position;\n"
               << "    const float distance = glm::length(toTarget);\n"
               << "    if (distance > GetFieldFloat(\"stopDistance\", 1.5f) && distance > 1e-4f) {\n"
               << "        self->position += (toTarget / distance) * GetFieldFloat(\"speed\", 3.0f) * dt;\n"
               << "    }\n";
        break;
    case ScriptTemplate::Projectile:
        source << "    auto* transform = Transform();\n"
               << "    if (!transform) return;\n"
               << "    if (!m_started) { m_life = GetFieldFloat(\"lifetime\", 3.0f); m_started = true; }\n"
               << "    glm::vec3 direction = GetFieldVec3(\"direction\", glm::vec3(0.0f, 0.0f, -1.0f));\n"
               << "    if (glm::length(direction) > 1e-4f) {\n"
               << "        transform->position += glm::normalize(direction) * GetFieldFloat(\"speed\", 12.0f) * dt;\n"
               << "    }\n"
               << "    m_life -= dt;\n"
               << "    if (m_life <= 0.0f) DestroySelf();\n";
        break;
    case ScriptTemplate::AiTask:
    case ScriptTemplate::AiDecorator:
    case ScriptTemplate::AiService:
        break;
    case ScriptTemplate::Empty:
        source << "    (void)dt;\n"
               << "    // Called every Play-mode update.\n"
               << "    // Helpers: GetFieldFloat(\"speed\", 1.0f), IsKeyDown(key), WasKeyPressed(key), Transform(), FindObject(\"Door\"), DestroySelf().\n";
        break;
    }
}

// Per-template private member block (state a template's OnUpdate relies on).
void WriteTemplatePrivateMembers(std::ostringstream& source, ScriptTemplate scriptTemplate) {
    switch (scriptTemplate) {
    case ScriptTemplate::Pickup:
        source << "\nprivate:\n    bool m_collected = false;\n";
        break;
    case ScriptTemplate::Patrol:
        source << "\nprivate:\n    glm::vec3 m_origin{0.0f};\n"
               << "    bool m_started = false;\n    float m_dir = 1.0f;\n";
        break;
    case ScriptTemplate::Projectile:
        source << "\nprivate:\n    float m_life = 0.0f;\n    bool m_started = false;\n";
        break;
    default:
        break;
    }
}

bool DrawTriggerActionModeCombo(const char* label, EditorScene::TriggerActionMode* mode) {
    bool changed = false;
    if (ImGui::BeginCombo(label, TriggerActionModeName(*mode))) {
        const EditorScene::TriggerActionMode modes[] = {
            EditorScene::TriggerActionMode::None,
            EditorScene::TriggerActionMode::Enable,
            EditorScene::TriggerActionMode::Disable,
            EditorScene::TriggerActionMode::Toggle
        };
        for (EditorScene::TriggerActionMode candidate : modes) {
            const bool selected = candidate == *mode;
            if (ImGui::Selectable(TriggerActionModeName(candidate), selected)) {
                *mode = candidate;
                changed = true;
            }
            if (selected) {
                ImGui::SetItemDefaultFocus();
            }
        }
        ImGui::EndCombo();
    }
    return changed;
}

bool DrawAudioActionCombo(const char* label, engine::ecs::AudioAction* action) {
    bool changed = false;
    if (ImGui::BeginCombo(label, AudioActionName(*action))) {
        const engine::ecs::AudioAction actions[] = {
            engine::ecs::AudioAction::None,
            engine::ecs::AudioAction::Play,
            engine::ecs::AudioAction::Restart,
            engine::ecs::AudioAction::Pause,
            engine::ecs::AudioAction::Resume,
            engine::ecs::AudioAction::Stop
        };
        for (const engine::ecs::AudioAction candidate : actions) {
            const bool selected = candidate == *action;
            if (ImGui::Selectable(AudioActionName(candidate), selected)) {
                *action = candidate;
                changed = true;
            }
            if (selected) ImGui::SetItemDefaultFocus();
        }
        ImGui::EndCombo();
    }
    return changed;
}

bool DrawParticleActionCombo(const char* label, engine::ParticleAction* action) {
    bool changed = false;
    if (ImGui::BeginCombo(label, ParticleActionName(*action))) {
        const engine::ParticleAction actions[] = {
            engine::ParticleAction::None, engine::ParticleAction::Play,
            engine::ParticleAction::Restart, engine::ParticleAction::Stop,
            engine::ParticleAction::Burst, engine::ParticleAction::Clear
        };
        for (const engine::ParticleAction candidate : actions) {
            const bool selected = candidate == *action;
            if (ImGui::Selectable(ParticleActionName(candidate), selected)) {
                *action = candidate;
                changed = true;
            }
            if (selected) ImGui::SetItemDefaultFocus();
        }
        ImGui::EndCombo();
    }
    return changed;
}

std::string SanitizeScriptClassName(const std::string& raw) {
    std::string result;
    result.reserve(raw.size());
    for (char ch : raw) {
        const unsigned char u = static_cast<unsigned char>(ch);
        if (std::isalnum(u) || ch == '_') {
            result.push_back(ch);
        }
    }
    if (result.empty()) {
        return {};
    }
    if (std::isdigit(static_cast<unsigned char>(result.front()))) {
        result.insert(result.begin(), '_');
    }
    return result;
}

bool IsGameModuleRoot(const std::filesystem::path& path) {
    std::error_code ec;
    return std::filesystem::exists(path / "CMakeLists.txt", ec)
        && std::filesystem::exists(path / "include" / "game" / "GameModule.h", ec);
}

std::filesystem::path GameModuleRootFor(const EditorDockspace::Context& context) {
#ifdef THREEDG_GAME_MODULE_DIR
    const std::filesystem::path configured(THREEDG_GAME_MODULE_DIR);
    if (IsGameModuleRoot(configured)) {
        return configured;
    }
#endif
    std::vector<std::filesystem::path> starts;
    if (context.assets && !context.assets->RootPath().empty()) {
        std::error_code ec;
        starts.push_back(std::filesystem::absolute(context.assets->RootPath(), ec));
    }
    std::error_code ec;
    starts.push_back(std::filesystem::current_path(ec));

    for (std::filesystem::path start : starts) {
        if (start.empty()) continue;
        for (int depth = 0; depth < 8 && !start.empty(); ++depth) {
            if (IsGameModuleRoot(start)) return start;
            if (IsGameModuleRoot(start / "game")) return start / "game";
            const std::filesystem::path parent = start.parent_path();
            if (parent == start) break;
            start = parent;
        }
    }
    return std::filesystem::current_path(ec) / "game";
}

std::filesystem::path ProjectRootFor(const EditorDockspace::Context& context) {
    return GameModuleRootFor(context).parent_path();
}

void EnsureScriptEditorSettings(EditorDockspace::Context& context) {
    if (g_scriptEditorSettingsLoaded) return;
    g_scriptEditorSettingsLoaded = true;
    if (!context.config) return;
    const std::string preferred =
        context.config->GetString("scripts.code_editor", "BuiltIn");
    if (preferred == "VSCode") g_preferredCodeEditor = static_cast<int>(PreferredCodeEditor::VisualStudioCode);
    else if (preferred == "VisualStudio") g_preferredCodeEditor = static_cast<int>(PreferredCodeEditor::VisualStudio);
    else if (preferred == "Rider") g_preferredCodeEditor = static_cast<int>(PreferredCodeEditor::Rider);
    else if (preferred == "Custom") g_preferredCodeEditor = static_cast<int>(PreferredCodeEditor::Custom);
    const std::string custom = context.config->GetString("scripts.custom_editor", "");
    std::snprintf(g_customCodeEditorPath.data(), g_customCodeEditorPath.size(), "%s", custom.c_str());
}

void SaveScriptEditorSettings(EditorDockspace::Context& context) {
    if (!context.config) return;
    static const char* values[] = {"BuiltIn", "VSCode", "VisualStudio", "Rider", "Custom"};
    const int index = std::clamp(g_preferredCodeEditor, 0, 4);
    context.config->Set("scripts.code_editor", values[index]);
    context.config->Set("scripts.custom_editor", g_customCodeEditorPath.data());
    context.config->Save();
}

std::string StoredScriptPath(const std::filesystem::path& absolutePath) {
    std::error_code ec;
    const std::filesystem::path relative =
        std::filesystem::relative(absolutePath, std::filesystem::current_path(ec), ec);
    return ec ? absolutePath.lexically_normal().generic_string()
              : relative.lexically_normal().generic_string();
}

std::string ScriptPathFor(const EditorDockspace::Context& context,
                          const std::string& className,
                          bool lua = false) {
    std::error_code ec;
    const std::filesystem::path contentRoot =
        context.assets && !context.assets->RootPath().empty()
            ? std::filesystem::absolute(context.assets->RootPath(), ec)
            : GameModuleRootFor(context).parent_path() / "Content";
    return StoredScriptPath(contentRoot / "Scripts"
        / (className + (lua ? ".lua" : ".h")));
}

struct SavedScriptEntry {
    std::string className;
    std::string storedPath;
    bool lua = false;
};

std::vector<SavedScriptEntry> SavedScriptsFor(const EditorDockspace::Context& context) {
    std::vector<std::filesystem::path> roots;
    std::error_code ec;
    if (context.assets && !context.assets->RootPath().empty()) {
        roots.push_back(std::filesystem::absolute(context.assets->RootPath(), ec) / "Scripts");
        ec.clear();
    }
    roots.push_back(ProjectRootFor(context) / "Content" / "Scripts");

    std::vector<SavedScriptEntry> scripts;
    for (const std::filesystem::path& root : roots) {
        for (std::filesystem::directory_iterator it(root, ec), end;
             !ec && it != end; it.increment(ec)) {
            if (!it->is_regular_file(ec)) continue;
            const bool lua = it->path().extension() == ".lua";
            if (!lua && it->path().extension() != ".h") continue;
            if (!lua) {
                std::ifstream source(it->path(), std::ios::binary);
                const std::string contents((std::istreambuf_iterator<char>(source)),
                                           std::istreambuf_iterator<char>());
                if (contents.find("engine::ai::BtScript") != std::string::npos) {
                    continue;
                }
            }
            const std::string stem = it->path().stem().string();
            const std::string className = SanitizeScriptClassName(stem);
            if (className.empty() || className != stem) continue;
            const bool alreadyListed = std::any_of(scripts.begin(), scripts.end(),
                [&className, lua](const SavedScriptEntry& entry) {
                    return entry.className == className && entry.lua == lua;
                });
            if (!alreadyListed) {
                scripts.push_back({className, StoredScriptPath(it->path()), lua});
            }
        }
        ec.clear();
    }
    std::sort(scripts.begin(), scripts.end(),
        [](const SavedScriptEntry& a, const SavedScriptEntry& b) {
            return a.className == b.className ? a.lua < b.lua
                                              : a.className < b.className;
        });
    return scripts;
}

bool WriteTextFile(const std::filesystem::path& path, const std::string& text, std::string* error) {
    std::ofstream out(path);
    if (!out) {
        if (error) {
            *error = "Could not write " + path.string();
        }
        return false;
    }
    out << text;
    return true;
}

// Gameplay-script registration is handled by the shared EditorGeneratedScriptTools::
// RegisterScript (see CreateScriptFiles below). The former duplicate generator that lived
// here was removed so there is a single source of truth for the per-project list + header.

bool LoadBehaviorTreeTemplate(const std::filesystem::path& gameRoot,
                              ScriptTemplate scriptTemplate,
                              const std::string& className,
                              std::string* source,
                              std::string* error) {
    const std::filesystem::path relative =
        std::filesystem::path("editor") / "btscripts" / "templates"
        / BehaviorTreeTemplateFile(scriptTemplate);
    const std::filesystem::path candidates[] = {
#ifdef THREEDG_BT_SCRIPT_TEMPLATE_DIR
        std::filesystem::path(THREEDG_BT_SCRIPT_TEMPLATE_DIR)
            / BehaviorTreeTemplateFile(scriptTemplate),
#endif
        std::filesystem::current_path() / relative,
        std::filesystem::current_path().parent_path() / relative,
        gameRoot.parent_path() / relative
    };

    std::ifstream input;
    for (const std::filesystem::path& candidate : candidates) {
        input.open(candidate, std::ios::binary);
        if (input) {
            break;
        }
        input.clear();
    }
    if (!input) {
        if (error) {
            *error = "Could not find AI script template "
                + std::string(BehaviorTreeTemplateFile(scriptTemplate))
                + " in editor/btscripts/templates.";
        }
        return false;
    }

    *source = std::string((std::istreambuf_iterator<char>(input)),
                          std::istreambuf_iterator<char>());
    const std::string placeholder = BehaviorTreeTemplatePlaceholder(scriptTemplate);
    std::size_t offset = 0;
    while ((offset = source->find(placeholder, offset)) != std::string::npos) {
        source->replace(offset, placeholder.size(), className);
        offset += className.size();
    }
    return true;
}

bool LoadScriptSource(const std::string& path, std::string* error) {
    std::ifstream input(path, std::ios::binary);
    if (!input) {
        if (error) *error = "Could not open " + path;
        return false;
    }
    const std::string source((std::istreambuf_iterator<char>(input)),
                             std::istreambuf_iterator<char>());
    if (source.size() + 1 > g_scriptSourceBuffer.size()) {
        if (error) *error = "Script is larger than the editor's 128 KB source limit.";
        return false;
    }
    std::fill(g_scriptSourceBuffer.begin(), g_scriptSourceBuffer.end(), '\0');
    std::copy(source.begin(), source.end(), g_scriptSourceBuffer.begin());
    g_scriptSourcePath = path;
    g_scriptSourceLoaded = true;
    g_scriptSourceDirty = false;
    return true;
}

int ScriptSourceNavigationCallback(ImGuiInputTextCallbackData* data) {
    if (!data || g_scriptEditorTargetLine <= 0) return 0;
    int offset = 0;
    int line = 1;
    while (offset < data->BufTextLen && line < g_scriptEditorTargetLine) {
        if (data->Buf[offset++] == '\n') ++line;
    }
    const int lineStart = offset;
    while (offset < data->BufTextLen && data->Buf[offset] != '\n'
           && data->Buf[offset] != '\r') {
        ++offset;
    }
    const int columnOffset = std::clamp(g_scriptEditorTargetColumn - 1, 0,
                                        offset - lineStart);
    data->CursorPos = lineStart + columnOffset;
    data->SelectionStart = data->CursorPos;
    data->SelectionEnd = data->CursorPos;
    g_scriptEditorTargetLine = 0;
    g_scriptEditorTargetColumn = 0;
    return 0;
}

bool OpenScriptInPreferredEditor(EditorDockspace::Context& context,
                                 const std::string& path,
                                 std::string* error) {
    EnsureScriptEditorSettings(context);
    if (!LoadScriptSource(path, error)) return false;
    g_scriptEditorWindowOpen = true;
    const PreferredCodeEditor preferred =
        static_cast<PreferredCodeEditor>(std::clamp(g_preferredCodeEditor, 0, 4));
    if (preferred == PreferredCodeEditor::BuiltIn) return true;
    return EditorScriptTools::OpenExternalEditor(preferred,
        g_customCodeEditorPath.data(), path, ProjectRootFor(context), error);
}

bool CreateScriptFiles(const EditorDockspace::Context& context,
                       const std::string& className,
                       ScriptTemplate scriptTemplate,
                       bool lua,
                       std::string* scriptPath,
                       std::string* error) {
    const std::filesystem::path gameRoot = GameModuleRootFor(context);
    if (!lua && !IsGameModuleRoot(gameRoot)) {
        if (error) {
            *error = "Could not find the shared game module (game/CMakeLists.txt and game/include/game/GameModule.h).";
        }
        return false;
    }
    std::error_code ec;
    const std::filesystem::path contentRoot =
        context.assets && !context.assets->RootPath().empty()
            ? std::filesystem::absolute(context.assets->RootPath(), ec)
            : gameRoot.parent_path() / "Content";
    const std::filesystem::path scriptRoot = contentRoot / "Scripts";
    std::filesystem::create_directories(scriptRoot, ec);
    if (ec) {
        if (error) {
            *error = "Could not create script folder: " + ec.message();
        }
        return false;
    }

    const std::filesystem::path headerPath =
        scriptRoot / (className + (lua ? ".lua" : ".h"));
    const std::filesystem::path docsRoot = scriptRoot / "Docs";
    std::filesystem::create_directories(docsRoot, ec);
    if (ec) {
        if (error) {
            *error = "Could not create script docs folder: " + ec.message();
        }
        return false;
    }
    const std::filesystem::path docPath = docsRoot / (className + ".md");

    // Copy scripts made by the previous workflow into Content/Scripts. Keep the
    // old file untouched so projects can migrate without losing user changes.
    const std::filesystem::path legacyHeader =
        gameRoot / "include" / "game" / "scripts" / (className + ".h");
    if (!lua && !std::filesystem::exists(headerPath, ec)
        && std::filesystem::exists(legacyHeader, ec)) {
        std::filesystem::copy_file(legacyHeader, headerPath,
            std::filesystem::copy_options::skip_existing, ec);
        if (ec) {
            if (error) *error = "Could not migrate existing script into Content/Scripts: " + ec.message();
            return false;
        }
    }

    if (!std::filesystem::exists(headerPath)) {
        if (lua) {
            std::ostringstream source;
            source
                << "-- " << className << "\n"
                << "-- Runs in Editor Play and packaged games without rebuilding.\n\n"
                << "function OnCreate()\n"
                << "    -- Called once when this object enters Play mode.\n"
                << "end\n\n"
                << "function OnUpdate(dt)\n"
                << "    -- Example: Engine.Translate(0, 0, dt)\n"
                << "end\n\n"
                << "function OnFixedUpdate(dt)\n"
                << "    -- Put fixed-step physics-related logic here.\n"
                << "end\n\n"
                << "function OnDestroy()\n"
                << "    -- Called before this object or script is removed.\n"
                << "end\n";
            if (!WriteTextFile(headerPath, source.str(), error)) return false;
        } else if (IsBehaviorTreeTemplate(scriptTemplate)) {
            std::string source;
            if (!LoadBehaviorTreeTemplate(gameRoot, scriptTemplate, className, &source, error)
                || !WriteTextFile(headerPath, source, error)) {
                return false;
            }
        } else {
            std::ostringstream header;
            header << "#pragma once\n\n"
                   << "#include <engine/gameplay/GameMode.h>\n"
                   << "#include <engine/gameplay/GameplayComponents.h>\n"
                   << "#include <engine/gameplay/Script.h>\n\n"
                   << "#include <algorithm>\n"
                   << "#include <glm/geometric.hpp>\n"
                   << "#include <string>\n\n"
                   << "class " << className << " final : public engine::Script {\n"
                   << "public:\n"
                   << "    void OnCreate() override {\n"
                   << "    // Called when the object enters Play mode.\n"
                   << "    // Example: if (auto* transform = Transform()) { transform->position.y += 1.0f; }\n"
                   << "    }\n\n"
                   << "    void OnUpdate(float dt) override {\n";
            WriteTemplateUpdateBody(header, scriptTemplate);
            header << "    }\n";
            WriteTemplatePrivateMembers(header, scriptTemplate);
            header << "};\n";
            if (!WriteTextFile(headerPath, header.str(), error)) {
                return false;
            }
        }
    }

    if (!lua && !EditorGeneratedScriptTools::RegisterScript(
            gameRoot, scriptRoot, className,
            IsBehaviorTreeTemplate(scriptTemplate), error)) {
        return false;
    }

    if (!std::filesystem::exists(docPath)) {
        std::ostringstream doc;
        doc << "# " << className << "\n\n"
            << "## What It Does\n\n"
            << (lua ? "Lua gameplay script generated by the editor. "
                : IsBehaviorTreeTemplate(scriptTemplate)
                ? "Behavior-tree script template generated by the editor. "
                : "Gameplay script template generated by the editor. ")
            << ScriptTemplateDescription(scriptTemplate);
        if (lua) {
            doc << " It runs directly in Play mode and packaged games; no C++ rebuild is required.\n\n"
                << "## How To Use It\n\n"
                << "Define `OnCreate`, `OnUpdate(dt)`, `OnFixedUpdate(dt)`, and `OnDestroy` as needed. "
                << "Use the global `Engine` table for transforms, input, fields, animation, audio, particles, camera shake, health, and game score/state. "
                << "Save the file and start Play again to load the new version.\n";
        } else if (IsBehaviorTreeTemplate(scriptTemplate)) {
            doc << " It derives from `engine::ai::BtScript` and is selected from the Script Class dropdown on a Behavior Graph script task, decorator, or service.\n\n"
                << "## How To Use It\n\n"
                << "Edit the generated methods, compile scripts, then open the Behavior Graph. Add the matching Script Task, Script Decorator, or Script Service and choose `" << className
                << "` from its Script Class dropdown. The editor registers the class in the shared game module, so it works in both Play mode and built projects.\n";
        } else {
            doc << " It derives from `engine::Script` so it can be attached to a scene object and run in Play mode after registration.\n\n"
                << "## How To Use It\n\n"
                << "Use `OnCreate()` for one-time setup when the object enters Play mode. Use `OnUpdate(float dt)` for per-frame behavior. The editor registers this class automatically in the shared game module; rebuild and restart the editor before Play mode can run newly compiled code. The standalone player receives the same class on its next build. Common helpers include `GetFieldFloat()`, `GetFieldInt()`, `GetFieldBool()`, `GetFieldString()`, `Self()`, `Transform()`, `FindObject()`, `FindTransform()`, `SocketPosition()`, `SocketTransform()`, `IsKeyDown()`, `WasKeyPressed()`, `PlayAudio()`, `StopAudio()`, `PlayParticles()`, `StopParticles()`, `RestartParticles()`, `BurstParticles()`, `SetParticleRate()`, `ShakeCamera()`, `PlayCameraSequence()`, `WasCameraSequenceEvent()`, `WasCameraSequenceFinished()`, and `DestroySelf()`. Pass an entity returned by `FindObject()` to control another object's Audio Source or Particle System.\n";
        }
        if (!WriteTextFile(docPath, doc.str(), error)) {
            return false;
        }
    }

    if (scriptPath) {
        *scriptPath = StoredScriptPath(headerPath);
    }
    return true;
}

struct ScenePhysicsStatus {
    std::size_t objects = 0;
    std::size_t rigidBodies = 0;
    std::size_t dynamicBodies = 0;
    std::size_t staticBodies = 0;
    std::size_t colliders = 0;
    std::size_t staticColliders = 0;
    std::size_t triggers = 0;
    std::size_t spheres = 0;
    std::size_t boxes = 0;
    std::size_t planes = 0;
    std::size_t capsules = 0;
    std::size_t cylinders = 0;
    std::size_t cones = 0;
    std::size_t pyramids = 0;
    std::size_t toruses = 0;
    std::size_t staircases = 0;
    std::size_t dynamicBodiesWithoutCollider = 0;
    std::size_t invalidColliders = 0;
    std::size_t joints = 0;
};

bool ColliderIsInvalid(const engine::ecs::Collider& collider) {
    switch (collider.shape) {
    case engine::ecs::ColliderShape::Sphere:
        return collider.radius <= 0.0f;
    case engine::ecs::ColliderShape::Box:
    case engine::ecs::ColliderShape::Pyramid:
    case engine::ecs::ColliderShape::Staircase:
        return collider.halfExtents.x <= 0.0f
            || collider.halfExtents.y <= 0.0f
            || collider.halfExtents.z <= 0.0f;
    case engine::ecs::ColliderShape::Plane:
        return collider.planeNormal.x == 0.0f
            && collider.planeNormal.y == 0.0f
            && collider.planeNormal.z == 0.0f;
    case engine::ecs::ColliderShape::Capsule:
        return collider.radius <= 0.0f || collider.halfHeight < 0.0f;
    case engine::ecs::ColliderShape::Cylinder:
    case engine::ecs::ColliderShape::Cone:
        return collider.radius <= 0.0f || collider.halfHeight <= 0.0f;
    case engine::ecs::ColliderShape::Torus:
        return collider.majorRadius <= 0.0f || collider.minorRadius <= 0.0f;
    }

    return true;
}

ScenePhysicsStatus CollectScenePhysicsStatus(const EditorScene& scene) {
    ScenePhysicsStatus status;
    status.objects = scene.Objects().size();
    status.joints = scene.PhysicsJoints().size();

    for (const EditorScene::Object& object : scene.Objects()) {
        if (object.rigidBodyEnabled) {
            ++status.rigidBodies;
            if (object.rigidBody.invMass > 0.0f) {
                ++status.dynamicBodies;
                if (!object.colliderEnabled) {
                    ++status.dynamicBodiesWithoutCollider;
                }
            } else {
                ++status.staticBodies;
            }
        }

        if (!object.colliderEnabled) {
            continue;
        }

        ++status.colliders;
        if (object.collider.isTrigger) {
            ++status.triggers;
        }
        if (!object.rigidBodyEnabled || object.rigidBody.invMass <= 0.0f) {
            ++status.staticColliders;
        }
        if (ColliderIsInvalid(object.collider)) {
            ++status.invalidColliders;
        }

        switch (object.collider.shape) {
        case engine::ecs::ColliderShape::Sphere:
            ++status.spheres;
            break;
        case engine::ecs::ColliderShape::Box:
            ++status.boxes;
            break;
        case engine::ecs::ColliderShape::Plane:
            ++status.planes;
            break;
        case engine::ecs::ColliderShape::Capsule: ++status.capsules; break;
        case engine::ecs::ColliderShape::Cylinder: ++status.cylinders; break;
        case engine::ecs::ColliderShape::Cone: ++status.cones; break;
        case engine::ecs::ColliderShape::Pyramid: ++status.pyramids; break;
        case engine::ecs::ColliderShape::Torus: ++status.toruses; break;
        case engine::ecs::ColliderShape::Staircase: ++status.staircases; break;
        }
    }

    return status;
}

const char* PhysicsJointTypeName(EditorScene::PhysicsJoint::Type type, bool rope) {
    if (type == EditorScene::PhysicsJoint::Type::Spring) {
        return "Spring";
    }
    return rope ? "Rope" : "Distance";
}

void DrawStatusRow(const char* label, std::size_t value) {
    ImGui::TableNextRow();
    ImGui::TableNextColumn();
    ImGui::TextUnformatted(label);
    ImGui::TableNextColumn();
    ImGui::Text("%d", static_cast<int>(value));
}

engine::ecs::Collider DefaultColliderForObject(const EditorScene::Object& object,
                                               const engine::ecs::Transform* transform) {
    // A low restitution so editor bodies settle on landing instead of bouncing.
    constexpr float kDefaultRestitution = 0.1f;

    if (object.primitive == EditorScene::Primitive::Plane && object.modelAssetPath.empty()) {
        const float planeOffset = transform ? transform->position.y : 0.0f;
        engine::ecs::Collider collider = engine::ecs::Collider::MakePlane(glm::vec3(0.0f, 1.0f, 0.0f), planeOffset);
        collider.restitution = kDefaultRestitution;
        return collider;
    }

    if (object.primitive == EditorScene::Primitive::Sphere && object.modelAssetPath.empty()) {
        engine::ecs::Collider collider = engine::ecs::Collider::MakeSphere(0.5f);
        collider.restitution = kDefaultRestitution;
        return collider;
    }

    if (object.primitive == EditorScene::Primitive::Capsule && object.modelAssetPath.empty()) {
        engine::ecs::Collider collider = engine::ecs::Collider::MakeCapsuleFromHeight(0.4f, 1.8f);
        collider.restitution = kDefaultRestitution;
        return collider;
    }

    if (object.primitive == EditorScene::Primitive::Cylinder && object.modelAssetPath.empty()) {
        const float radius = transform ? 0.5f * std::max(transform->scale.x, transform->scale.z) : 0.5f;
        const float height = transform ? transform->scale.y : 1.0f;
        engine::ecs::Collider collider = engine::ecs::Collider::MakeCylinder(radius, height);
        collider.restitution = kDefaultRestitution;
        return collider;
    }

    if (object.modelAssetPath.empty() && transform) {
        if (object.primitive == EditorScene::Primitive::Cone)
            return engine::ecs::Collider::MakeCone(
                0.5f * std::max(transform->scale.x, transform->scale.z), transform->scale.y);
        if (object.primitive == EditorScene::Primitive::Pyramid)
            return engine::ecs::Collider::MakePyramid(transform->scale * 0.5f);
        if (object.primitive == EditorScene::Primitive::Torus) {
            const float radialScale = std::max(transform->scale.x, transform->scale.z);
            return engine::ecs::Collider::MakeTorus(0.35f * radialScale,
                0.15f * std::max(radialScale, transform->scale.y));
        }
        if (object.primitive == EditorScene::Primitive::Staircase)
            return engine::ecs::Collider::MakeStaircase(transform->scale * 0.5f, 6);
    }

    engine::ecs::Collider collider = transform
        ? engine::ecs::Collider::MakeBox(glm::vec3(
              std::max(transform->scale.x * 0.5f, 0.001f),
              std::max(transform->scale.y * 0.5f, 0.001f),
              std::max(transform->scale.z * 0.5f, 0.001f)))
        : engine::ecs::Collider::MakeBox(glm::vec3(0.5f));
    collider.restitution = kDefaultRestitution;
    return collider;
}

bool HasComponent(const EditorScene::Object& object, AddableComponent component) {
    switch (component) {
    case AddableComponent::LinearVelocity: return object.linearVelocityEnabled;
    case AddableComponent::AngularVelocity: return object.angularVelocityEnabled;
    case AddableComponent::RigidBody: return object.rigidBodyEnabled;
    case AddableComponent::Collider: return object.colliderEnabled;
    case AddableComponent::Rotator: return object.rotatorEnabled;
    case AddableComponent::Mover: return object.moverEnabled;
    case AddableComponent::PlayerController: return object.playerControllerEnabled;
    case AddableComponent::CameraZone: return object.cameraZoneEnabled;
    case AddableComponent::Health: return object.healthEnabled;
    case AddableComponent::NavAgent: return object.navAgentEnabled;
    case AddableComponent::Script:
        return object.scriptEnabled || !object.scriptClassName.empty() || !object.scriptPath.empty();
    case AddableComponent::AudioSource: return object.audioSourceEnabled;
    case AddableComponent::ParticleSystem: return object.particleSystemEnabled;
    }
    return false;
}

bool ComponentMatchesSearch(const ComponentCatalogEntry& entry) {
    std::string query(g_componentSearch.data());
    if (query.empty()) return true;
    std::string haystack = std::string(entry.category) + " " + entry.name + " " + entry.description;
    std::transform(query.begin(), query.end(), query.begin(),
        [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    std::transform(haystack.begin(), haystack.end(), haystack.begin(),
        [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return haystack.find(query) != std::string::npos;
}

bool AddComponent(EditorDockspace::Context& context, AddableComponent component) {
    if (!context.scene) return false;
    const EditorScene::Object* selected = context.scene->SelectedObject();
    if (!selected || selected->locked || HasComponent(*selected, component)) return false;

    bool added = false;
    switch (component) {
    case AddableComponent::LinearVelocity:
        added = context.scene->SetSelectedLinearVelocityEnabled(true);
        break;
    case AddableComponent::AngularVelocity:
        added = context.scene->SetSelectedAngularVelocityEnabled(true);
        break;
    case AddableComponent::RigidBody:
        added = context.scene->SetSelectedRigidBody(engine::ecs::RigidBody::Dynamic(1.0f));
        break;
    case AddableComponent::Collider: {
        const engine::ecs::Transform* transform = context.scene->TryGetTransform(selected->entity);
        added = context.scene->SetSelectedCollider(DefaultColliderForObject(*selected, transform));
        break;
    }
    case AddableComponent::Rotator:
        added = context.scene->SetSelectedRotatorEnabled(true);
        break;
    case AddableComponent::Mover:
        added = context.scene->SetSelectedMoverEnabled(true);
        break;
    case AddableComponent::PlayerController:
        added = context.scene->SetSelectedPlayerControllerEnabled(true);
        break;
    case AddableComponent::CameraZone: {
        const std::string preset = context.scene->CameraPresets().empty()
            ? std::string()
            : context.scene->CameraPresets().front().name;
        added = context.scene->SetSelectedCameraZone(true, preset, true, 0, 0.35f);
        break;
    }
    case AddableComponent::Health:
        added = context.scene->SetSelectedHealthEnabled(true);
        break;
    case AddableComponent::NavAgent:
        added = context.scene->SetSelectedNavAgent(true, 3.0f, 20.0f, 0.6f, 0.3f,
            std::string(), 12.0f, 45.0f);
        break;
    case AddableComponent::Script:
        added = context.scene->SetSelectedScript("NewObjectScript", std::string(), false);
        break;
    case AddableComponent::AudioSource:
        added = context.scene->SetSelectedAudioSource(true, std::string(), 1.0f, 1.0f,
            true, false, false, 1.0f, 40.0f, 1.0f);
        break;
    case AddableComponent::ParticleSystem: {
        engine::ParticleSystemComponent settings;
        added = context.scene->SetSelectedParticleSystem(true, settings);
        if (added && context.panels) {
            context.panels->SetOpen(EditorPanels::Panel::ParticleEditor, true);
        }
        break;
    }
    }
    if (added && context.log) {
        for (const ComponentCatalogEntry& entry : kComponentCatalog) {
            if (entry.component == component) {
                context.log->Info(std::string("Added ") + entry.name + " component to " + selected->name);
                break;
            }
        }
    }
    return added;
}

void DrawComponentMenuItems(EditorDockspace::Context& context) {
    const EditorScene::Object* selected = context.scene ? context.scene->SelectedObject() : nullptr;
    const bool locked = !selected || selected->locked;
    const char* currentCategory = nullptr;
    for (const ComponentCatalogEntry& entry : kComponentCatalog) {
        if (!currentCategory || std::string(currentCategory) != entry.category) {
            if (currentCategory) ImGui::Separator();
            currentCategory = entry.category;
            ImGui::TextDisabled("%s", currentCategory);
        }
        const bool attached = selected && HasComponent(*selected, entry.component);
        const std::string label = attached ? std::string(entry.name) + " (Added)" : entry.name;
        if (ImGui::MenuItem(label.c_str(), nullptr, false, !locked && !attached)) {
            AddComponent(context, entry.component);
        }
    }
}

void DrawAddComponentPopup(EditorDockspace::Context& context) {
    if (g_componentPopupOpenRequested) {
        g_componentSearch.fill('\0');
        ImGui::OpenPopup("Add Component");
        g_componentPopupOpenRequested = false;
    }
    ImGui::SetNextWindowSize(ImVec2(455.0f, 390.0f), ImGuiCond_Appearing);
    if (!ImGui::BeginPopup("Add Component")) return;

    const EditorScene::Object* selected = context.scene ? context.scene->SelectedObject() : nullptr;
    ImGui::Text("Add Component to %s", selected ? selected->name.c_str() : "selection");
    if (selected && selected->locked) ImGui::TextColored(ImVec4(1.0f, 0.55f, 0.25f, 1.0f), "Unlock this object to add components.");
    ImGui::SetNextItemWidth(-1.0f);
    if (ImGui::IsWindowAppearing()) ImGui::SetKeyboardFocusHere();
    ImGui::InputTextWithHint("##ComponentSearch", "Search components...",
        g_componentSearch.data(), g_componentSearch.size());
    ImGui::Separator();

    bool close = false;
    ImGui::BeginChild("##ComponentResults", ImVec2(0.0f, 0.0f), false);
    const char* currentCategory = nullptr;
    for (const ComponentCatalogEntry& entry : kComponentCatalog) {
        if (!ComponentMatchesSearch(entry)) continue;
        if (!currentCategory || std::string(currentCategory) != entry.category) {
            currentCategory = entry.category;
            ImGui::Spacing();
            ImGui::TextDisabled("%s", currentCategory);
        }
        const bool attached = selected && HasComponent(*selected, entry.component);
        const bool disabled = !selected || selected->locked || attached;
        ImGui::PushID(static_cast<int>(entry.component));
        if (disabled) ImGui::BeginDisabled();
        const std::string label = attached ? std::string(entry.name) + "   Added" : entry.name;
        if (ImGui::Selectable(label.c_str(), false, 0, ImVec2(0.0f, 38.0f))) {
            close = AddComponent(context, entry.component);
        }
        if (disabled) ImGui::EndDisabled();
        ImGui::SameLine(190.0f);
        ImGui::TextDisabled("%s", entry.description);
        ImGui::PopID();
    }
    ImGui::EndChild();
    if (close) ImGui::CloseCurrentPopup();
    ImGui::EndPopup();
}

bool IsMaterialDocument(const std::filesystem::path& path) {
    return path.extension() == ".3dgmat";
}

std::vector<EditorAssets::Asset> FindMaterialAssets(const EditorAssets& assets) {
    std::vector<EditorAssets::Asset> materials;
    std::error_code ec;
    const std::filesystem::path root = assets.RootPath();
    if (!std::filesystem::exists(root, ec) || !std::filesystem::is_directory(root, ec)) {
        return materials;
    }

    for (const std::filesystem::directory_entry& entry : std::filesystem::recursive_directory_iterator(root, ec)) {
        if (ec) {
            break;
        }
        if (!entry.is_regular_file(ec) || !IsMaterialDocument(entry.path())) {
            continue;
        }

        EditorAssets::Asset material;
        material.relativePath = std::filesystem::relative(entry.path(), root, ec).string();
        if (ec) {
            continue;
        }
        std::replace(material.relativePath.begin(), material.relativePath.end(), '\\', '/');
        material.displayName = entry.path().filename().string();
        material.type = EditorAssets::Type::Material;
        materials.push_back(material);
    }

    std::sort(materials.begin(), materials.end(),
        [](const EditorAssets::Asset& a, const EditorAssets::Asset& b) {
            return a.relativePath < b.relativePath;
        });
    return materials;
}

std::vector<EditorAssets::Asset> FindBehaviorGraphAssets(const EditorAssets& assets) {
    std::vector<EditorAssets::Asset> graphs;
    std::error_code ec;
    const std::filesystem::path root = assets.RootPath();
    if (!std::filesystem::exists(root, ec) || !std::filesystem::is_directory(root, ec)) {
        return graphs;
    }

    for (const std::filesystem::directory_entry& entry :
         std::filesystem::recursive_directory_iterator(root, ec)) {
        if (ec) break;
        if (!entry.is_regular_file(ec)) continue;
        std::string extension = entry.path().extension().string();
        std::transform(extension.begin(), extension.end(), extension.begin(),
            [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
        if (extension != ".btgraph") continue;

        EditorAssets::Asset graph;
        graph.relativePath = std::filesystem::relative(entry.path(), root, ec).string();
        if (ec) continue;
        std::replace(graph.relativePath.begin(), graph.relativePath.end(), '\\', '/');
        graph.displayName = entry.path().filename().string();
        graph.type = EditorAssets::Type::BehaviorGraph;
        graphs.push_back(std::move(graph));
    }

    std::sort(graphs.begin(), graphs.end(),
        [](const EditorAssets::Asset& a, const EditorAssets::Asset& b) {
            return a.relativePath < b.relativePath;
        });
    return graphs;
}

std::vector<EditorAssets::Asset> FindAudioAssets(const EditorAssets& assets) {
    std::vector<EditorAssets::Asset> audio;
    std::error_code ec;
    const std::filesystem::path root = assets.RootPath();
    if (!std::filesystem::exists(root, ec) || !std::filesystem::is_directory(root, ec)) return audio;
    for (const std::filesystem::directory_entry& entry : std::filesystem::recursive_directory_iterator(root, ec)) {
        if (ec) break;
        if (!entry.is_regular_file(ec)) continue;
        std::string extension = entry.path().extension().string();
        std::transform(extension.begin(), extension.end(), extension.begin(),
            [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
        if (extension != ".wav" && extension != ".flac" && extension != ".mp3" && extension != ".ogg") continue;
        EditorAssets::Asset asset;
        asset.relativePath = std::filesystem::relative(entry.path(), root, ec).string();
        if (ec) continue;
        std::replace(asset.relativePath.begin(), asset.relativePath.end(), '\\', '/');
        asset.displayName = entry.path().filename().string();
        asset.type = EditorAssets::Type::Audio;
        audio.push_back(std::move(asset));
    }
    std::sort(audio.begin(), audio.end(), [](const auto& a, const auto& b) {
        return a.relativePath < b.relativePath;
    });
    return audio;
}

bool IsEditableAudioPath(const std::string& path) {
    std::string extension = std::filesystem::path(path).extension().string();
    std::transform(extension.begin(), extension.end(), extension.begin(),
        [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return extension == ".wav" || extension == ".flac" || extension == ".mp3" || extension == ".ogg";
}

void SetAudioEditorOutputPath(const std::string& source) {
    const std::filesystem::path input(source);
    const std::filesystem::path output = input.parent_path() / (input.stem().string() + "_edited.wav");
    std::snprintf(g_audioEditor.outputPath.data(), g_audioEditor.outputPath.size(), "%s", output.string().c_str());
}

bool LoadAudioIntoEditor(const std::string& path, EditorLog* log) {
    engine::AudioBuffer decoded;
    std::string error;
    if (!engine::DecodeAudioFile(path, &decoded, &error)) {
        if (log) log->Error("Audio Editor: " + error + " " + path);
        return false;
    }
    g_audioEditor.buffer = std::move(decoded);
    g_audioEditor.original = g_audioEditor.buffer;
    g_audioEditor.undo = {};
    g_audioEditor.undoStack.clear();
    g_audioEditor.redoStack.clear();
    g_audioEditor.sourcePath = path;
    g_audioEditor.selectionStart = 0.0f;
    g_audioEditor.selectionEnd = g_audioEditor.buffer.DurationSeconds();
    g_audioEditor.dirty = false;
    SetAudioEditorOutputPath(path);
    if (log) log->Info("Audio Editor loaded: " + path);
    return true;
}

void PushAudioEditUndo() {
    g_audioEditor.undo = g_audioEditor.buffer;
    g_audioEditor.undoStack.push_back(g_audioEditor.buffer);
    if (g_audioEditor.undoStack.size() > 32) g_audioEditor.undoStack.erase(g_audioEditor.undoStack.begin());
    g_audioEditor.redoStack.clear();
    g_audioEditor.dirty = true;
}

std::pair<std::size_t, std::size_t> AudioSelectionFrames() {
    const engine::AudioBuffer& buffer = g_audioEditor.buffer;
    const std::size_t frames = buffer.FrameCount();
    const std::size_t begin = std::min(frames, static_cast<std::size_t>(
        std::max(g_audioEditor.selectionStart, 0.0f) * buffer.sampleRate));
    const std::size_t end = std::clamp(static_cast<std::size_t>(
        std::max(g_audioEditor.selectionEnd, 0.0f) * buffer.sampleRate), begin, frames);
    return {begin, end};
}

void DrawAudioWaveform(const engine::AudioBuffer& buffer) {
    const ImVec2 size(ImGui::GetContentRegionAvail().x, 190.0f);
    const ImVec2 origin = ImGui::GetCursorScreenPos();
    ImDrawList* draw = ImGui::GetWindowDrawList();
    draw->AddRectFilled(origin, ImVec2(origin.x + size.x, origin.y + size.y), IM_COL32(15, 18, 24, 255));
    draw->AddRect(origin, ImVec2(origin.x + size.x, origin.y + size.y), IM_COL32(65, 78, 96, 255));
    ImGui::InvisibleButton("##AudioWaveform", size);
    if (buffer.Empty() || size.x < 2.0f) return;

    const float duration = buffer.DurationSeconds();
    const float visibleDuration = duration / std::max(g_audioEditor.waveformZoom, 1.0f);
    const float visibleStart = std::clamp(g_audioEditor.waveformOffset, 0.0f,
        std::max(duration - visibleDuration, 0.0f));
    const float visibleEnd = visibleStart + visibleDuration;
    const auto timeToX = [&](float time) {
        return origin.x + size.x * ((time - visibleStart) / std::max(visibleDuration, 0.0001f));
    };
    const float selectedX0 = std::clamp(timeToX(g_audioEditor.selectionStart), origin.x, origin.x + size.x);
    const float selectedX1 = std::clamp(timeToX(g_audioEditor.selectionEnd), origin.x, origin.x + size.x);
    draw->AddRectFilled(ImVec2(selectedX0, origin.y), ImVec2(selectedX1, origin.y + size.y), IM_COL32(35, 92, 130, 65));
    const float centerY = origin.y + size.y * 0.5f;
    draw->AddLine(ImVec2(origin.x, centerY), ImVec2(origin.x + size.x, centerY), IM_COL32(70, 80, 92, 255));
    const std::size_t frames = buffer.FrameCount();
    const std::size_t visibleFrameStart = std::min(frames,
        static_cast<std::size_t>(visibleStart * buffer.sampleRate));
    const std::size_t visibleFrameEnd = std::min(frames,
        static_cast<std::size_t>(visibleEnd * buffer.sampleRate));
    const std::size_t visibleFrames = std::max<std::size_t>(visibleFrameEnd - visibleFrameStart, 1);
    const int columns = std::max(1, static_cast<int>(size.x));
    for (int x = 0; x < columns; ++x) {
        const std::size_t begin = visibleFrameStart
            + visibleFrames * static_cast<std::size_t>(x) / columns;
        const std::size_t end = std::max(begin + 1, visibleFrameStart
            + visibleFrames * static_cast<std::size_t>(x + 1) / columns);
        float minimum = 1.0f;
        float maximum = -1.0f;
        for (std::size_t frame = begin; frame < std::min(end, frames); ++frame) {
            for (std::uint32_t channel = 0; channel < buffer.channels; ++channel) {
                const float sample = buffer.samples[frame * buffer.channels + channel];
                minimum = std::min(minimum, sample);
                maximum = std::max(maximum, sample);
            }
        }
        draw->AddLine(ImVec2(origin.x + x, centerY - maximum * (size.y * 0.46f)),
            ImVec2(origin.x + x, centerY - minimum * (size.y * 0.46f)), IM_COL32(64, 205, 226, 255));
    }
    draw->AddLine(ImVec2(selectedX0, origin.y), ImVec2(selectedX0, origin.y + size.y), IM_COL32(255, 205, 80, 255), 2.0f);
    draw->AddLine(ImVec2(selectedX1, origin.y), ImVec2(selectedX1, origin.y + size.y), IM_COL32(255, 205, 80, 255), 2.0f);
    static float dragAnchor = 0.0f;
    if (ImGui::IsItemActivated()) {
        const float normalized = std::clamp((ImGui::GetIO().MousePos.x - origin.x) / size.x, 0.0f, 1.0f);
        dragAnchor = visibleStart + normalized * visibleDuration;
        g_audioEditor.selectionStart = dragAnchor;
        g_audioEditor.selectionEnd = dragAnchor;
    }
    if (ImGui::IsItemActive()) {
        const float normalized = std::clamp((ImGui::GetIO().MousePos.x - origin.x) / size.x, 0.0f, 1.0f);
        const float cursor = visibleStart + normalized * visibleDuration;
        g_audioEditor.selectionStart = std::min(dragAnchor, cursor);
        g_audioEditor.selectionEnd = std::max(dragAnchor, cursor);
    }
}

void GenerateAudioEditorClip() {
    constexpr std::uint32_t sampleRate = 44100;
    const float duration = std::clamp(g_audioEditor.generatorDuration, 0.05f, 30.0f);
    const std::size_t frames = static_cast<std::size_t>(duration * sampleRate);
    engine::AudioBuffer generated;
    generated.sampleRate = sampleRate;
    generated.channels = 1;
    generated.samples.resize(frames);
    std::uint32_t noise = 0x12345678u;
    for (std::size_t i = 0; i < frames; ++i) {
        const float phase = 6.28318530718f * g_audioEditor.generatorFrequency * static_cast<float>(i) / sampleRate;
        float sample = 0.0f;
        if (g_audioEditor.generator == 0) sample = std::sin(phase);
        else if (g_audioEditor.generator == 1) sample = std::sin(phase) >= 0.0f ? 1.0f : -1.0f;
        else {
            noise = noise * 1664525u + 1013904223u;
            sample = static_cast<float>((noise >> 8) & 0x00FFFFFFu) / 8388607.5f - 1.0f;
        }
        generated.samples[i] = sample * std::clamp(g_audioEditor.generatorAmplitude, 0.0f, 1.0f);
    }
    g_audioEditor.buffer = generated;
    g_audioEditor.original = generated;
    g_audioEditor.undo = {};
    g_audioEditor.undoStack.clear();
    g_audioEditor.redoStack.clear();
    g_audioEditor.sourcePath.clear();
    g_audioEditor.selectionStart = 0.0f;
    g_audioEditor.selectionEnd = duration;
    g_audioEditor.dirty = true;
}

void EnsureAudioAssetOutputPaths(EditorDockspace::Context& context) {
    if (g_audioEditor.cuePath[0] == '\0') {
        const std::filesystem::path root = context.assets
            ? std::filesystem::path(context.assets->RootPath()) : std::filesystem::path("Content");
        const std::string path = (root / "Audio" / "new_cue.3dgaudio").string();
        std::snprintf(g_audioEditor.cuePath.data(), g_audioEditor.cuePath.size(), "%s", path.c_str());
    }
    if (g_audioEditor.musicPath[0] == '\0') {
        const std::filesystem::path root = context.assets
            ? std::filesystem::path(context.assets->RootPath()) : std::filesystem::path("Content");
        const std::string path = (root / "Audio" / "adaptive_music.3dgmusic").string();
        std::snprintf(g_audioEditor.musicPath.data(), g_audioEditor.musicPath.size(), "%s", path.c_str());
    }
}

std::string SelectedAudioAssetPath(EditorDockspace::Context& context) {
    if (!context.assets) return {};
    const EditorAssets::Asset* selected = context.assets->SelectedAsset();
    const std::string path = context.assets->SelectedAssetFullPath();
    return selected && IsEditableAudioPath(path) ? path : std::string{};
}

void RefreshAudioAssets(EditorDockspace::Context& context) {
    if (!context.assets) return;
    std::string ignored;
    context.assets->Refresh(context.assets->RootPath(), &ignored);
}

void DrawAudioCueAuthoring(EditorDockspace::Context& context) {
    EnsureAudioAssetOutputPaths(context);
    engine::AudioCueAsset& cue = g_audioEditor.cue;
    if (!ImGui::CollapsingHeader("Gameplay Audio Cue", ImGuiTreeNodeFlags_DefaultOpen)) return;
    ImGui::TextDisabled("Reusable randomized, sequential, or layered gameplay sound.");
    const char* modes[] = {"Random", "Sequence", "Layered"};
    int mode = static_cast<int>(cue.mode);
    if (ImGui::Combo("Playback Mode", &mode, modes, 3))
        cue.mode = static_cast<engine::AudioCueMode>(mode);
    int bus = static_cast<int>(cue.bus);
    if (ImGui::BeginCombo("Cue Bus", engine::AudioBusName(cue.bus))) {
        for (int i = static_cast<int>(engine::AudioBus::Music);
             i <= static_cast<int>(engine::AudioBus::Ambient); ++i) {
            if (ImGui::Selectable(engine::AudioBusName(static_cast<engine::AudioBus>(i)), i == bus)) {
                bus = i;
                cue.bus = static_cast<engine::AudioBus>(i);
            }
        }
        ImGui::EndCombo();
    }
    ImGui::DragFloatRange2("Volume Variation", &cue.volumeMin, &cue.volumeMax,
        0.01f, 0.0f, 2.0f, "%.2f", "%.2f");
    ImGui::DragFloatRange2("Pitch Variation", &cue.pitchMin, &cue.pitchMax,
        0.01f, 0.1f, 4.0f, "%.2f", "%.2f");
    ImGui::DragFloat("Cooldown", &cue.cooldownSeconds, 0.01f, 0.0f, 60.0f, "%.2f s");
    ImGui::SliderInt("Max Instances", &cue.maxInstances, 1, 64);
    ImGui::SliderInt("Priority", &cue.priority, 0, 100);
    ImGui::Checkbox("Spatial Cue", &cue.spatial);
    ImGui::SameLine();
    ImGui::Checkbox("Avoid Immediate Repeat", &cue.noImmediateRepeat);

    if (ImGui::Button("Add Selected Audio Clip")) {
        const std::string path = SelectedAudioAssetPath(context);
        if (!path.empty()) {
            cue.clips.push_back({path});
            g_audioEditor.selectedCueClip = static_cast<int>(cue.clips.size()) - 1;
        } else if (context.log) {
            context.log->Warning("Audio Cue: select a WAV, FLAC, MP3, or OGG asset first");
        }
    }
    ImGui::SameLine();
    if (ImGui::Button("Remove Clip") && g_audioEditor.selectedCueClip >= 0
        && g_audioEditor.selectedCueClip < static_cast<int>(cue.clips.size())) {
        cue.clips.erase(cue.clips.begin() + g_audioEditor.selectedCueClip);
        g_audioEditor.selectedCueClip = std::min(g_audioEditor.selectedCueClip,
            static_cast<int>(cue.clips.size()) - 1);
    }
    ImGui::BeginChild("##CueClips", ImVec2(0.0f, 110.0f), true);
    for (std::size_t i = 0; i < cue.clips.size(); ++i) {
        const std::string label = std::to_string(i + 1) + ". "
            + std::filesystem::path(cue.clips[i].path).filename().string();
        if (ImGui::Selectable(label.c_str(), g_audioEditor.selectedCueClip == static_cast<int>(i)))
            g_audioEditor.selectedCueClip = static_cast<int>(i);
    }
    ImGui::EndChild();
    if (g_audioEditor.selectedCueClip >= 0
        && g_audioEditor.selectedCueClip < static_cast<int>(cue.clips.size())) {
        engine::AudioCueClip& clip = cue.clips[static_cast<std::size_t>(g_audioEditor.selectedCueClip)];
        ImGui::TextWrapped("%s", clip.path.c_str());
        ImGui::DragFloat("Weight", &clip.weight, 0.05f, 0.0f, 100.0f);
        ImGui::DragFloat("Clip Volume", &clip.volume, 0.01f, 0.0f, 4.0f);
        ImGui::DragFloat("Clip Pitch", &clip.pitch, 0.01f, 0.1f, 4.0f);
        ImGui::DragFloat("Layer Delay", &clip.delaySeconds, 0.01f, 0.0f, 30.0f, "%.2f s");
    }
    ImGui::InputText("Cue Asset", g_audioEditor.cuePath.data(), g_audioEditor.cuePath.size());
    if (ImGui::Button("Save Cue")) {
        std::string error;
        if (engine::SaveAudioCue(g_audioEditor.cuePath.data(), cue, &error)) {
            RefreshAudioAssets(context);
            if (context.log) context.log->Info("Saved audio cue: " + std::string(g_audioEditor.cuePath.data()));
        } else if (context.log) context.log->Error("Audio Cue: " + error);
    }
    ImGui::SameLine();
    if (ImGui::Button("Load Cue")) {
        std::string error;
        if (!engine::LoadAudioCue(g_audioEditor.cuePath.data(), &cue, &error)) {
            if (context.log) context.log->Error("Audio Cue: " + error);
        } else {
            g_audioEditor.selectedCueClip = cue.clips.empty() ? -1 : 0;
        }
    }
    ImGui::SameLine();
    if (ImGui::Button("Preview Cue")) {
        context.previewAudioRequested = true;
        context.previewAudioPath = g_audioEditor.cuePath.data();
        context.previewAudioSpatial = cue.spatial;
    }
}

void DrawAdaptiveMusicAuthoring(EditorDockspace::Context& context) {
    if (!ImGui::CollapsingHeader("Adaptive Music", ImGuiTreeNodeFlags_DefaultOpen)) return;
    engine::AdaptiveMusicAsset& music = g_audioEditor.music;
    if (ImGui::Button("Add Music State")) {
        engine::AdaptiveMusicState state;
        state.name = "State " + std::to_string(music.states.size() + 1);
        const std::string selected = SelectedAudioAssetPath(context);
        if (!selected.empty()) state.stems.push_back(selected);
        music.states.push_back(std::move(state));
        g_audioEditor.selectedMusicState = static_cast<int>(music.states.size()) - 1;
    }
    ImGui::SameLine();
    if (ImGui::Button("Remove State") && g_audioEditor.selectedMusicState >= 0
        && g_audioEditor.selectedMusicState < static_cast<int>(music.states.size())) {
        music.states.erase(music.states.begin() + g_audioEditor.selectedMusicState);
        g_audioEditor.selectedMusicState = std::min(g_audioEditor.selectedMusicState,
            static_cast<int>(music.states.size()) - 1);
    }
    if (ImGui::BeginCombo("Music State",
        g_audioEditor.selectedMusicState >= 0
            && g_audioEditor.selectedMusicState < static_cast<int>(music.states.size())
        ? music.states[static_cast<std::size_t>(g_audioEditor.selectedMusicState)].name.c_str()
        : "Select state...")) {
        for (std::size_t i = 0; i < music.states.size(); ++i)
            if (ImGui::Selectable(music.states[i].name.c_str(),
                    g_audioEditor.selectedMusicState == static_cast<int>(i)))
                g_audioEditor.selectedMusicState = static_cast<int>(i);
        ImGui::EndCombo();
    }
    if (g_audioEditor.selectedMusicState >= 0
        && g_audioEditor.selectedMusicState < static_cast<int>(music.states.size())) {
        auto& state = music.states[static_cast<std::size_t>(g_audioEditor.selectedMusicState)];
        ImGui::DragFloat("BPM", &state.bpm, 0.5f, 1.0f, 400.0f);
        ImGui::SliderFloat("Music Volume", &state.volume, 0.0f, 2.0f);
        ImGui::DragFloat("Crossfade", &state.crossfadeSeconds, 0.05f, 0.0f, 30.0f, "%.2f s");
        if (ImGui::Button("Add Selected Stem")) {
            const std::string selected = SelectedAudioAssetPath(context);
            if (!selected.empty()) state.stems.push_back(selected);
        }
        for (std::size_t i = 0; i < state.stems.size(); ++i)
            ImGui::BulletText("%s", std::filesystem::path(state.stems[i]).filename().string().c_str());
    }
    ImGui::InputText("Music Asset", g_audioEditor.musicPath.data(), g_audioEditor.musicPath.size());
    if (ImGui::Button("Save Adaptive Music")) {
        std::string error;
        if (engine::SaveAdaptiveMusic(g_audioEditor.musicPath.data(), music, &error))
            RefreshAudioAssets(context);
        else if (context.log) context.log->Error("Adaptive Music: " + error);
    }
    ImGui::SameLine();
    if (ImGui::Button("Load Adaptive Music")) {
        std::string error;
        if (!engine::LoadAdaptiveMusic(g_audioEditor.musicPath.data(), &music, &error)) {
            if (context.log) context.log->Error("Adaptive Music: " + error);
        } else {
            g_audioEditor.selectedMusicState = music.states.empty() ? -1 : 0;
        }
    }
}

ImVec4 LogColor(EditorLog::Level level) {
    switch (level) {
    case EditorLog::Level::Info: return ImVec4(0.78f, 0.84f, 0.92f, 1.0f);
    case EditorLog::Level::Warning: return ImVec4(1.0f, 0.78f, 0.30f, 1.0f);
    case EditorLog::Level::Error: return ImVec4(1.0f, 0.34f, 0.32f, 1.0f);
    }
    return ImVec4(0.78f, 0.84f, 0.92f, 1.0f);
}

void DrawWorldSettings(EditorScene& scene, EditorDockspace::Context& context, bool* open) {
    if (!ImGui::Begin(EditorPanels::Name(EditorPanels::Panel::WorldSettings), open)) {
        ImGui::End();
        return;
    }

    EditorScene::Environment environment = scene.GetEnvironment();
    const EditorScene::Environment defaults{};
    bool changed = false;

    if (ImGui::CollapsingHeader("Presets", ImGuiTreeNodeFlags_DefaultOpen)) {
        if (ImGui::Button("Day")) {
            environment.timeOfDay = 0.50f;
            environment.skyLightIntensity = 1.0f;
            environment.driveSunLight = true;
            environment.sunIntensity = 1.0f;
            environment.fog = false;
            changed = true;
        }
        ImGui::SameLine();
        if (ImGui::Button("Night")) {
            environment.timeOfDay = 0.0f;
            environment.skyLightIntensity = 0.25f;
            environment.driveSunLight = true;
            environment.sunIntensity = 0.45f;
            environment.fog = false;
            changed = true;
        }
        ImGui::SameLine();
        if (ImGui::Button("Sunset")) {
            environment.timeOfDay = 0.75f;
            environment.skyLightIntensity = 0.8f;
            environment.driveSunLight = true;
            environment.sunIntensity = 1.2f;
            environment.fog = true;
            environment.fogColor = glm::vec3(0.95f, 0.54f, 0.34f);
            environment.fogDensity = 0.006f;
            environment.fogHeight = -0.25f;
            environment.fogHeightFalloff = 0.08f;
            changed = true;
        }
        ImGui::SameLine();
        if (ImGui::Button("Foggy")) {
            environment.skyLightIntensity = 0.7f;
            environment.fog = true;
            environment.fogColor = glm::vec3(0.55f, 0.62f, 0.68f);
            environment.fogDensity = 0.026f;
            environment.fogHeight = -0.10f;
            environment.fogHeightFalloff = 0.18f;
            changed = true;
        }
    }

    if (ImGui::CollapsingHeader("Sky", ImGuiTreeNodeFlags_DefaultOpen)) {
        int mode = environment.skyMode;
        const char* modes[] = {"Procedural Atmosphere", "Imported Sky"};
        if (ImGui::Combo("Sky Source", &mode, modes, 2) && mode != environment.skyMode) {
            environment.skyMode = mode;
            changed = true;
        }
        if (environment.skyMode == 1) {
            ImGui::TextWrapped("Image: %s", environment.skyTexturePath.empty()
                ? "(none)" : environment.skyTexturePath.c_str());
            if (ImGui::Button("Import PNG...")) {
                const std::string picked = editor::OpenFileDialog(
                    "Choose an equirectangular sky", "Panorama PNG", "png");
                if (!picked.empty()) { environment.skyTexturePath = picked; changed = true; }
            }
            ImGui::SameLine();
            if (ImGui::Button("Import JPG...")) {
                const std::string picked = editor::OpenFileDialog(
                    "Choose an equirectangular sky", "Panorama JPEG", "jpg");
                if (!picked.empty()) { environment.skyTexturePath = picked; changed = true; }
            }
            if (!environment.skyTexturePath.empty()) {
                ImGui::SameLine();
                if (ImGui::Button("Clear")) { environment.skyTexturePath.clear(); changed = true; }
            }
            changed |= ImGui::SliderFloat("Sky Rotation", &environment.skyRotation,
                                          0.0f, 360.0f, "%.0f deg");
            changed |= ImGui::DragFloat("Sky Brightness", &environment.skyIntensity,
                                        0.02f, 0.0f, 8.0f, "%.2f");
            ImGui::TextDisabled("A 360 equirectangular panorama (marketplace sky). Also "
                                "lights the scene via IBL. .hdr not yet supported.");
        } else {
            ImGui::TextDisabled("Procedural atmosphere — edit Time of Day, Clouds and Fog below.");
        }
    }

    if (ImGui::CollapsingHeader("Lighting", ImGuiTreeNodeFlags_DefaultOpen)) {
        if (ImGui::SmallButton("Reset Lighting")) {
            environment.timeOfDay = defaults.timeOfDay;
            environment.skyLightIntensity = defaults.skyLightIntensity;
            environment.skylightOcclusion = defaults.skylightOcclusion;
            environment.skylightOcclusionStrength = defaults.skylightOcclusionStrength;
            environment.minimumSkylight = defaults.minimumSkylight;
            environment.driveSunLight = defaults.driveSunLight;
            environment.sunIntensity = defaults.sunIntensity;
            changed = true;
        }
        changed |= ImGui::SliderFloat("Time Of Day", &environment.timeOfDay, 0.0f, 1.0f);
        changed |= ImGui::DragFloat("Sky Light", &environment.skyLightIntensity, 0.02f, 0.0f, 8.0f);
        changed |= ImGui::Checkbox("Skylight Occlusion (Indoor Darkness)", &environment.skylightOcclusion);
        if (!environment.skylightOcclusion) ImGui::BeginDisabled();
        changed |= ImGui::SliderFloat("Indoor Occlusion Strength", &environment.skylightOcclusionStrength, 0.0f, 1.0f, "%.2f");
        changed |= ImGui::SliderFloat("Minimum Indoor Skylight", &environment.minimumSkylight, 0.0f, 1.0f, "%.2f");
        if (!environment.skylightOcclusion) ImGui::EndDisabled();
        ImGui::TextDisabled("Uses dynamic sun-shadow visibility to block sky/IBL inside enclosed spaces.");
        changed |= ImGui::Checkbox("Time Sun", &environment.driveSunLight);
        changed |= ImGui::DragFloat("Sun Intensity", &environment.sunIntensity, 0.02f, 0.0f, 8.0f);
    }

    if (ImGui::CollapsingHeader("Clouds", ImGuiTreeNodeFlags_DefaultOpen)) {
        const char* toggleLabel = environment.clouds ? "Clouds: On" : "Clouds: Off";
        if (ImGui::Button(toggleLabel, ImVec2(110.0f, 0.0f))) {
            environment.clouds = !environment.clouds;
            changed = true;
        }
        ImGui::SameLine();
        if (ImGui::SmallButton("Reset Clouds")) {
            environment.clouds = defaults.clouds;
            environment.cloudCoverage = defaults.cloudCoverage;
            environment.cloudDensity = defaults.cloudDensity;
            environment.cloudScale = defaults.cloudScale;
            environment.cloudSoftness = defaults.cloudSoftness;
            environment.cloudWindSpeed = defaults.cloudWindSpeed;
            environment.cloudWindDirection = defaults.cloudWindDirection;
            environment.cloudHorizonHeight = defaults.cloudHorizonHeight;
            environment.cloudColor = defaults.cloudColor;
            environment.cloudShadows = defaults.cloudShadows;
            environment.cloudShadowStrength = defaults.cloudShadowStrength;
            environment.cloudShadowScale = defaults.cloudShadowScale;
            changed = true;
        }

        if (!environment.clouds) ImGui::BeginDisabled();
        if (ImGui::SmallButton("Clear")) {
            environment.cloudCoverage = 0.82f;
            environment.cloudDensity = 0.20f;
            changed = true;
        }
        ImGui::SameLine();
        if (ImGui::SmallButton("Scattered")) {
            environment.cloudCoverage = 0.45f;
            environment.cloudDensity = 0.75f;
            changed = true;
        }
        ImGui::SameLine();
        if (ImGui::SmallButton("Overcast")) {
            environment.cloudCoverage = 0.27f;
            environment.cloudDensity = 1.25f;
            environment.cloudSoftness = 0.22f;
            changed = true;
        }
        changed |= ImGui::SliderFloat("Coverage", &environment.cloudCoverage, 0.05f, 0.95f, "%.2f");
        if (ImGui::IsItemHovered())
            ImGui::SetTooltip("Lower values create more cloud cover; higher values clear the sky.");
        changed |= ImGui::SliderFloat("Density", &environment.cloudDensity, 0.0f, 2.0f, "%.2f");
        changed |= ImGui::SliderFloat("Cloud Scale", &environment.cloudScale, 0.10f, 6.0f, "%.2f");
        changed |= ImGui::SliderFloat("Edge Softness", &environment.cloudSoftness, 0.01f, 0.45f, "%.2f");
        changed |= ImGui::SliderFloat("Wind Speed", &environment.cloudWindSpeed, -0.25f, 0.25f, "%.3f");
        changed |= ImGui::SliderFloat("Wind Direction", &environment.cloudWindDirection, -180.0f, 180.0f, "%.0f deg");
        changed |= ImGui::SliderFloat("Horizon Height", &environment.cloudHorizonHeight, 0.005f, 0.50f, "%.3f");
        changed |= ImGui::ColorEdit3("Cloud Tint", &environment.cloudColor.x);
        ImGui::Separator();
        changed |= ImGui::Checkbox("Cast Cloud Shadows", &environment.cloudShadows);
        if (!environment.cloudShadows) ImGui::BeginDisabled();
        changed |= ImGui::SliderFloat("Shadow Strength", &environment.cloudShadowStrength, 0.0f, 1.0f, "%.2f");
        changed |= ImGui::SliderFloat("Shadow World Scale", &environment.cloudShadowScale, 0.002f, 0.15f, "%.3f");
        if (ImGui::IsItemHovered())
            ImGui::SetTooltip("Controls the size of moving cloud shadows across the world.");
        if (!environment.cloudShadows) ImGui::EndDisabled();
        if (!environment.clouds) ImGui::EndDisabled();
    }

    if (ImGui::CollapsingHeader("Render Features", ImGuiTreeNodeFlags_DefaultOpen)) {
        if (ImGui::SmallButton("Reset Render Features")) {
            environment.ibl = defaults.ibl;
            environment.ssao = defaults.ssao;
            environment.ssaoRadius = defaults.ssaoRadius;
            environment.ssaoBias = defaults.ssaoBias;
            environment.ssr = defaults.ssr;
            environment.ssrIntensity = defaults.ssrIntensity;
            environment.msaa = defaults.msaa;
            environment.fxaa = defaults.fxaa;
            environment.renderScale = defaults.renderScale;
            changed = true;
        }
        changed |= ImGui::Checkbox("IBL", &environment.ibl);
        changed |= ImGui::Checkbox("SSAO", &environment.ssao);
        changed |= ImGui::DragFloat("SSAO Radius", &environment.ssaoRadius, 0.01f, 0.05f, 5.0f, "%.2f");
        changed |= ImGui::DragFloat("SSAO Bias", &environment.ssaoBias, 0.001f, 0.0f, 0.2f, "%.3f");
        changed |= ImGui::Checkbox("SSR", &environment.ssr);
        changed |= ImGui::DragFloat("SSR Intensity", &environment.ssrIntensity, 0.01f, 0.0f, 2.0f, "%.2f");
        ImGui::Separator();
        ImGui::TextUnformatted("Anti-aliasing");
        changed |= ImGui::Checkbox("MSAA (4x, direct view)", &environment.msaa);
        if (ImGui::IsItemHovered()) {
            ImGui::SetTooltip("Multisample AA on the main view. Active when SSR is off.");
        }
        changed |= ImGui::Checkbox("FXAA (post, SSR view)", &environment.fxaa);
        if (ImGui::IsItemHovered()) {
            ImGui::SetTooltip("Post-process edge AA. Active when SSR is on.");
        }
        changed |= ImGui::SliderFloat("Render Scale", &environment.renderScale, 0.25f, 1.0f, "%.2fx");
        if (ImGui::IsItemHovered()) {
            ImGui::SetTooltip("Render the 3D scene at this fraction of window resolution, then "
                              "upscale. Cuts fill-rate GPU cost. Ignored while SSR or SSAO is on.");
        }
        ImGui::Separator();
        ImGui::TextUnformatted("Display");
        if (ImGui::Checkbox("VSync", &context.vsync)) {
            context.vsyncChangeRequested = true;   // applied by the app (window setting)
        }
        if (ImGui::IsItemHovered()) {
            ImGui::SetTooltip("Cap the frame rate to the monitor refresh. Off = uncapped (see Profiler).");
        }
    }

    if (ImGui::CollapsingHeader(
            "Post Process Shader Stack", ImGuiTreeNodeFlags_DefaultOpen)) {
        const EditorAssets::Asset* selected =
            context.assets ? context.assets->SelectedAsset() : nullptr;
        const bool selectedShader =
            selected && selected->type == EditorAssets::Type::Shader;
        if (!selectedShader) ImGui::BeginDisabled();
        if (ImGui::Button("Add Selected Shader") && context.assets) {
            const std::string path = context.assets->SelectedAssetFullPath();
            engine::ShaderAsset shader;
            std::string loadError;
            if (!engine::LoadShaderAsset(path, &shader, &loadError)) {
                if (context.log)
                    context.log->Error("Post Process: " + loadError);
            } else if (shader.domain != engine::ShaderDomain::PostProcess) {
                if (context.log)
                    context.log->Warning(
                        "Only Post Process shader assets can be added to this stack.");
            } else {
                EditorScene::Environment::PostProcessEffect effect;
                effect.shaderPath = path;
                effect.shaderAssetId = shader.assetId;
                for (const engine::ShaderParameter& reflected :
                     shader.parameters) {
                    effect.parameters.push_back({
                        reflected.name,
                        static_cast<int>(reflected.type),
                        reflected.defaultValue
                    });
                }
                environment.postProcessEffects.push_back(std::move(effect));
                changed = true;
            }
        }
        if (!selectedShader) ImGui::EndDisabled();
        ImGui::SameLine();
        ImGui::TextDisabled("Effects run top to bottom before bloom and tone mapping.");

        int moveFrom = -1;
        int moveTo = -1;
        int remove = -1;
        for (std::size_t i = 0; i < environment.postProcessEffects.size(); ++i) {
            auto& effect = environment.postProcessEffects[i];
            ImGui::PushID(static_cast<int>(i));
            const std::string label =
                std::to_string(i + 1) + ". "
                + std::filesystem::path(effect.shaderPath).filename().string();
            const bool expanded = ImGui::TreeNodeEx(
                "Effect", ImGuiTreeNodeFlags_DefaultOpen, "%s", label.c_str());
            ImGui::SameLine();
            changed |= ImGui::Checkbox("Enabled", &effect.enabled);
            ImGui::SameLine();
            if (ImGui::SmallButton("Up") && i > 0) {
                moveFrom = static_cast<int>(i);
                moveTo = static_cast<int>(i - 1);
            }
            ImGui::SameLine();
            if (ImGui::SmallButton("Down")
                && i + 1 < environment.postProcessEffects.size()) {
                moveFrom = static_cast<int>(i);
                moveTo = static_cast<int>(i + 1);
            }
            ImGui::SameLine();
            if (ImGui::SmallButton("Remove"))
                remove = static_cast<int>(i);
            if (expanded) {
                ImGui::TextDisabled("%s", effect.shaderPath.c_str());
                for (auto& parameter : effect.parameters) {
                    ImGui::PushID(parameter.name.c_str());
                    if (parameter.type
                        == static_cast<int>(engine::ShaderValueType::Bool)) {
                        bool value = parameter.value == "true"
                            || parameter.value == "1";
                        if (ImGui::Checkbox(parameter.name.c_str(), &value)) {
                            parameter.value = value ? "true" : "false";
                            changed = true;
                        }
                    } else if (parameter.type
                               == static_cast<int>(
                                   engine::ShaderValueType::Float)) {
                        float value = std::strtof(
                            parameter.value.c_str(), nullptr);
                        if (ImGui::DragFloat(
                                parameter.name.c_str(), &value, 0.01f)) {
                            parameter.value = std::to_string(value);
                            changed = true;
                        }
                    } else {
                        std::array<char, 384> value{};
                        std::snprintf(
                            value.data(), value.size(), "%s",
                            parameter.value.c_str());
                        if (ImGui::InputText(
                                parameter.name.c_str(), value.data(),
                                value.size())) {
                            parameter.value = value.data();
                            changed = true;
                        }
                    }
                    ImGui::PopID();
                }
                ImGui::TreePop();
            }
            ImGui::PopID();
        }
        if (moveFrom >= 0 && moveTo >= 0) {
            std::swap(environment.postProcessEffects[
                          static_cast<std::size_t>(moveFrom)],
                      environment.postProcessEffects[
                          static_cast<std::size_t>(moveTo)]);
            changed = true;
        }
        if (remove >= 0) {
            environment.postProcessEffects.erase(
                environment.postProcessEffects.begin() + remove);
            changed = true;
        }
    }

    if (ImGui::CollapsingHeader("Shadows", ImGuiTreeNodeFlags_DefaultOpen)) {
        if (ImGui::SmallButton("Reset Shadows")) {
            environment.directionalShadows = defaults.directionalShadows;
            environment.pointShadows = defaults.pointShadows;
            environment.spotShadows = defaults.spotShadows;
            environment.shadowSoftness = defaults.shadowSoftness;
            environment.shadowDistance = defaults.shadowDistance;
            changed = true;
        }
        changed |= ImGui::Checkbox("Sun Shadows", &environment.directionalShadows);
        changed |= ImGui::Checkbox("Point Shadows", &environment.pointShadows);
        changed |= ImGui::Checkbox("Spot Shadows", &environment.spotShadows);
        changed |= ImGui::DragFloat("Shadow Softness", &environment.shadowSoftness, 0.05f, 0.1f, 12.0f, "%.2f");
        changed |= ImGui::DragFloat("Shadow Visibility Distance", &environment.shadowDistance,
                                    5.0f, 10.0f, 5000.0f, "%.0f units");
        if (ImGui::IsItemHovered()) {
            ImGui::SetTooltip("How far sun shadows remain visible from the camera. Larger values cover more world space but reduce shadow detail.");
        }
    }

    if (ImGui::CollapsingHeader("Atmosphere", ImGuiTreeNodeFlags_DefaultOpen)) {
        if (ImGui::SmallButton("Reset Atmosphere")) {
            environment.fog = defaults.fog;
            environment.fogColor = defaults.fogColor;
            environment.fogDensity = defaults.fogDensity;
            environment.fogHeight = defaults.fogHeight;
            environment.fogHeightFalloff = defaults.fogHeightFalloff;
            changed = true;
        }
        changed |= ImGui::Checkbox("Atmosphere Fog", &environment.fog);
        changed |= ImGui::ColorEdit3("Fog Color", &environment.fogColor.x);
        changed |= ImGui::DragFloat("Fog Density", &environment.fogDensity, 0.001f, 0.0f, 0.20f, "%.4f");
        changed |= ImGui::DragFloat("Fog Height", &environment.fogHeight, 0.02f, -20.0f, 20.0f);
        changed |= ImGui::DragFloat("Fog Falloff", &environment.fogHeightFalloff, 0.005f, 0.001f, 2.0f, "%.3f");
    }

    if (ImGui::CollapsingHeader("Physics", ImGuiTreeNodeFlags_DefaultOpen)) {
        if (ImGui::SmallButton("Reset Physics")) {
            environment.physicsGravity = defaults.physicsGravity;
            environment.physicsSolverIterations = defaults.physicsSolverIterations;
            environment.physicsBroadPhase = defaults.physicsBroadPhase;
            environment.physicsCellSize = defaults.physicsCellSize;
            environment.physicsRestitutionThreshold = defaults.physicsRestitutionThreshold;
            environment.physicsAllowSleeping = defaults.physicsAllowSleeping;
            environment.physicsSleepLinearVelocity = defaults.physicsSleepLinearVelocity;
            environment.physicsSleepAngularVelocity = defaults.physicsSleepAngularVelocity;
            environment.physicsTimeToSleep = defaults.physicsTimeToSleep;
            changed = true;
        }
        changed |= ImGui::DragFloat3("Gravity", &environment.physicsGravity.x, 0.05f);
        changed |= ImGui::DragInt("Solver Iterations", &environment.physicsSolverIterations, 1.0f, 1, 32);
        changed |= ImGui::Checkbox("Broad Phase", &environment.physicsBroadPhase);
        changed |= ImGui::DragFloat("Cell Size", &environment.physicsCellSize, 0.05f, 0.1f, 100.0f, "%.2f");
        changed |= ImGui::DragFloat("Bounce Threshold", &environment.physicsRestitutionThreshold, 0.02f, 0.0f, 10.0f, "%.2f");
        changed |= ImGui::Checkbox("Allow Sleeping", &environment.physicsAllowSleeping);
        changed |= ImGui::DragFloat("Sleep Linear Velocity", &environment.physicsSleepLinearVelocity, 0.005f, 0.0f, 10.0f, "%.3f");
        changed |= ImGui::DragFloat("Sleep Angular Velocity", &environment.physicsSleepAngularVelocity, 0.005f, 0.0f, 10.0f, "%.3f");
        changed |= ImGui::DragFloat("Sleep Time", &environment.physicsTimeToSleep, 0.02f, 0.0f, 10.0f, "%.2f");
    }

    if (ImGui::CollapsingHeader("Editor Guides")) {
        if (ImGui::SmallButton("Reset Guides")) {
            environment.showLightGuides = defaults.showLightGuides;
            environment.selectedLightGuideOnly = defaults.selectedLightGuideOnly;
            environment.showPhysicsGuides = defaults.showPhysicsGuides;
            environment.selectedPhysicsGuideOnly = defaults.selectedPhysicsGuideOnly;
            changed = true;
        }
        changed |= ImGui::Checkbox("Light Guides", &environment.showLightGuides);
        changed |= ImGui::Checkbox("Selected Guide Only", &environment.selectedLightGuideOnly);
        changed |= ImGui::Checkbox("Collider Guides (Edit Mode)", &environment.showPhysicsGuides);
        changed |= ImGui::Checkbox("Selected Physics Only", &environment.selectedPhysicsGuideOnly);
    }

    if (changed) {
        scene.SetEnvironment(environment);
    }

    ImGui::End();
}

void DrawGameModeSettings(EditorScene& scene, bool* open) {
    if (!ImGui::Begin(
            EditorPanels::Name(EditorPanels::Panel::GameModeSettings), open)) {
        ImGui::End();
        return;
    }

    EditorScene::GameModeSettings settings = scene.GetGameModeSettings();
    bool changed = false;

    if (ImGui::CollapsingHeader("Player", ImGuiTreeNodeFlags_DefaultOpen)) {
        const char* playerPreview = settings.playerObjectName.empty()
            ? "First Player Controller in scene"
            : settings.playerObjectName.c_str();
        if (ImGui::BeginCombo("Player Object", playerPreview)) {
            const bool automatic = settings.playerObjectName.empty();
            if (ImGui::Selectable(
                    "First Player Controller in scene", automatic)) {
                settings.playerObjectName.clear();
                changed = true;
            }
            for (const EditorScene::Object& object : scene.Objects()) {
                if (!object.playerControllerEnabled) {
                    continue;
                }
                const bool selected = settings.playerObjectName == object.name;
                if (ImGui::Selectable(object.name.c_str(), selected)) {
                    settings.playerObjectName = object.name;
                    changed = true;
                }
            }
            ImGui::EndCombo();
        }
        changed |= ImGui::Checkbox(
            "Enable Player Input", &settings.playerInputEnabled);
        ImGui::TextDisabled(
            "The selected object supplies movement, collision, and camera tuning.");
    }

    if (ImGui::CollapsingHeader("Game Rules", ImGuiTreeNodeFlags_DefaultOpen)) {
        changed |= ImGui::Checkbox("Start Paused", &settings.startPaused);
        changed |= ImGui::Checkbox("Allow Pause", &settings.allowPause);
        changed |= ImGui::Checkbox("Allow Restart", &settings.allowRestart);
        changed |= ImGui::Checkbox(
            "Lose When Player Dies", &settings.loseOnPlayerDeath);
        changed |= ImGui::DragInt(
            "Initial Score", &settings.initialScore, 1.0f, 0, 1000000);
    }

    if (ImGui::CollapsingHeader(
            "Camera Override", ImGuiTreeNodeFlags_DefaultOpen)) {
        changed |= ImGui::Checkbox(
            "Override Player Camera", &settings.cameraOverride);
        ImGui::BeginDisabled(!settings.cameraOverride);
        static constexpr const char* kCameraModes[] = {
            "Third Person", "First Person", "Isometric", "Platformer"
        };
        settings.cameraMode = std::clamp(settings.cameraMode, 0, 3);
        changed |= ImGui::Combo(
            "Camera Mode", &settings.cameraMode, kCameraModes,
            static_cast<int>(std::size(kCameraModes)));
        ImGui::EndDisabled();
        ImGui::TextWrapped(
            "Camera mode is fixed when Play begins. Gameplay input cannot switch it.");
    }

    if (ImGui::CollapsingHeader("Game UI")) {
        EditorScene::Environment environment = scene.GetEnvironment();
        char hudAsset[512]{};
        std::snprintf(
            hudAsset, sizeof(hudAsset), "%s", environment.hudAsset.c_str());
        if (ImGui::InputText("HUD Asset", hudAsset, sizeof(hudAsset))) {
            environment.hudAsset = hudAsset;
            scene.SetEnvironment(environment);
        }
        ImGui::TextDisabled("Optional .hud asset loaded when Play begins.");
    }

    if (changed) {
        scene.SetGameModeSettings(settings);
    }

    ImGui::End();
}

void DrawPhysicsStatus(EditorDockspace::Context& context, bool* open) {
    if (!ImGui::Begin(EditorPanels::Name(EditorPanels::Panel::PhysicsStatus), open)) {
        ImGui::End();
        return;
    }

    if (!context.scene) {
        ImGui::TextUnformatted("Scene unavailable.");
        ImGui::End();
        return;
    }

    const EditorScene::Environment& environment = context.scene->GetEnvironment();
    const ScenePhysicsStatus status = CollectScenePhysicsStatus(*context.scene);

    if (ImGui::Button("Validate Runtime")) {
        context.validateRuntimeRequested = true;
    }
    ImGui::SameLine();
    if (context.playMode) {
        ImGui::TextUnformatted("Mode: Play");
    } else {
        ImGui::TextUnformatted("Mode: Edit");
    }

    if (context.playMode) {
        if (ImGui::Button(context.physicsPaused ? "Resume Physics" : "Pause Physics")) {
            context.physicsPauseToggleRequested = true;
        }
        ImGui::SameLine();
        if (ImGui::Button("Step Physics")) {
            context.physicsStepRequested = true;
        }
    } else {
        ImGui::TextUnformatted("Physics playback controls are available in Play mode.");
    }

    ImGui::Text("Fixed Step: %.4f s (%.1f Hz)",
        context.physicsFixedTimestep,
        context.physicsFixedTimestep > 0.0f ? 1.0f / context.physicsFixedTimestep : 0.0f);
    ImGui::Text("Accumulator: %.4f s", context.physicsAccumulator);
    ImGui::Text("Steps Last Frame: %d", context.physicsStepsLastFrame);
    ImGui::Text("Events: %d enter, %d stay, %d exit",
        context.physicsEventEnterCount,
        context.physicsEventStayCount,
        context.physicsEventExitCount,
        context.physicsActionCount);

    if (ImGui::CollapsingHeader("World Physics", ImGuiTreeNodeFlags_DefaultOpen)) {
        if (ImGui::BeginTable("PhysicsWorldStatus", 2, ImGuiTableFlags_BordersInnerV)) {
            ImGui::TableNextRow();
            ImGui::TableNextColumn();
            ImGui::TextUnformatted("Gravity");
            ImGui::TableNextColumn();
            ImGui::Text("%.2f, %.2f, %.2f",
                environment.physicsGravity.x,
                environment.physicsGravity.y,
                environment.physicsGravity.z);

            ImGui::TableNextRow();
            ImGui::TableNextColumn();
            ImGui::TextUnformatted("Solver Iterations");
            ImGui::TableNextColumn();
            ImGui::Text("%d", environment.physicsSolverIterations);

            ImGui::TableNextRow();
            ImGui::TableNextColumn();
            ImGui::TextUnformatted("Broad Phase");
            ImGui::TableNextColumn();
            ImGui::TextUnformatted(environment.physicsBroadPhase ? "On" : "Off");

            ImGui::TableNextRow();
            ImGui::TableNextColumn();
            ImGui::TextUnformatted("Cell Size");
            ImGui::TableNextColumn();
            ImGui::Text("%.2f", environment.physicsCellSize);

            ImGui::TableNextRow();
            ImGui::TableNextColumn();
            ImGui::TextUnformatted("Sleeping");
            ImGui::TableNextColumn();
            ImGui::TextUnformatted(environment.physicsAllowSleeping ? "On" : "Off");

            ImGui::TableNextRow();
            ImGui::TableNextColumn();
            ImGui::TextUnformatted("Sleep Linear");
            ImGui::TableNextColumn();
            ImGui::Text("%.3f", environment.physicsSleepLinearVelocity);

            ImGui::TableNextRow();
            ImGui::TableNextColumn();
            ImGui::TextUnformatted("Sleep Angular");
            ImGui::TableNextColumn();
            ImGui::Text("%.3f", environment.physicsSleepAngularVelocity);
            ImGui::EndTable();
        }
    }

    if (ImGui::CollapsingHeader("Scene Physics", ImGuiTreeNodeFlags_DefaultOpen)) {
        if (ImGui::BeginTable("PhysicsSceneStatus", 2, ImGuiTableFlags_BordersInnerV)) {
            DrawStatusRow("Objects", status.objects);
            DrawStatusRow("Rigid Bodies", status.rigidBodies);
            DrawStatusRow("Dynamic Bodies", status.dynamicBodies);
            DrawStatusRow("Static Bodies", status.staticBodies);
            DrawStatusRow("Colliders", status.colliders);
            DrawStatusRow("Static Colliders", status.staticColliders);
            DrawStatusRow("Triggers", status.triggers);
            DrawStatusRow("Sphere Colliders", status.spheres);
            DrawStatusRow("Box Colliders", status.boxes);
            DrawStatusRow("Plane Colliders", status.planes);
            DrawStatusRow("Capsule Colliders", status.capsules);
            DrawStatusRow("Cylinder Colliders", status.cylinders);
            DrawStatusRow("Cone Colliders", status.cones);
            DrawStatusRow("Pyramid Colliders", status.pyramids);
            DrawStatusRow("Torus Colliders", status.toruses);
            DrawStatusRow("Stair Colliders", status.staircases);
            DrawStatusRow("Joints", status.joints);
            ImGui::EndTable();
        }
    }

    if (ImGui::CollapsingHeader("Selected Object", ImGuiTreeNodeFlags_DefaultOpen)) {
        const EditorScene::Object* selected = context.scene->SelectedObject();
        if (!selected) {
            ImGui::TextUnformatted("No object selected.");
        } else {
            ImGui::Text("Name: %s", selected->name.c_str());
            ImGui::Text("Type: %s", ObjectTypeName(*selected));
            ImGui::Text("Rigid Body: %s", selected->rigidBodyEnabled ? "Enabled" : "Disabled");
            if (selected->rigidBodyEnabled) {
                const bool dynamic = selected->rigidBody.invMass > 0.0f;
                ImGui::Text("Mode: %s", dynamic ? "Dynamic" : "Static");
                if (dynamic) {
                    ImGui::Text("Mass: %.3f", 1.0f / selected->rigidBody.invMass);
                }
                ImGui::Text("Velocity: %.3f, %.3f, %.3f",
                    selected->rigidBody.velocity.x,
                    selected->rigidBody.velocity.y,
                    selected->rigidBody.velocity.z);
                ImGui::Text("Gravity: %s", selected->rigidBody.useGravity ? "On" : "Off");
                ImGui::Text("CCD: %s", selected->rigidBody.ccd ? "On" : "Off");
                ImGui::Text("Freeze Rotation: %s", selected->rigidBody.freezeRotation ? "On" : "Off");
                ImGui::Text("Sleep: %s", selected->rigidBody.allowSleep ? "Allowed" : "Blocked");
            }

            ImGui::Separator();
            ImGui::Text("Collider: %s", selected->colliderEnabled ? "Enabled" : "Disabled");
            if (selected->colliderEnabled) {
                ImGui::Text("Shape: %s", ColliderShapeName(selected->collider.shape));
                if (selected->collider.shape == engine::ecs::ColliderShape::Sphere) {
                    ImGui::Text("Radius: %.3f", selected->collider.radius);
                } else if (selected->collider.shape == engine::ecs::ColliderShape::Box
                    || selected->collider.shape == engine::ecs::ColliderShape::Pyramid
                    || selected->collider.shape == engine::ecs::ColliderShape::Staircase) {
                    ImGui::Text("Half Extents: %.3f, %.3f, %.3f",
                        selected->collider.halfExtents.x,
                        selected->collider.halfExtents.y,
                        selected->collider.halfExtents.z);
                    if (selected->collider.shape == engine::ecs::ColliderShape::Staircase)
                        ImGui::Text("Steps: %d", selected->collider.steps);
                } else if (selected->collider.shape == engine::ecs::ColliderShape::Capsule
                    || selected->collider.shape == engine::ecs::ColliderShape::Cylinder
                    || selected->collider.shape == engine::ecs::ColliderShape::Cone) {
                    ImGui::Text("Radius / Half Height: %.3f / %.3f",
                        selected->collider.radius, selected->collider.halfHeight);
                } else if (selected->collider.shape == engine::ecs::ColliderShape::Torus) {
                    ImGui::Text("Major / Minor Radius: %.3f / %.3f",
                        selected->collider.majorRadius, selected->collider.minorRadius);
                } else if (selected->collider.shape == engine::ecs::ColliderShape::Plane) {
                    ImGui::Text("Plane: %.3f, %.3f, %.3f / %.3f",
                        selected->collider.planeNormal.x,
                        selected->collider.planeNormal.y,
                        selected->collider.planeNormal.z,
                        selected->collider.planeOffset);
                }
                ImGui::Text("Trigger: %s", selected->collider.isTrigger ? "Yes" : "No");
                ImGui::Text("Restitution: %.3f", selected->collider.restitution);
                ImGui::Text("Friction: %.3f", selected->collider.friction);
            }
        }
    }

    if (ImGui::CollapsingHeader("Warnings", ImGuiTreeNodeFlags_DefaultOpen)) {
        bool hasWarning = false;
        if (status.dynamicBodiesWithoutCollider > 0) {
            hasWarning = true;
            ImGui::TextColored(ImVec4(1.0f, 0.78f, 0.30f, 1.0f),
                "%d dynamic body/bodies have no collider",
                static_cast<int>(status.dynamicBodiesWithoutCollider));
        }
        if (status.invalidColliders > 0) {
            hasWarning = true;
            ImGui::TextColored(ImVec4(1.0f, 0.78f, 0.30f, 1.0f),
                "%d collider(s) have invalid dimensions",
                static_cast<int>(status.invalidColliders));
        }
        if (status.dynamicBodies > 0 && status.staticColliders == 0) {
            hasWarning = true;
            ImGui::TextColored(ImVec4(1.0f, 0.78f, 0.30f, 1.0f),
                "Dynamic bodies exist but no static colliders are present");
        }
        if (!hasWarning) {
            ImGui::TextUnformatted("No physics warnings.");
        }
    }

    if (ImGui::CollapsingHeader("Scene Debug", ImGuiTreeNodeFlags_DefaultOpen)) {
        if (context.showPhysicsEventGuides) {
            ImGui::Checkbox("Show Play Physics Event Lines", context.showPhysicsEventGuides);
        }
        if (context.showAiDebug) {
            ImGui::Checkbox("AI Debug", context.showAiDebug);
        }
        if (context.useNavMesh) {
            ImGui::Checkbox("AI: Use Navmesh", context.useNavMesh);
            if (ImGui::IsItemHovered()) {
                ImGui::SetTooltip("Route chase/search paths through the funnel-smoothed "
                                  "navmesh instead of the grid (applied on next Play).");
            }
        }
        if (context.showNavigationPreview) {
            if (ImGui::Checkbox("Show Navigation Areas", context.showNavigationPreview)
                && *context.showNavigationPreview) {
                context.rebuildNavigationPreviewRequested = true;
            }
            ImGui::SameLine();
            if (ImGui::Button("Rebuild Navigation")) {
                context.rebuildNavigationPreviewRequested = true;
            }
            ImGui::Text("Walkable polygons: %d", context.navigationPreviewPolygons);
            if (ImGui::IsItemHovered()) {
                ImGui::SetTooltip("Green areas are locations the AI can navigate to. Rebuild after changing bounds or colliders.");
            }
        }
        if (context.physicsEventGuidesSelectedOnly) {
            ImGui::Checkbox("Selected Events Only", context.physicsEventGuidesSelectedOnly);
        }
        if (context.physicsEventGuidesTriggersOnly) {
            ImGui::Checkbox("Trigger Events Only", context.physicsEventGuidesTriggersOnly);
        }
        if (context.physicsEventGuidesEnterExitOnly) {
            ImGui::Checkbox("Enter/Exit Events Only", context.physicsEventGuidesEnterExitOnly);
        }
        if (ImGui::Button("Clear Recent Events")) {
            context.clearPhysicsEventGuidesRequested = true;
        }
        ImGui::TextUnformatted("Light and collider guide visibility is in World Settings.");
    }

    if (ImGui::CollapsingHeader("Recent Events", ImGuiTreeNodeFlags_DefaultOpen)) {
        static bool selectedOnly = false;
        static bool triggersOnly = false;
        static bool enterExitOnly = false;
        static bool actionsOnly = false;

        ImGui::Checkbox("Selected Only##PhysicsEvents", &selectedOnly);
        ImGui::SameLine();
        ImGui::Checkbox("Triggers Only##PhysicsEvents", &triggersOnly);
        ImGui::SameLine();
        ImGui::Checkbox("Enter/Exit Only##PhysicsEvents", &enterExitOnly);
        ImGui::SameLine();
        ImGui::Checkbox("Actions Only##PhysicsEvents", &actionsOnly);

        std::string selectedName;
        if (context.scene) {
            if (const EditorScene::Object* selected = context.scene->SelectedObject()) {
                selectedName = selected->name;
            }
        }

        if (!context.playMode) {
            ImGui::TextUnformatted("Enter Play mode to capture physics events.");
        } else if (!context.physicsEventRows || context.physicsEventRows->empty()) {
            ImGui::TextUnformatted("No collision or trigger events captured yet.");
        } else {
            int visibleRows = 0;
            ImGui::BeginChild("PhysicsEventList", ImVec2(0.0f, 150.0f), true);
            for (const EditorDockspace::PhysicsEventRow& row : *context.physicsEventRows) {
                if (selectedOnly && (selectedName.empty()
                    || (row.objectA != selectedName && row.objectB != selectedName))) {
                    continue;
                }
                if (triggersOnly && !row.trigger) {
                    continue;
                }
                if (enterExitOnly && row.phase == 1) {
                    continue;
                }
                if (actionsOnly && !row.action) {
                    continue;
                }

                ImGui::TextUnformatted(row.text.c_str());
                ++visibleRows;
            }
            if (visibleRows == 0) {
                ImGui::TextUnformatted("No events match the active filters.");
            }
            ImGui::EndChild();
        }
    }

    ImGui::End();
}

void DrawGameplayDebug(EditorDockspace::Context& context, bool* open) {
    if (!ImGui::Begin(EditorPanels::Name(EditorPanels::Panel::GameplayDebug), open)) {
        ImGui::End();
        return;
    }

    const EditorDockspace::GameplayDebugState& debug = context.gameplayDebug;
    ImGui::Text("Mode: %s", context.playMode ? "Play" : "Edit");

    if (ImGui::CollapsingHeader("Runtime Controls", ImGuiTreeNodeFlags_DefaultOpen)) {
        if (!context.playMode) {
            ImGui::TextDisabled("Enter Play mode to control the runtime.");
        } else {
            if (ImGui::Button(context.physicsPaused ? "Resume" : "Pause"))
                context.physicsPauseToggleRequested = true;
            ImGui::SameLine();
            ImGui::BeginDisabled(!context.physicsPaused);
            if (ImGui::Button("Step Physics")) context.physicsStepRequested = true;
            ImGui::EndDisabled();
            ImGui::Text("Fixed step: %.4f s", context.physicsFixedTimestep);
            ImGui::Text("Accumulator: %.4f s", context.physicsAccumulator);
            ImGui::Text("Steps this frame: %d", context.physicsStepsLastFrame);
            ImGui::Text("State: %s", context.physicsPaused ? "Paused" : "Running");
        }
        if (context.showGameplayTraces) {
            ImGui::Checkbox("Show Trace Guides", context.showGameplayTraces);
            if (ImGui::IsItemHovered())
                ImGui::SetTooltip("Draw Raycast, SphereCast and OverlapSphere queries from Play mode.");
        }
    }

    const auto drawRecentEvents = [&]() {
        if (!ImGui::CollapsingHeader("Recent Runtime Events", ImGuiTreeNodeFlags_DefaultOpen))
            return;
        ImGui::Text("Enter %d  Stay %d  Exit %d  Actions %d",
            context.physicsEventEnterCount, context.physicsEventStayCount,
            context.physicsEventExitCount, context.physicsActionCount);
        if (!context.physicsEventRows || context.physicsEventRows->empty()) {
            ImGui::TextDisabled("No runtime events recorded.");
            return;
        }
        ImGui::BeginChild("##GameplayDebugEvents", ImVec2(0.0f, 150.0f), true);
        const auto& rows = *context.physicsEventRows;
        const std::size_t first = rows.size() > 32 ? rows.size() - 32 : 0;
        for (std::size_t i = first; i < rows.size(); ++i) {
            const auto& row = rows[i];
            const ImVec4 color = row.phase == 0
                ? ImVec4(0.40f, 0.90f, 0.55f, 1.0f)
                : row.phase == 2
                    ? ImVec4(1.0f, 0.55f, 0.35f, 1.0f)
                    : ImVec4(0.75f, 0.80f, 0.90f, 1.0f);
            ImGui::PushStyleColor(ImGuiCol_Text, color);
            ImGui::TextWrapped("%s", row.text.c_str());
            ImGui::PopStyleColor();
        }
        ImGui::EndChild();
    };

    if (!debug.hasSelection) {
        ImGui::TextUnformatted("No object selected.");
        drawRecentEvents();
        ImGui::End();
        return;
    }

    ImGui::Text("Selected: %s", debug.selectedName.c_str());
    if (!context.playMode) {
        ImGui::TextUnformatted("Enter Play mode to inspect runtime script and Health state.");
    } else if (!debug.playEntityFound) {
        ImGui::TextColored(ImVec4(1.0f, 0.78f, 0.30f, 1.0f),
            "Selected object was not found in the Play registry.");
    }

    if (ImGui::CollapsingHeader("Health", ImGuiTreeNodeFlags_DefaultOpen)) {
        if (!debug.hasHealth) {
            ImGui::TextUnformatted("No runtime Health component.");
        } else {
            ImGui::Text("HP: %.2f / %.2f", debug.health, debug.maxHealth);
            ImGui::Text("Alive: %s", debug.healthAlive ? "Yes" : "No");
            ImGui::Text("Just Died: %s", debug.healthJustDied ? "Yes" : "No");
            const float fraction = debug.maxHealth > 0.0f ? debug.health / debug.maxHealth : 0.0f;
            ImGui::ProgressBar(std::clamp(fraction, 0.0f, 1.0f), ImVec2(-1.0f, 0.0f));
        }
    }

    if (ImGui::CollapsingHeader("Script", ImGuiTreeNodeFlags_DefaultOpen)) {
        if (!debug.hasScript) {
            ImGui::TextUnformatted("No runtime NativeScriptComponent.");
        } else {
            ImGui::Text("Class: %s", debug.scriptClassName.empty() ? "-" : debug.scriptClassName.c_str());
            ImGui::Text("Path: %s", debug.scriptPath.empty() ? "-" : debug.scriptPath.c_str());
            ImGui::Text("Enabled: %s", debug.scriptEnabled ? "Yes" : "No");
            ImGui::Text("Created: %s", debug.scriptCreated ? "Yes" : "No");
            ImGui::Text("Missing Factory: %s", debug.scriptMissingFactory ? "Yes" : "No");
            ImGui::Text("Fields: %d authored, %d runtime",
                debug.authoredFieldCount,
                debug.runtimeFieldCount);
            if (debug.scriptMissingFactory) {
                ImGui::TextColored(ImVec4(1.0f, 0.42f, 0.34f, 1.0f),
                    "Register this script class before entering Play mode.");
            }
        }
    }

    if (ImGui::CollapsingHeader("Trigger Contacts", ImGuiTreeNodeFlags_DefaultOpen)) {
        if (!context.playMode) {
            ImGui::TextUnformatted("Trigger contact counts are available in Play mode.");
        } else {
            ImGui::Text("Touching/Stay: %d", debug.selectedTriggerTouchCount);
            ImGui::Text("Entered: %d", debug.selectedTriggerEnterCount);
            ImGui::Text("Exited: %d", debug.selectedTriggerExitCount);
            ImGui::TextUnformatted("Counts come from the most recent physics event rows.");
        }
    }

    drawRecentEvents();

    ImGui::End();
}

void DrawAnimationPreview(EditorDockspace::Context& context, bool* open) {
    if (!ImGui::Begin(EditorPanels::Name(EditorPanels::Panel::AnimationPreview), open)) {
        ImGui::End();
        return;
    }

    const EditorDockspace::AnimationPreviewState& state = context.animationPreview;
    if (!state.hasSelection) {
        ImGui::TextUnformatted("No object selected.");
        ImGui::End();
        return;
    }

    ImGui::Text("%s", state.selectedName.c_str());
    ImGui::SameLine();
    ImGui::TextDisabled("(%s)", state.assetMode ? "Asset Preview"
        : state.playMode ? "Play mode" : "Edit mode");

    if (state.assetMode) {
        if (context.animationPreviewAssetPath
            && editor::icons::LabeledButton(editor::icons::Contact,
                "Use Scene Selection")) {
            context.animationPreviewAssetPath->clear();
        }
        ImGui::SameLine();
        if (editor::icons::LabeledButton(editor::icons::Refresh,
                "Refresh Compatible Rigs"))
            context.animationAssetRefreshRequested = true;
        if (state.assetIsAnimation) {
            ImGui::SameLine();
            if (editor::icons::LabeledButton(editor::icons::Open,
                    "Open in Clip Editor"))
                context.animationAssetOpenInClipEditorRequested = true;
        }

        ImGui::TextWrapped("Asset: %s", state.assetPath.c_str());
        ImGui::TextDisabled("Skeleton: %s",
            state.skeletonId.empty() ? "-" : state.skeletonId.c_str());

        const std::string rigLabel = state.previewMeshPath.empty()
            ? std::string("No compatible preview mesh")
            : std::filesystem::path(state.previewMeshPath).filename().string();
        ImGui::SetNextItemWidth(-1.0f);
        if (ImGui::BeginCombo("Preview Mesh", rigLabel.c_str())) {
            for (const auto& choice : state.previewMeshes) {
                ImGui::PushID(choice.path.c_str());
                if (!choice.compatible) ImGui::BeginDisabled();
                const bool selected = choice.path == state.previewMeshPath;
                if (ImGui::Selectable(choice.displayName.c_str(), selected)
                    && choice.compatible
                    && context.animationPreviewMeshPath) {
                    *context.animationPreviewMeshPath = choice.path;
                    context.animationAssetRefreshRequested = true;
                }
                if (!choice.compatible) ImGui::EndDisabled();
                if (ImGui::IsItemHovered(ImGuiHoveredFlags_AllowWhenDisabled))
                    ImGui::SetTooltip("%s\n%s", choice.path.c_str(),
                        choice.reason.c_str());
                ImGui::PopID();
            }
            if (state.previewMeshes.empty())
                ImGui::TextDisabled("No .3dgskmesh assets found in Content.");
            ImGui::EndCombo();
        }

        if (!state.loadError.empty()) {
            ImGui::TextColored(ImVec4(1.0f, 0.40f, 0.30f, 1.0f),
                "%s", state.loadError.c_str());
            ImGui::End();
            return;
        }
        if (!state.compatibilitySummary.empty()) {
            const ImVec4 color = state.missingChannels == 0
                ? ImVec4(0.45f, 0.85f, 0.55f, 1.0f)
                : ImVec4(1.0f, 0.72f, 0.25f, 1.0f);
            ImGui::TextColored(color, "%s", state.compatibilitySummary.c_str());
        }

        if (state.previewTexture != 0) {
            const float side = std::max(180.0f,
                std::min(ImGui::GetContentRegionAvail().x, 420.0f));
            ImGui::Image((ImTextureID)(std::intptr_t)state.previewTexture,
                ImVec2(side, side), ImVec2(0, 1), ImVec2(1, 0));
            if (ImGui::IsItemHovered()) {
                if (ImGui::IsMouseDragging(ImGuiMouseButton_Left)
                    && context.animationAssetYaw
                    && context.animationAssetPitch) {
                    const ImVec2 delta = ImGui::GetIO().MouseDelta;
                    *context.animationAssetYaw += delta.x * 0.45f;
                    *context.animationAssetPitch = std::clamp(
                        *context.animationAssetPitch - delta.y * 0.35f,
                        -85.0f, 85.0f);
                }
                if (context.animationAssetZoom
                    && ImGui::GetIO().MouseWheel != 0.0f) {
                    *context.animationAssetZoom = std::clamp(
                        *context.animationAssetZoom
                            + ImGui::GetIO().MouseWheel * 0.1f,
                        0.4f, 3.0f);
                }
            }
        }

        if (context.animationAssetPlaying) {
            if (editor::icons::LabeledButton(*context.animationAssetPlaying
                    ? editor::icons::Stop : editor::icons::Play,
                    *context.animationAssetPlaying ? "Pause" : "Play"))
                *context.animationAssetPlaying = !*context.animationAssetPlaying;
            ImGui::SameLine();
            if (editor::icons::LabeledButton(editor::icons::Refresh, "Restart"))
                context.animationAssetRestartRequested = true;
        }
        if (context.animationAssetLoop)
            ImGui::Checkbox("Loop", context.animationAssetLoop);
        ImGui::SameLine();
        if (context.animationAssetStripRootMotion && state.assetIsAnimation)
            ImGui::Checkbox("Strip Root Motion",
                context.animationAssetStripRootMotion);
        if (context.animationAssetSpeed)
            ImGui::DragFloat("Playback Speed", context.animationAssetSpeed,
                0.02f, 0.0f, 8.0f, "%.2fx");
        if (context.animationPreviewTime && state.previewDuration > 0.0f) {
            float time = *context.animationPreviewTime;
            if (ImGui::SliderFloat("Timeline", &time, 0.0f,
                    state.previewDuration, "%.3f s"))
                *context.animationPreviewTime = time;
            ImGui::TextDisabled("%.3f / %.3f seconds",
                state.previewTime, state.previewDuration);
        }

        if (ImGui::CollapsingHeader("Clips", ImGuiTreeNodeFlags_DefaultOpen)) {
            for (std::size_t i = 0; i < state.clips.size(); ++i)
                ImGui::BulletText("%s  (%.3f s)",
                    state.clips[i].name.empty()
                        ? ("Clip " + std::to_string(i)).c_str()
                        : state.clips[i].name.c_str(),
                    state.clips[i].durationSeconds);
            if (state.clips.empty()) ImGui::TextDisabled("No clips in this asset.");
        }
        if (ImGui::CollapsingHeader("Events / Notifies")) {
            ImGui::TextDisabled(
                "Reusable events are authored on a .3dgclip in the Clip Editor.");
            for (const auto& event : state.events)
                ImGui::BulletText("%.3f s  %s", event.time, event.name.c_str());
        }
        if (ImGui::CollapsingHeader("Skeleton")) {
            ImGui::Text("%zu bones", state.bones.size());
            ImGui::BeginChild("AssetPreviewSkeleton", ImVec2(0, 220), true);
            for (const auto& bone : state.bones) {
                std::string label(static_cast<std::size_t>(
                    std::max(bone.depth, 0)) * 2, ' ');
                label += bone.name.empty() ? "(unnamed)" : bone.name;
                ImGui::TextUnformatted(label.c_str());
            }
            ImGui::EndChild();
        }
        ImGui::End();
        return;
    }
    if (!state.skeletalModel) {
        ImGui::TextUnformatted("Selected object is not marked as a skeletal model.");
        ImGui::End();
        return;
    }

    ImGui::TextWrapped("Model: %s", state.modelPath.empty() ? "-" : state.modelPath.c_str());
    if (!state.loadError.empty()) {
        ImGui::TextWrapped("Load error: %s", state.loadError.c_str());
        ImGui::End();
        return;
    }
    if (!state.modelLoaded) {
        ImGui::TextUnformatted("Skeletal model is not loaded yet.");
        ImGui::End();
        return;
    }

    if (!state.playMode && context.scene) {
        if (ImGui::CollapsingHeader("Preview Controls", ImGuiTreeNodeFlags_DefaultOpen)) {
            if (editor::icons::LabeledButton(state.autoplay
                    ? editor::icons::Stop : editor::icons::Play,
                    state.autoplay ? "Pause" : "Play")) {
                context.scene->SetSelectedAnimationSettings(true,
                    state.defaultClipIndex,
                    state.defaultClipName,
                    !state.autoplay,
                    state.loop,
                    state.playbackSpeed);
            }
            ImGui::SameLine();
            if (editor::icons::LabeledButton(editor::icons::Refresh, "Reset")
                && context.animationPreviewTime) {
                *context.animationPreviewTime = 0.0f;
            }

            if (!state.clips.empty()) {
                int selectedClip = std::clamp(state.defaultClipIndex, 0, static_cast<int>(state.clips.size() - 1));
                const std::string currentClipName = state.defaultClipName.empty()
                    ? state.clips[static_cast<std::size_t>(selectedClip)].name
                    : state.defaultClipName;
                if (ImGui::BeginCombo("Preview Clip", currentClipName.empty() ? "(unnamed)" : currentClipName.c_str())) {
                    for (std::size_t i = 0; i < state.clips.size(); ++i) {
                        const std::string label = state.clips[i].name.empty()
                            ? ("Clip " + std::to_string(i))
                            : state.clips[i].name;
                        const bool selected = static_cast<int>(i) == selectedClip;
                        if (ImGui::Selectable(label.c_str(), selected)) {
                            context.scene->SetSelectedAnimationSettings(true,
                                static_cast<int>(i),
                                state.clips[i].name,
                                state.autoplay,
                                state.loop,
                                state.playbackSpeed);
                            if (context.animationPreviewTime) {
                                *context.animationPreviewTime = 0.0f;
                            }
                        }
                        if (selected) {
                            ImGui::SetItemDefaultFocus();
                        }
                    }
                    ImGui::EndCombo();
                }

                float scrubTime = state.previewTime;
                const float maxTime = std::max(state.previewDuration, 0.001f);
                if (ImGui::SliderFloat("Time", &scrubTime, 0.0f, maxTime, "%.2f s")
                    && context.animationPreviewTime) {
                    *context.animationPreviewTime = scrubTime;
                }
                ImGui::Text("Duration: %.2f s", state.previewDuration);
            }
        }
    }

    if (false /* legacy read-only settings dump — authored in the Character/Graph editors */) {
        ImGui::Text("Default Clip: %d %s", state.defaultClipIndex,
            state.defaultClipName.empty() ? "" : state.defaultClipName.c_str());
        ImGui::Text("Autoplay: %s", state.autoplay ? "Yes" : "No");
        ImGui::SameLine();
        ImGui::Text("Loop: %s", state.loop ? "Yes" : "No");
        ImGui::Text("Speed: %.2f", state.playbackSpeed);
        ImGui::Separator();
        ImGui::Text("Locomotion: %s", state.locomotionEnabled ? "Enabled" : "Disabled");
        if (state.locomotionEnabled) {
            ImGui::Text("Idle: %d %s", state.idleClipIndex, state.idleClipName.c_str());
            ImGui::Text("Walk: %d %s", state.walkClipIndex, state.walkClipName.c_str());
            ImGui::Text("Run: %d %s", state.runClipIndex, state.runClipName.c_str());
            ImGui::Text("Walk At: %.2f", state.walkAt);
            ImGui::SameLine();
            ImGui::Text("Run At: %.2f", state.runAt);
        }
    }

    if (ImGui::CollapsingHeader("Action Test", ImGuiTreeNodeFlags_DefaultOpen)) {
        if (state.clips.empty()) {
            ImGui::TextUnformatted("No animation clips found.");
        } else if (!context.animationActionClip
            || !context.animationActionFadeIn
            || !context.animationActionFadeOut
            || !context.animationActionSpeed) {
            ImGui::TextUnformatted("Action test controls are unavailable.");
        } else {
            *context.animationActionClip = std::clamp(
                *context.animationActionClip,
                0,
                static_cast<int>(state.clips.size() - 1));

            const int actionClip = *context.animationActionClip;
            const std::string currentActionClipName = state.clips[static_cast<std::size_t>(actionClip)].name.empty()
                ? ("Clip " + std::to_string(actionClip))
                : state.clips[static_cast<std::size_t>(actionClip)].name;
            if (ImGui::BeginCombo("Action Clip", currentActionClipName.c_str())) {
                for (std::size_t i = 0; i < state.clips.size(); ++i) {
                    const std::string label = state.clips[i].name.empty()
                        ? ("Clip " + std::to_string(i))
                        : state.clips[i].name;
                    const bool selected = static_cast<int>(i) == actionClip;
                    if (ImGui::Selectable(label.c_str(), selected)) {
                        *context.animationActionClip = static_cast<int>(i);
                    }
                    if (selected) {
                        ImGui::SetItemDefaultFocus();
                    }
                }
                ImGui::EndCombo();
            }

            ImGui::DragFloat("Fade In", context.animationActionFadeIn, 0.01f, 0.0f, 5.0f, "%.2f s");
            ImGui::DragFloat("Fade Out", context.animationActionFadeOut, 0.01f, 0.0f, 5.0f, "%.2f s");
            ImGui::DragFloat("Speed", context.animationActionSpeed, 0.01f, 0.0f, 5.0f, "%.2f");
            if (context.animationActionMaskRoot && context.animationActionMaskRootSize > 0) {
                ImGui::InputText("Mask Root Bone",
                    context.animationActionMaskRoot,
                    context.animationActionMaskRootSize);
                if (!state.bones.empty()) {
                    const char* currentMask = context.animationActionMaskRoot[0] == '\0'
                        ? "Full Body"
                        : context.animationActionMaskRoot;
                    if (ImGui::BeginCombo("Pick Mask Bone", currentMask)) {
                        if (ImGui::Selectable("Full Body", context.animationActionMaskRoot[0] == '\0')) {
                            context.animationActionMaskRoot[0] = '\0';
                        }
                        for (const EditorDockspace::AnimationPreviewState::BoneInfo& bone : state.bones) {
                            std::string label(static_cast<std::size_t>(std::max(bone.depth, 0)) * 2, ' ');
                            label += bone.name.empty() ? "(unnamed)" : bone.name;
                            const bool selected = bone.name == context.animationActionMaskRoot;
                            if (ImGui::Selectable(label.c_str(), selected)) {
                                std::snprintf(context.animationActionMaskRoot,
                                    context.animationActionMaskRootSize,
                                    "%s",
                                    bone.name.c_str());
                            }
                            if (selected) {
                                ImGui::SetItemDefaultFocus();
                            }
                        }
                        ImGui::EndCombo();
                    }
                }
            }
            *context.animationActionFadeIn = std::max(*context.animationActionFadeIn, 0.0f);
            *context.animationActionFadeOut = std::max(*context.animationActionFadeOut, 0.0f);
            *context.animationActionSpeed = std::max(*context.animationActionSpeed, 0.0f);

            if (ImGui::Button("Play Action")) {
                context.animationActionRequested = true;
            }
            ImGui::SameLine();
            ImGui::Text("Status: %s", state.actionPlaying ? "Playing" : "Idle");
        }
    }

    if (false /* legacy inline state-machine editor — now in the Graph Editor panel */) {
        if (state.playMode || !context.scene) {
            ImGui::TextUnformatted("State graphs are edited in Edit mode.");
        } else if (state.clips.empty()) {
            ImGui::TextUnformatted("No animation clips found.");
        } else {
            std::vector<EditorScene::AnimationStateNode> states = state.states;
            std::vector<EditorScene::AnimationParameter> parameters = state.parameterDefinitions;
            std::vector<EditorScene::AnimationStateTransition> transitions = state.transitions;
            bool changed = false;
            int removeState = -1;
            int removeTransition = -1;

            ImGui::Text("States: %zu", states.size());
            for (std::size_t i = 0; i < states.size(); ++i) {
                EditorScene::AnimationStateNode& node = states[i];
                ImGui::PushID(static_cast<int>(i));
                std::array<char, 96> nameBuffer{};
                std::snprintf(nameBuffer.data(), nameBuffer.size(), "%s", node.name.c_str());
                if (ImGui::InputText("State", nameBuffer.data(), nameBuffer.size())) {
                    node.name = nameBuffer.data();
                    changed = true;
                }

                node.clipIndex = std::clamp(node.clipIndex, 0, static_cast<int>(state.clips.size() - 1));
                const std::string currentClip = node.clipName.empty()
                    ? (state.clips[static_cast<std::size_t>(node.clipIndex)].name.empty()
                        ? ("Clip " + std::to_string(node.clipIndex))
                        : state.clips[static_cast<std::size_t>(node.clipIndex)].name)
                    : node.clipName;
                if (ImGui::BeginCombo("Clip", currentClip.empty() ? "(unnamed)" : currentClip.c_str())) {
                    for (std::size_t clip = 0; clip < state.clips.size(); ++clip) {
                        const std::string label = state.clips[clip].name.empty()
                            ? ("Clip " + std::to_string(clip))
                            : state.clips[clip].name;
                        const bool selectedClip = static_cast<int>(clip) == node.clipIndex;
                        if (ImGui::Selectable(label.c_str(), selectedClip)) {
                            node.clipIndex = static_cast<int>(clip);
                            node.clipName = state.clips[clip].name;
                            changed = true;
                        }
                        if (selectedClip) {
                            ImGui::SetItemDefaultFocus();
                        }
                    }
                    ImGui::EndCombo();
                }
                if (ImGui::Checkbox("Loop", &node.loop)) {
                    changed = true;
                }
                if (ImGui::DragFloat("Speed", &node.speed, 0.01f, 0.0f, 5.0f, "%.2f")) {
                    node.speed = std::max(node.speed, 0.0f);
                    changed = true;
                }
                const char* blendClip = node.blendClipIndex >= 0 && node.blendClipIndex < static_cast<int>(state.clips.size())
                    ? state.clips[static_cast<std::size_t>(node.blendClipIndex)].name.c_str() : "Disabled";
                if (ImGui::BeginCombo("Blend Clip", blendClip)) {
                    if (ImGui::Selectable("Disabled", node.blendClipIndex < 0)) {
                        node.blendClipIndex = -1;
                        node.blendClipName.clear();
                        changed = true;
                    }
                    for (std::size_t clipIndex = 0; clipIndex < state.clips.size(); ++clipIndex) {
                        if (ImGui::Selectable(state.clips[clipIndex].name.c_str(), node.blendClipIndex == static_cast<int>(clipIndex))) {
                            node.blendClipIndex = static_cast<int>(clipIndex);
                            node.blendClipName = state.clips[clipIndex].name;
                            changed = true;
                        }
                    }
                    ImGui::EndCombo();
                }
                if (node.blendClipIndex >= 0) {
                    std::array<char, 64> blendParameter{};
                    std::snprintf(blendParameter.data(), blendParameter.size(), "%s", node.blendParameter.c_str());
                    if (ImGui::InputText("Blend Parameter", blendParameter.data(), blendParameter.size())) {
                        node.blendParameter = blendParameter.data(); changed = true;
                    }
                    changed |= ImGui::DragFloat("Blend Min", &node.blendMin, 0.01f,
                        -1000000.0f, 1000000.0f);
                    changed |= ImGui::DragFloat("Blend Max", &node.blendMax, 0.01f,
                        -1000000.0f, 1000000.0f);
                    node.blendMax = std::max(node.blendMax, node.blendMin + 0.0001f);
                }
                if (ImGui::Checkbox("Root Motion", &node.rootMotion)) changed = true;
                if (ImGui::Button("Remove State")) {
                    removeState = static_cast<int>(i);
                }
                ImGui::Separator();
                ImGui::PopID();
            }

            if (removeState >= 0) {
                const std::string removedName = states[static_cast<std::size_t>(removeState)].name;
                states.erase(states.begin() + removeState);
                transitions.erase(std::remove_if(transitions.begin(), transitions.end(),
                    [&](const EditorScene::AnimationStateTransition& transition) {
                        return transition.fromState == removedName || transition.toState == removedName;
                    }), transitions.end());
                changed = true;
            }

            if (ImGui::Button("Add State")) {
                const int clip = std::clamp(state.defaultClipIndex, 0, static_cast<int>(state.clips.size() - 1));
                states.push_back(EditorScene::AnimationStateNode{
                    "State",
                    clip,
                    state.clips[static_cast<std::size_t>(clip)].name,
                    true,
                    1.0f
                });
                changed = true;
            }

            ImGui::Separator();
            ImGui::Text("Parameters: %zu", parameters.size());
            int removeParameter = -1;
            const char* parameterTypes[] = {"Float", "Bool", "Trigger"};
            for (std::size_t i = 0; i < parameters.size(); ++i) {
                auto& parameter = parameters[i];
                ImGui::PushID(5000 + static_cast<int>(i));
                std::array<char, 64> name{};
                std::snprintf(name.data(), name.size(), "%s", parameter.name.c_str());
                if (ImGui::InputText("Name", name.data(), name.size())) { parameter.name = name.data(); changed = true; }
                int type = std::clamp(static_cast<int>(parameter.type), 0, 2);
                if (ImGui::Combo("Type", &type, parameterTypes, 3)) {
                    parameter.type = static_cast<EditorScene::AnimationParameter::Type>(type); changed = true;
                }
                if (parameter.type == EditorScene::AnimationParameter::Type::Float) {
                    changed |= ImGui::DragFloat("Default", &parameter.defaultValue, 0.01f);
                } else {
                    bool defaultValue = parameter.defaultValue != 0.0f;
                    if (ImGui::Checkbox("Default", &defaultValue)) { parameter.defaultValue = defaultValue ? 1.0f : 0.0f; changed = true; }
                }
                if (ImGui::Button("Remove Parameter")) removeParameter = static_cast<int>(i);
                ImGui::Separator(); ImGui::PopID();
            }
            if (removeParameter >= 0) { parameters.erase(parameters.begin() + removeParameter); changed = true; }
            if (ImGui::Button("Add Parameter")) {
                parameters.push_back({"Parameter", EditorScene::AnimationParameter::Type::Float, 0.0f}); changed = true;
            }

            ImGui::Separator();
            ImGui::Text("Transitions: %zu", transitions.size());
            const char* compareLabels[] = {">=", "<", "==", "!=", "<=", ">"};
            for (std::size_t i = 0; i < transitions.size(); ++i) {
                EditorScene::AnimationStateTransition& transition = transitions[i];
                ImGui::PushID(10000 + static_cast<int>(i));

                auto drawStateCombo = [&](const char* label, std::string& value, bool allowAny) {
                    const char* current = value.empty() ? (allowAny ? "Any State" : "-") : value.c_str();
                    if (ImGui::BeginCombo(label, current)) {
                        if (allowAny && ImGui::Selectable("Any State", value.empty())) {
                            value.clear(); changed = true;
                        }
                        for (const EditorScene::AnimationStateNode& node : states) {
                            const bool selectedNode = node.name == value;
                            if (ImGui::Selectable(node.name.empty() ? "(unnamed)" : node.name.c_str(), selectedNode)) {
                                value = node.name;
                                changed = true;
                            }
                            if (selectedNode) {
                                ImGui::SetItemDefaultFocus();
                            }
                        }
                        ImGui::EndCombo();
                    }
                };

                drawStateCombo("From", transition.fromState, true);
                drawStateCombo("To", transition.toState, false);

                if (!parameters.empty() && ImGui::BeginCombo("Parameter", transition.parameter.empty() ? "-" : transition.parameter.c_str())) {
                    for (const auto& parameter : parameters) {
                        if (ImGui::Selectable(parameter.name.c_str(), transition.parameter == parameter.name)) {
                            transition.parameter = parameter.name;
                            if (parameter.type == EditorScene::AnimationParameter::Type::Trigger) {
                                transition.compare = EditorScene::AnimationStateTransition::Compare::NotEqual;
                                transition.threshold = 0.0f;
                            } else if (parameter.type == EditorScene::AnimationParameter::Type::Bool) {
                                // Bools need an equality test; the >= 0 default always passes.
                                transition.compare = EditorScene::AnimationStateTransition::Compare::Equal;
                                transition.threshold = 1.0f;
                            }
                            changed = true;
                        }
                    }
                    ImGui::EndCombo();
                } else if (parameters.empty()) {
                    std::array<char, 64> parameterBuffer{};
                    std::snprintf(parameterBuffer.data(), parameterBuffer.size(), "%s", transition.parameter.c_str());
                    if (ImGui::InputText("Parameter", parameterBuffer.data(), parameterBuffer.size())) {
                        transition.parameter = parameterBuffer.data(); changed = true;
                    }
                }

                auto parameterType = EditorScene::AnimationParameter::Type::Float;
                for (const auto& parameter : parameters) if (parameter.name == transition.parameter) { parameterType = parameter.type; break; }
                // A bool compared with >= / < never actually tests the value (0 and 1 are
                // both >= 0). Normalise legacy/default transitions to an equality test.
                if (parameterType == EditorScene::AnimationParameter::Type::Bool
                    && (transition.compare == EditorScene::AnimationStateTransition::Compare::GreaterOrEqual
                        || transition.compare == EditorScene::AnimationStateTransition::Compare::Less)) {
                    transition.compare = EditorScene::AnimationStateTransition::Compare::Equal;
                    if (transition.threshold != 0.0f && transition.threshold != 1.0f) transition.threshold = 1.0f;
                    changed = true;
                }
                int compare = static_cast<int>(transition.compare);
                compare = std::clamp(compare, 0, 5);
                if (parameterType != EditorScene::AnimationParameter::Type::Trigger && ImGui::BeginCombo("Compare", compareLabels[compare])) {
                    // Bool params only expose == / != ; numeric params get the full set
                    // including the new <= and >.
                    const int firstCompare = parameterType == EditorScene::AnimationParameter::Type::Bool ? 2 : 0;
                    const int lastCompare = parameterType == EditorScene::AnimationParameter::Type::Bool ? 4 : 6;
                    for (int c = firstCompare; c < lastCompare; ++c) {
                        const bool selectedCompare = c == compare;
                        if (ImGui::Selectable(compareLabels[c], selectedCompare)) {
                            transition.compare = static_cast<EditorScene::AnimationStateTransition::Compare>(c);
                            changed = true;
                        }
                        if (selectedCompare) {
                            ImGui::SetItemDefaultFocus();
                        }
                    }
                    ImGui::EndCombo();
                }
                if (parameterType == EditorScene::AnimationParameter::Type::Float) {
                    if (ImGui::DragFloat("Threshold", &transition.threshold, 0.01f, -1000.0f, 1000.0f, "%.2f")) changed = true;
                } else if (parameterType == EditorScene::AnimationParameter::Type::Bool) {
                    bool expected = transition.threshold != 0.0f;
                    if (ImGui::Checkbox("Expected", &expected)) { transition.threshold = expected ? 1.0f : 0.0f; changed = true; }
                } else {
                    ImGui::TextDisabled("Trigger is consumed after this transition fires.");
                }
                if (ImGui::DragFloat("Fade", &transition.fade, 0.01f, 0.0f, 5.0f, "%.2f s")) {
                    transition.fade = std::max(transition.fade, 0.0f);
                    changed = true;
                }
                if (ImGui::SliderFloat("Exit Time", &transition.exitTime, 0.0f, 1.0f, "%.2f")) {
                    transition.exitTime = std::clamp(transition.exitTime, 0.0f, 1.0f);
                    changed = true;
                }
                if (ImGui::DragInt("Priority", &transition.priority, 1.0f, -100, 100)) {
                    changed = true;
                }
                if (ImGui::Checkbox("Interrupt Blend", &transition.canInterrupt)) {
                    changed = true;
                }
                if (ImGui::Button("Remove Transition")) {
                    removeTransition = static_cast<int>(i);
                }
                ImGui::Separator();
                ImGui::PopID();
            }

            if (removeTransition >= 0) {
                transitions.erase(transitions.begin() + removeTransition);
                changed = true;
            }
            if (ImGui::Button("Add Transition")) {
                const std::string from = states.empty() ? std::string() : states.front().name;
                const std::string to = states.size() > 1 ? states[1].name : from;
                transitions.push_back(EditorScene::AnimationStateTransition{
                    from,
                    to,
                    "Speed",
                    // "Speed >= 0" is always true and would skip the state on frame 1;
                    // default to "> 0.1" so a resting character stays in place.
                    EditorScene::AnimationStateTransition::Compare::Greater,
                    0.1f,
                    0.2f
                });
                changed = true;
            }

            if (changed) {
                context.scene->SetSelectedAnimationStateGraph(states, transitions, parameters);
            }
        }
    }

    if (false /* legacy state-graph visualization — now in the Graph Editor panel */) {
        const ImVec2 origin = ImGui::GetCursorScreenPos();
        const float width = std::max(ImGui::GetContentRegionAvail().x, 240.0f);
        const float height = std::max(180.0f, 90.0f * std::ceil(static_cast<float>(std::max<std::size_t>(state.states.size(), 1)) / 3.0f));
        ImGui::InvisibleButton("animation_graph_canvas", ImVec2(width, height));
        ImDrawList* draw = ImGui::GetWindowDrawList();
        draw->AddRectFilled(origin, ImVec2(origin.x + width, origin.y + height), IM_COL32(24, 27, 32, 255), 5.0f);
        std::vector<ImVec2> centers;
        for (std::size_t i = 0; i < state.states.size(); ++i) {
            centers.emplace_back(origin.x + 75.0f + static_cast<float>(i % 3) * ((width - 150.0f) / 2.0f),
                origin.y + 45.0f + static_cast<float>(i / 3) * 90.0f);
        }
        auto findState = [&](const std::string& name) -> int {
            for (std::size_t i = 0; i < state.states.size(); ++i) if (state.states[i].name == name) return static_cast<int>(i);
            return -1;
        };
        for (const auto& transition : state.transitions) {
            const int to = findState(transition.toState);
            if (to < 0) continue;
            const int from = findState(transition.fromState);
            const ImVec2 target = centers[static_cast<std::size_t>(to)];
            const ImVec2 source = transition.fromState.empty() ? ImVec2(origin.x + 10.0f, target.y)
                : (from >= 0 ? centers[static_cast<std::size_t>(from)] : target);
            const ImU32 color = transition.fromState.empty() ? IM_COL32(240, 170, 70, 220) : IM_COL32(110, 155, 220, 210);
            draw->AddLine(source, target, color, 2.0f);
            const float dx = target.x - source.x, dy = target.y - source.y;
            const float length = std::sqrt(dx * dx + dy * dy);
            if (length > 1.0f) draw->AddCircleFilled(ImVec2(target.x - dx / length * 39.0f, target.y - dy / length * 19.0f), 3.0f, color);
        }
        for (std::size_t i = 0; i < state.states.size(); ++i) {
            const ImVec2 c = centers[i];
            const bool active = state.playMode && state.currentState == state.states[i].name;
            draw->AddRectFilled(ImVec2(c.x - 55.0f, c.y - 20.0f), ImVec2(c.x + 55.0f, c.y + 20.0f),
                active ? IM_COL32(65, 135, 85, 255) : IM_COL32(55, 62, 74, 255), 5.0f);
            draw->AddRect(ImVec2(c.x - 55.0f, c.y - 20.0f), ImVec2(c.x + 55.0f, c.y + 20.0f),
                active ? IM_COL32(120, 240, 145, 255) : IM_COL32(105, 120, 145, 255), 5.0f);
            const std::string label = state.states[i].name.empty() ? "(unnamed)" : state.states[i].name;
            const ImVec2 size = ImGui::CalcTextSize(label.c_str());
            draw->AddText(ImVec2(c.x - size.x * 0.5f, c.y - size.y * 0.5f), IM_COL32_WHITE, label.c_str());
        }
    }

    if (ImGui::CollapsingHeader("Graph Validation", ImGuiTreeNodeFlags_DefaultOpen)) {
        if (state.graphWarnings.empty()) ImGui::TextColored(ImVec4(0.45f, 0.9f, 0.55f, 1.0f), "Graph is valid.");
        else for (const std::string& warning : state.graphWarnings) ImGui::BulletText("%s", warning.c_str());
    }

    if (ImGui::CollapsingHeader("Graph Parameters", ImGuiTreeNodeFlags_DefaultOpen)) {
        if (state.parameters.empty()) {
            ImGui::TextUnformatted("No graph parameters are referenced by transitions.");
        } else if (state.playMode || !context.animationPreviewParameters) {
            for (const EditorDockspace::AnimationPreviewState::ParameterInfo& parameter : state.parameters) {
                if (parameter.type == EditorScene::AnimationParameter::Type::Float) ImGui::Text("%s: %.3f", parameter.name.c_str(), parameter.value);
                else ImGui::Text("%s: %s", parameter.name.c_str(), parameter.value != 0.0f ? "true" : "false");
            }
        } else {
            for (const EditorDockspace::AnimationPreviewState::ParameterInfo& parameter : state.parameters) {
                float value = parameter.value;
                const auto found = context.animationPreviewParameters->find(parameter.name);
                if (found != context.animationPreviewParameters->end()) {
                    value = found->second;
                }
                if (parameter.type == EditorScene::AnimationParameter::Type::Float) {
                    if (ImGui::DragFloat(parameter.name.c_str(), &value, 0.01f, -1000.0f, 1000.0f, "%.3f"))
                        (*context.animationPreviewParameters)[parameter.name] = value;
                } else if (parameter.type == EditorScene::AnimationParameter::Type::Bool) {
                    bool enabled = std::abs(value) > 0.0001f;
                    if (ImGui::Checkbox(parameter.name.c_str(), &enabled))
                        (*context.animationPreviewParameters)[parameter.name] = enabled ? 1.0f : 0.0f;
                } else if (ImGui::Button(parameter.name.c_str())) {
                    (*context.animationPreviewParameters)[parameter.name] = 1.0f;
                }
            }
            if (ImGui::Button("Reset Parameters")) {
                for (const EditorDockspace::AnimationPreviewState::ParameterInfo& parameter : state.parameters) {
                    (*context.animationPreviewParameters)[parameter.name] = 0.0f;
                }
            }
        }
    }

    if (ImGui::CollapsingHeader("Transition Debug", ImGuiTreeNodeFlags_DefaultOpen)) {
        if (!state.playMode) {
            ImGui::TextUnformatted("Transition diagnostics are live in Play mode.");
        } else if (!state.runtimeAnimated) {
            ImGui::TextUnformatted("Selected object has no runtime animation controller.");
        } else if (state.transitionDebugRows.empty()) {
            ImGui::TextUnformatted("No runtime graph transitions are active on this object.");
        } else {
            for (const EditorDockspace::AnimationPreviewState::TransitionDebugRow& row : state.transitionDebugRows) {
                const char* status = "Blocked";
                if (row.selected) {
                    status = "Selected";
                } else if (row.eligible) {
                    status = "Ready";
                } else if (row.blockedByBlend) {
                    status = "Blend";
                } else if (!row.exitTimeReached) {
                    status = "Exit";
                } else if (!row.conditionMet) {
                    status = "Condition";
                }

                ImGui::Text("%s -> %s", row.fromState.empty() ? "(none)" : row.fromState.c_str(),
                    row.toState.empty() ? "(none)" : row.toState.c_str());
                ImGui::SameLine();
                ImGui::TextDisabled("[%s]", status);
                ImGui::Text("Param %s: %.3f / %.3f", row.parameter.empty() ? "Speed" : row.parameter.c_str(),
                    row.value,
                    row.threshold);
                ImGui::Text("Exit %.2f %s  Priority %d%s",
                    row.exitTime,
                    row.exitTimeReached ? "ready" : "waiting",
                    row.priority,
                    row.canInterrupt ? "  interrupt" : "");
                ImGui::Separator();
            }
        }
    }

    if (ImGui::CollapsingHeader("Action Profiles", ImGuiTreeNodeFlags_DefaultOpen)) {
        if (state.playMode || !context.scene) {
            ImGui::TextUnformatted("Action profiles are edited in Edit mode.");
        } else if (state.clips.empty()) {
            ImGui::TextUnformatted("No animation clips found.");
        } else {
            std::vector<EditorScene::AnimationActionProfile> edited = state.actionProfiles;
            bool changed = false;
            int removeIndex = -1;

            for (std::size_t i = 0; i < edited.size(); ++i) {
                EditorScene::AnimationActionProfile& profile = edited[i];
                ImGui::PushID(static_cast<int>(i));

                std::array<char, 96> nameBuffer{};
                std::snprintf(nameBuffer.data(), nameBuffer.size(), "%s", profile.name.c_str());
                if (ImGui::InputText("Name", nameBuffer.data(), nameBuffer.size())) {
                    profile.name = nameBuffer.data();
                    changed = true;
                }

                profile.clipIndex = std::clamp(profile.clipIndex, 0, static_cast<int>(state.clips.size() - 1));
                const std::string currentClipName = profile.clipName.empty()
                    ? (state.clips[static_cast<std::size_t>(profile.clipIndex)].name.empty()
                        ? ("Clip " + std::to_string(profile.clipIndex))
                        : state.clips[static_cast<std::size_t>(profile.clipIndex)].name)
                    : profile.clipName;
                if (ImGui::BeginCombo("Clip", currentClipName.empty() ? "(unnamed)" : currentClipName.c_str())) {
                    for (std::size_t clip = 0; clip < state.clips.size(); ++clip) {
                        const std::string label = state.clips[clip].name.empty()
                            ? ("Clip " + std::to_string(clip))
                            : state.clips[clip].name;
                        const bool selected = static_cast<int>(clip) == profile.clipIndex;
                        if (ImGui::Selectable(label.c_str(), selected)) {
                            profile.clipIndex = static_cast<int>(clip);
                            profile.clipName = state.clips[clip].name;
                            changed = true;
                        }
                        if (selected) {
                            ImGui::SetItemDefaultFocus();
                        }
                    }
                    ImGui::EndCombo();
                }

                std::array<char, 128> maskBuffer{};
                std::snprintf(maskBuffer.data(), maskBuffer.size(), "%s", profile.maskRootBone.c_str());
                if (ImGui::InputText("Mask Root", maskBuffer.data(), maskBuffer.size())) {
                    profile.maskRootBone = maskBuffer.data();
                    changed = true;
                }
                if (!state.bones.empty()) {
                    const char* currentMask = profile.maskRootBone.empty() ? "Full Body" : profile.maskRootBone.c_str();
                    if (ImGui::BeginCombo("Pick Bone", currentMask)) {
                        if (ImGui::Selectable("Full Body", profile.maskRootBone.empty())) {
                            profile.maskRootBone.clear();
                            changed = true;
                        }
                        for (const EditorDockspace::AnimationPreviewState::BoneInfo& bone : state.bones) {
                            std::string label(static_cast<std::size_t>(std::max(bone.depth, 0)) * 2, ' ');
                            label += bone.name.empty() ? "(unnamed)" : bone.name;
                            const bool selected = bone.name == profile.maskRootBone;
                            if (ImGui::Selectable(label.c_str(), selected)) {
                                profile.maskRootBone = bone.name;
                                changed = true;
                            }
                            if (selected) {
                                ImGui::SetItemDefaultFocus();
                            }
                        }
                        ImGui::EndCombo();
                    }
                }

                if (ImGui::DragFloat("Fade In", &profile.fadeIn, 0.01f, 0.0f, 5.0f, "%.2f s")) {
                    profile.fadeIn = std::max(profile.fadeIn, 0.0f);
                    changed = true;
                }
                if (ImGui::DragFloat("Fade Out", &profile.fadeOut, 0.01f, 0.0f, 5.0f, "%.2f s")) {
                    profile.fadeOut = std::max(profile.fadeOut, 0.0f);
                    changed = true;
                }
                if (ImGui::DragFloat("Speed", &profile.speed, 0.01f, 0.0f, 5.0f, "%.2f")) {
                    profile.speed = std::max(profile.speed, 0.0f);
                    changed = true;
                }

                if (ImGui::Button("Remove Profile")) {
                    removeIndex = static_cast<int>(i);
                }
                ImGui::Separator();
                ImGui::PopID();
            }

            if (removeIndex >= 0) {
                edited.erase(edited.begin() + removeIndex);
                changed = true;
            }

            if (ImGui::Button("Add Profile")) {
                const int clip = context.animationActionClip
                    ? std::clamp(*context.animationActionClip, 0, static_cast<int>(state.clips.size() - 1))
                    : std::clamp(state.defaultClipIndex, 0, static_cast<int>(state.clips.size() - 1));
                edited.push_back(EditorScene::AnimationActionProfile{
                    "ActionProfile",
                    clip,
                    state.clips[static_cast<std::size_t>(clip)].name,
                    context.animationActionMaskRoot ? std::string(context.animationActionMaskRoot) : std::string(),
                    context.animationActionFadeIn ? *context.animationActionFadeIn : 0.08f,
                    context.animationActionFadeOut ? *context.animationActionFadeOut : 0.15f,
                    context.animationActionSpeed ? *context.animationActionSpeed : 1.0f
                });
                changed = true;
            }

            if (changed) {
                context.scene->SetSelectedAnimationActionProfiles(edited);
            }
            if (edited.empty()) {
                ImGui::TextUnformatted("No action profiles authored for this object.");
            }
        }
    }

    if (ImGui::CollapsingHeader("Events", ImGuiTreeNodeFlags_DefaultOpen)) {
        if (state.playMode || !context.scene) {
            ImGui::TextUnformatted("Animation events are edited in Edit mode.");
        } else {
            ImGui::TextWrapped("Audio commands: Audio.Play, Audio.Restart:SourceName, "
                               "Audio.Pause:SourceName, Audio.Resume:SourceName, Audio.Stop:SourceName");
            std::vector<EditorScene::AnimationEvent> edited = state.events;
            bool changed = false;
            int removeIndex = -1;

            for (std::size_t i = 0; i < edited.size(); ++i) {
                EditorScene::AnimationEvent& event = edited[i];
                ImGui::PushID(static_cast<int>(i));

                int clipIndex = event.clipIndex;
                if (ImGui::InputInt("Clip", &clipIndex)) {
                    event.clipIndex = std::max(clipIndex, 0);
                    changed = true;
                }

                float eventTime = event.time;
                if (ImGui::DragFloat("Time", &eventTime, 0.01f, 0.0f, 10000.0f, "%.2f s")) {
                    event.time = std::max(eventTime, 0.0f);
                    changed = true;
                }

                std::array<char, 96> nameBuffer{};
                std::snprintf(nameBuffer.data(), nameBuffer.size(), "%s", event.name.c_str());
                if (ImGui::InputText("Name", nameBuffer.data(), nameBuffer.size())) {
                    event.name = nameBuffer.data();
                    changed = true;
                }

                if (ImGui::Button("Remove")) {
                    removeIndex = static_cast<int>(i);
                }
                ImGui::Separator();
                ImGui::PopID();
            }

            if (removeIndex >= 0) {
                edited.erase(edited.begin() + removeIndex);
                changed = true;
            }

            if (ImGui::Button("Add Event")) {
                edited.push_back(EditorScene::AnimationEvent{
                    std::max(state.defaultClipIndex, 0),
                    std::max(state.previewTime, 0.0f),
                    "Event"
                });
                changed = true;
            }

            if (changed) {
                context.scene->SetSelectedAnimationEvents(edited);
            }

            if (edited.empty()) {
                ImGui::TextUnformatted("No events authored for this object.");
            }
        }
    }

    if (ImGui::CollapsingHeader("Runtime", ImGuiTreeNodeFlags_DefaultOpen)) {
        if (!state.playMode) {
            ImGui::TextUnformatted("Enter Play mode to inspect live animation state.");
        } else if (!state.runtimeAnimated) {
            ImGui::TextUnformatted("Selected runtime entity has no AnimatedModel component.");
        } else {
            ImGui::Text("State: %s", state.currentState.c_str());
            ImGui::Text("States: %zu", state.stateCount);
            ImGui::Text("Parameter: %.2f", state.parameter);
            ImGui::Text("Current Clip: %d", state.currentClip);
            ImGui::Text("Current Time: %.2f s", state.currentTime);
            if (state.previousClip >= 0) {
                ImGui::Text("Previous Clip: %d", state.previousClip);
                ImGui::Text("Previous Time: %.2f s", state.previousTime);
            }
            ImGui::Text("Blend: %.2f", state.blend);
            ImGui::Text("Pose Bones: %zu", state.poseBones);
        }
    }

    if (ImGui::CollapsingHeader("Clips", ImGuiTreeNodeFlags_DefaultOpen)) {
        if (state.clips.empty()) {
            ImGui::TextUnformatted("No animation clips found.");
        } else {
            for (std::size_t i = 0; i < state.clips.size(); ++i) {
                const auto& clip = state.clips[i];
                ImGui::Text("%zu: %s", i, clip.name.empty() ? "(unnamed)" : clip.name.c_str());
                ImGui::SameLine();
                ImGui::TextDisabled("%.2f s", clip.durationSeconds);
            }
        }
    }

    if (ImGui::CollapsingHeader("Skeleton")) {
        if (state.bones.empty()) {
            ImGui::TextUnformatted("No skeleton bones found.");
        } else {
            ImGui::Text("Bones: %zu", state.bones.size());
            ImGui::Separator();
            ImGui::BeginChild("AnimationSkeletonBones", ImVec2(0.0f, 220.0f), true);
            for (std::size_t i = 0; i < state.bones.size(); ++i) {
                const auto& bone = state.bones[i];
                std::string label(static_cast<std::size_t>(std::max(bone.depth, 0)) * 2, ' ');
                label += std::to_string(i);
                label += ": ";
                label += bone.name.empty() ? "(unnamed)" : bone.name;
                if (context.animationActionMaskRoot
                    && context.animationActionMaskRootSize > 0
                    && ImGui::Selectable(label.c_str(), bone.name == context.animationActionMaskRoot)) {
                    std::snprintf(context.animationActionMaskRoot,
                        context.animationActionMaskRootSize,
                        "%s",
                        bone.name.c_str());
                }
                if (ImGui::IsItemHovered()) {
                    ImGui::SetTooltip("Parent: %d", bone.parent);
                }
            }
            ImGui::EndChild();
        }
    }

    ImGui::End();
}

void DrawHierarchy(EditorDockspace::Context& context, bool* open) {
    if (!ImGui::Begin(EditorPanels::Name(EditorPanels::Panel::Hierarchy), open)) {
        ImGui::End();
        return;
    }

    if (!context.scene) {
        ImGui::TextUnformatted("Scene unavailable.");
        ImGui::End();
        return;
    }

    const std::vector<EditorScene::Object>& objects = context.scene->Objects();
    ImGui::Checkbox("Lock Selection", &g_hierarchyLockSelection);
    if (ImGui::IsItemHovered()) {
        ImGui::SetTooltip("Prevent the Hierarchy from changing the scene selection, so a "
                          "stray click here can't re-target your viewport selection. Also "
                          "auto-locks while you drag a gizmo or paint in the viewport.");
    }
    // Effective lock: the manual toggle, or automatically while working in the viewport.
    const bool selectionLocked = g_hierarchyLockSelection || context.viewportInteractionActive;
    if (context.viewportInteractionActive && !g_hierarchyLockSelection) {
        ImGui::SameLine();
        ImGui::TextColored(ImVec4(1.0f, 0.72f, 0.18f, 1.0f), "(locked: working in viewport)");
    }
    g_hierarchyFilter.Draw("Filter");

    int visibleObjects = 0;
    for (const EditorScene::Object& object : objects) {
        char label[192];
        std::snprintf(label, sizeof(label), "%s%s%s %s",
            object.visible ? "" : "[hidden] ",
            object.locked ? "[locked] " : "",
            object.light ? "[light]" : "",
            object.name.c_str());

        if (g_hierarchyFilter.PassFilter(label)) {
            ++visibleObjects;
        }
    }

    if (g_hierarchyFilter.IsActive()) {
        ImGui::Text("%d of %d objects", visibleObjects, static_cast<int>(objects.size()));
    } else {
        ImGui::Text("%d objects", static_cast<int>(objects.size()));
    }
    ImGui::Separator();

    // Snapshot the multi-selection once so every selected row is highlighted (clicks
    // mutate the real set; the snapshot refreshes next frame).
    const std::vector<int> selectionSnapshot = context.scene->SelectedIndices();
    const auto isRowSelected = [&](int index) {
        return std::find(selectionSnapshot.begin(), selectionSnapshot.end(), index)
            != selectionSnapshot.end();
    };

    for (int i = 0; i < static_cast<int>(objects.size()); ++i) {
        const EditorScene::Object& object = objects[static_cast<std::size_t>(i)];
        char label[192];
        std::snprintf(label, sizeof(label), "%s%s%s %s",
            object.visible ? "" : "[hidden] ",
            object.locked ? "[locked] " : "",
            object.light ? "[light]" : "",
            object.name.c_str());

        if (!g_hierarchyFilter.PassFilter(label)) {
            continue;
        }

        if (ImGui::Selectable(label, isRowSelected(i)) && !selectionLocked) {
            // Shift+click toggles the row in/out of the multi-selection; a plain click
            // replaces the selection with just this object. Disabled while locked so the
            // viewport selection can't be changed (and accidentally deleted) from here.
            if (ImGui::GetIO().KeyShift) context.scene->ToggleSelection(i);
            else context.scene->SelectIndex(i);
        }
        if (ImGui::BeginPopupContextItem()) {
            // Right-clicking an unselected row selects just it; right-clicking a row that
            // is already selected keeps the (possibly multi-) selection so Duplicate/Delete
            // act on the whole group. While locked, the selection is left untouched.
            if (!selectionLocked && !isRowSelected(i)) context.scene->SelectIndex(i);
            if (ImGui::MenuItem("Duplicate", nullptr, false, !object.locked)) {
                context.duplicateSelectedRequested = true;
            }
            if (ImGui::MenuItem("Merge to Single Mesh", nullptr, false,
                    context.scene->SelectedIndices().size() >= 2)) {
                context.mergeSelectedRequested = true;
            }
            if (ImGui::MenuItem(object.visible ? "Hide" : "Show")) {
                context.scene->ToggleSelectVisible();
            }
            if (ImGui::MenuItem(object.locked ? "Unlock" : "Lock")) {
                context.scene->ToggleSelectedLocked();
            }
            if (ImGui::MenuItem("Delete", nullptr, false, !object.locked)) {
                context.deleteSelectedRequested = true;
            }
            if (ImGui::MenuItem("Frame Selected")) {
                context.frameSelectedRequested = true;
            }
            ImGui::Separator();
            if (ImGui::MenuItem("Deselect")) {
                context.scene->Deselect();
            }
            ImGui::EndPopup();
        }
    }

    ImGui::End();
}

void DrawInspector(EditorDockspace::Context& context, bool* open) {
    if (!ImGui::Begin(EditorPanels::Name(EditorPanels::Panel::Inspector), open)) {
        ImGui::End();
        return;
    }

    if (!context.scene) {
        ImGui::TextUnformatted("Scene unavailable.");
        ImGui::End();
        return;
    }

    const EditorScene::Object* selected = context.scene->SelectedObject();
    if (!selected) {
        ImGui::TextUnformatted("No object selected.");
        ImGui::End();
        return;
    }

    // Characters are authored in the Character Editor panel, so the inspector hides the
    // inline Animation / Runtime Components / Gameplay Components / AI sections for them.
    const bool isCharacter = selected->skeletalModel
        || !selected->characterAssetPath.empty();

    if (ImGui::CollapsingHeader("Object", ImGuiTreeNodeFlags_DefaultOpen)) {
        if (g_objectNameEntity != selected->entity) {
            std::snprintf(g_objectNameBuffer.data(), g_objectNameBuffer.size(), "%s", selected->name.c_str());
            g_objectNameEntity = selected->entity;
        }

        const bool submitted = ImGui::InputText("Name",
            g_objectNameBuffer.data(),
            g_objectNameBuffer.size(),
            ImGuiInputTextFlags_EnterReturnsTrue);
        const bool nameEditFinished = ImGui::IsItemDeactivatedAfterEdit();
        if (submitted || nameEditFinished) {
            if (context.scene->SetSelectedName(g_objectNameBuffer.data())) {
                const EditorScene::Object* renamed = context.scene->SelectedObject();
                std::snprintf(g_objectNameBuffer.data(), g_objectNameBuffer.size(), "%s",
                    renamed ? renamed->name.c_str() : "");
            } else {
                std::snprintf(g_objectNameBuffer.data(), g_objectNameBuffer.size(), "%s", selected->name.c_str());
            }
        }

        ImGui::Text("Type: %s", ObjectTypeName(*selected));
        if (ImGui::Button("Frame Selected")) {
            context.frameSelectedRequested = true;
        }

        bool visible = selected->visible;
        const char* activeLabel = selected->primitive == EditorScene::Primitive::Empty
            ? "Active in Play" : "Visible";
        if (ImGui::Checkbox(activeLabel, &visible)) {
            context.scene->ToggleSelectVisible();
        }

        bool locked = selected->locked;
        if (ImGui::Checkbox("Locked", &locked)) {
            context.scene->ToggleSelectedLocked();
        }
    }

    if (!selected->navMeshBoundsVolume) {
        // Add Component (opens the searchable catalog) and a dedicated Add Script shortcut
        // sit side by side. Sections below appear only for components that have been added.
        const float spacing = ImGui::GetStyle().ItemSpacing.x;
        const float half = (ImGui::GetContentRegionAvail().x - spacing) * 0.5f;
        if (ImGui::Button("+ Add Component", ImVec2(half, 30.0f))) {
            g_componentPopupOpenRequested = true;
        }
        ImGui::SameLine();
        const bool hasScript = HasComponent(*selected, AddableComponent::Script);
        ImGui::BeginDisabled(selected->locked || hasScript);
        if (ImGui::Button(hasScript ? "Script Added" : "+ Add Script", ImVec2(half, 30.0f))) {
            AddComponent(context, AddableComponent::Script);
        }
        ImGui::EndDisabled();
        DrawAddComponentPopup(context);
    }

    if (ImGui::CollapsingHeader("Transform", ImGuiTreeNodeFlags_DefaultOpen)) {
        const engine::ecs::Transform* transform = context.scene->TryGetTransform(selected->entity);
        if (transform) {
            engine::ecs::Transform edited = *transform;
            glm::vec3 rotationDegrees = glm::degrees(glm::eulerAngles(transform->rotation));
            bool transformChanged = false;
            bool transformEditEnded = false;

            transformChanged |= ImGui::DragFloat3("Position", &edited.position.x, 0.05f);
            if (ImGui::IsItemActivated()) {
                context.scene->BeginTransformEdit();
            }
            transformEditEnded |= ImGui::IsItemDeactivatedAfterEdit();

            transformChanged |= ImGui::DragFloat3("Scale", &edited.scale.x, 0.02f, 0.001f, 1000.0f);
            if (ImGui::IsItemActivated()) {
                context.scene->BeginTransformEdit();
            }
            transformEditEnded |= ImGui::IsItemDeactivatedAfterEdit();

            if (ImGui::DragFloat3("Rotation", &rotationDegrees.x, 0.5f)) {
                edited.rotation = glm::quat(glm::radians(rotationDegrees));
                transformChanged = true;
            }
            if (ImGui::IsItemActivated()) {
                context.scene->BeginTransformEdit();
            }
            transformEditEnded |= ImGui::IsItemDeactivatedAfterEdit();

            if (transformChanged) {
                context.scene->SetSelectedTransform(edited);
            }
            if (transformEditEnded) {
                context.scene->EndTransformEdit();
            }

            if (ImGui::Button("Reset Transform")) {
                context.scene->ResetSelectedTransform();
            }
        } else {
            ImGui::TextUnformatted("No transform component.");
        }
    }

    if (selected->navMeshBoundsVolume) {
        if (ImGui::CollapsingHeader("Navigation Bounds", ImGuiTreeNodeFlags_DefaultOpen)) {
            ImGui::TextWrapped("This editor-only volume defines the region baked into the navigation grid and nav mesh. Scale and move it to cover the playable area.");
            if (const engine::ecs::Transform* transform = context.scene->TryGetTransform(selected->entity)) {
                ImGui::Text("Bounds size: %.2f x %.2f x %.2f",
                    std::abs(transform->scale.x), std::abs(transform->scale.y), std::abs(transform->scale.z));
                ImGui::Text("Navigation floor: %.2f", transform->position.y - std::abs(transform->scale.y) * 0.5f);
            }
            ImGui::TextDisabled("The volume is excluded from runtime rendering and collision.");
        }
        ImGui::End();
        return;
    }

    if (selected->primitive == EditorScene::Primitive::Empty) {
        ImGui::TextDisabled("Empty objects do not render. Add scripts or other components below.");
    } else if (ImGui::CollapsingHeader("Rendering", ImGuiTreeNodeFlags_DefaultOpen)) {
        ImGui::Text("Model: %s", selected->modelAssetPath.empty() ? "-" : selected->modelAssetPath.c_str());
        ImGui::Text("Material: %s", selected->materialAssetPath.empty() ? "-" : selected->materialAssetPath.c_str());

        const engine::ecs::MeshRenderer* renderer = context.scene->TryGetMeshRenderer(selected->entity);
        std::size_t vertexCount = 0;
        std::size_t triangleCount = 0;
        std::size_t subMeshCount = 0;
        bool geometryStatsAvailable = false;
        if (!selected->modelAssetPath.empty() && context.runtimeAssets) {
            std::string geometryError;
            if (selected->skeletalModel) {
                if (const engine::SkinnedModel* model =
                        context.runtimeAssets->LoadSkinnedModel(
                            selected->modelAssetPath, &geometryError)) {
                    vertexCount = model->VertexCount();
                    triangleCount = model->TriangleCount();
                    subMeshCount = model->SubMeshCount();
                    geometryStatsAvailable = true;
                }
            } else if (const engine::Model* model =
                           context.runtimeAssets->LoadModel(
                               selected->modelAssetPath, &geometryError)) {
                vertexCount = model->VertexCount();
                triangleCount = model->TriangleCount();
                subMeshCount = model->SubMeshCount();
                geometryStatsAvailable = true;
            }
        } else if (renderer && renderer->mesh) {
            vertexCount = renderer->mesh->VertexCount();
            triangleCount = renderer->mesh->TriangleCount();
            subMeshCount = 1;
            geometryStatsAvailable = true;
        }
        if (geometryStatsAvailable) {
            ImGui::Text("Geometry: %zu vertices | %zu triangles",
                        vertexCount, triangleCount);
            if (subMeshCount > 1u)
                ImGui::TextDisabled("Submeshes: %zu", subMeshCount);
        } else {
            ImGui::TextDisabled("Geometry statistics unavailable.");
        }

        if (renderer) {
            glm::vec3 color = renderer->color;
            if (ImGui::ColorEdit3("Color", &color.x)) {
                context.scene->SetSelectedColor(color);
            }
        }

        if (context.assets) {
            const std::vector<EditorAssets::Asset> materials = FindMaterialAssets(*context.assets);
            const char* preview = selected->materialAssetPath.empty() ? "None" : selected->materialAssetPath.c_str();
            if (ImGui::BeginCombo("Apply Material", preview)) {
                if (ImGui::Selectable("None", selected->materialAssetPath.empty())) {
                    if (context.scene->SetSelectedMaterialAsset(std::string())) {
                        if (context.log) {
                            context.log->Info("Cleared selected object material");
                        }
                    } else if (context.log) {
                        context.log->Warning("Material clear failed: selected object is locked");
                    }
                }
                for (const EditorAssets::Asset& material : materials) {
                    const std::string fullPath = (std::filesystem::path(context.assets->RootPath()) / material.relativePath).string();
                    const bool current = selected->materialAssetPath == fullPath;
                    if (ImGui::Selectable(material.relativePath.c_str(), current)) {
                        if (context.scene->SetSelectedMaterialAsset(fullPath)) {
                            if (context.log) {
                                context.log->Info("Applied material: " + material.relativePath);
                            }
                        } else if (context.log) {
                            context.log->Warning("Material apply failed: selected object is locked");
                        }
                    }
                    if (current) {
                        ImGui::SetItemDefaultFocus();
                    }
                }
                if (materials.empty()) {
                    ImGui::TextUnformatted("No .3dgmat files found.");
                }
                ImGui::EndCombo();
            }
        }
        if (context.runtimeAssets && !selected->materialAssetPath.empty()
            && std::filesystem::path(selected->materialAssetPath).extension() == ".3dgmat") {
            std::string materialError;
            const engine::RuntimeMaterialAsset* material =
                context.runtimeAssets->LoadMaterial(
                    selected->materialAssetPath, &materialError);
            if (material && !material->shaderPath.empty()
                && ImGui::TreeNode("Material Instance Overrides")) {
                ImGui::TextDisabled("Shader: %s", material->shaderPath.c_str());
                for (const engine::RuntimeShaderParameter& parameter :
                     material->shaderParameters) {
                    const auto authored =
                        selected->materialParameterOverrides.find(parameter.name);
                    std::string value = authored == selected->materialParameterOverrides.end()
                        ? parameter.value : authored->second;
                    bool changed = false;
                    ImGui::PushID(parameter.name.c_str());
                    if (parameter.type == static_cast<int>(engine::ShaderValueType::Bool)) {
                        bool enabled = value == "true" || value == "1";
                        if (ImGui::Checkbox(parameter.name.c_str(), &enabled)) {
                            value = enabled ? "true" : "false";
                            changed = true;
                        }
                    } else if (parameter.type == static_cast<int>(engine::ShaderValueType::Float)) {
                        float number = std::strtof(value.c_str(), nullptr);
                        if (ImGui::DragFloat(parameter.name.c_str(), &number, 0.01f)) {
                            value = std::to_string(number);
                            changed = true;
                        }
                    } else {
                        std::array<char, 256> buffer{};
                        std::snprintf(buffer.data(), buffer.size(), "%s", value.c_str());
                        if (ImGui::InputText(parameter.name.c_str(),
                                             buffer.data(), buffer.size())) {
                            value = buffer.data();
                            changed = true;
                        }
                    }
                    if (changed)
                        context.scene->SetSelectedMaterialParameterOverride(
                            parameter.name, value);
                    ImGui::PopID();
                }
                ImGui::TreePop();
            }
        }
    }

    // Animation controls only apply to imported skeletal meshes. Keep character
    // assets in the dedicated Character Editor, and do not show these controls
    // for static meshes merely because they have a model asset path.
    if (selected->skeletalModel && selected->characterAssetPath.empty()
        && !selected->modelAssetPath.empty()
        && ImGui::CollapsingHeader("Animation", ImGuiTreeNodeFlags_DefaultOpen)) {
        bool skeletalModel = selected->skeletalModel;
        int clipIndex = selected->animationClipIndex;
        bool autoplay = selected->animationAutoplay;
        bool loop = selected->animationLoop;
        float speed = selected->animationSpeed;
        bool locomotionEnabled = selected->animationLocomotionEnabled;
        int idleClipIndex = selected->animationIdleClipIndex;
        int walkClipIndex = selected->animationWalkClipIndex;
        int runClipIndex = selected->animationRunClipIndex;
        float walkAt = selected->animationWalkAt;
        float runAt = selected->animationRunAt;
        std::array<char, 96> clipName{};
        std::array<char, 96> idleClipName{};
        std::array<char, 96> walkClipName{};
        std::array<char, 96> runClipName{};
        std::snprintf(clipName.data(), clipName.size(), "%s", selected->animationClipName.c_str());
        std::snprintf(idleClipName.data(), idleClipName.size(), "%s", selected->animationIdleClipName.c_str());
        std::snprintf(walkClipName.data(), walkClipName.size(), "%s", selected->animationWalkClipName.c_str());
        std::snprintf(runClipName.data(), runClipName.size(), "%s", selected->animationRunClipName.c_str());
        const engine::SkinnedModel* inspectedModel = nullptr;

        bool changed = false;
        changed |= ImGui::Checkbox("Skeletal Model", &skeletalModel);
        if (skeletalModel && context.runtimeAssets) {
            std::string error;
            inspectedModel = context.runtimeAssets->LoadSkinnedModel(selected->modelAssetPath, &error);
            if (inspectedModel) {
                const auto& animations = inspectedModel->Animations();
                if (!animations.empty()) {
                    clipIndex = std::clamp(clipIndex, 0, static_cast<int>(animations.size() - 1));
                    const std::string currentName = clipName[0] != '\0'
                        ? std::string(clipName.data())
                        : animations[static_cast<std::size_t>(clipIndex)].name;
                    if (ImGui::BeginCombo("Default Clip", currentName.c_str())) {
                        for (std::size_t i = 0; i < animations.size(); ++i) {
                            const std::string label = animations[i].name.empty()
                                ? ("Clip " + std::to_string(i))
                                : animations[i].name;
                            const bool selectedClip = static_cast<int>(i) == clipIndex;
                            if (ImGui::Selectable(label.c_str(), selectedClip)) {
                                clipIndex = static_cast<int>(i);
                                std::snprintf(clipName.data(), clipName.size(), "%s", animations[i].name.c_str());
                                changed = true;
                            }
                            if (selectedClip) {
                                ImGui::SetItemDefaultFocus();
                            }
                        }
                        ImGui::EndCombo();
                    }
                    ImGui::Text("Clips: %zu | Bones: %zu", animations.size(), inspectedModel->BoneCount());
                } else {
                    ImGui::TextUnformatted("This skeletal model has no animation clips.");
                    changed |= ImGui::InputInt("Default Clip Index", &clipIndex);
                    changed |= ImGui::InputText("Default Clip Name", clipName.data(), clipName.size());
                }
            } else {
                ImGui::TextWrapped("Could not inspect clips: %s", error.c_str());
                changed |= ImGui::InputInt("Default Clip Index", &clipIndex);
                changed |= ImGui::InputText("Default Clip Name", clipName.data(), clipName.size());
            }
        } else {
            changed |= ImGui::InputInt("Default Clip Index", &clipIndex);
            changed |= ImGui::InputText("Default Clip Name", clipName.data(), clipName.size());
        }
        changed |= ImGui::Checkbox("Autoplay", &autoplay);
        ImGui::SameLine();
        changed |= ImGui::Checkbox("Loop", &loop);
        changed |= ImGui::DragFloat("Playback Speed", &speed, 0.05f, 0.0f, 10.0f);

        if (skeletalModel && inspectedModel && !inspectedModel->Animations().empty()
            && ImGui::TreeNodeEx("Locomotion States", ImGuiTreeNodeFlags_DefaultOpen)) {
            const auto& animations = inspectedModel->Animations();
            auto drawClipCombo = [&](const char* label, int& index, std::array<char, 96>& nameBuffer) {
                index = std::clamp(index, 0, static_cast<int>(animations.size() - 1));
                const std::string currentName = nameBuffer[0] != '\0'
                    ? std::string(nameBuffer.data())
                    : animations[static_cast<std::size_t>(index)].name;
                bool comboChanged = false;
                if (ImGui::BeginCombo(label, currentName.c_str())) {
                    for (std::size_t i = 0; i < animations.size(); ++i) {
                        const std::string item = animations[i].name.empty()
                            ? ("Clip " + std::to_string(i))
                            : animations[i].name;
                        const bool selectedClip = static_cast<int>(i) == index;
                        if (ImGui::Selectable(item.c_str(), selectedClip)) {
                            index = static_cast<int>(i);
                            std::snprintf(nameBuffer.data(), nameBuffer.size(), "%s", animations[i].name.c_str());
                            comboChanged = true;
                        }
                        if (selectedClip) {
                            ImGui::SetItemDefaultFocus();
                        }
                    }
                    ImGui::EndCombo();
                }
                return comboChanged;
            };

            bool locomotionChanged = false;
            locomotionChanged |= ImGui::Checkbox("Use Locomotion", &locomotionEnabled);
            locomotionChanged |= drawClipCombo("Idle", idleClipIndex, idleClipName);
            locomotionChanged |= drawClipCombo("Walk", walkClipIndex, walkClipName);
            locomotionChanged |= drawClipCombo("Run", runClipIndex, runClipName);
            locomotionChanged |= ImGui::DragFloat("Walk At", &walkAt, 0.05f, 0.0f, 100.0f, "%.2f");
            locomotionChanged |= ImGui::DragFloat("Run At", &runAt, 0.05f, 0.0f, 100.0f, "%.2f");
            if (locomotionChanged) {
                context.scene->SetSelectedAnimationLocomotion(locomotionEnabled,
                    idleClipIndex,
                    idleClipName.data(),
                    walkClipIndex,
                    walkClipName.data(),
                    runClipIndex,
                    runClipName.data(),
                    walkAt,
                    runAt);
            }
            ImGui::TreePop();
        }

        if (changed) {
            context.scene->SetSelectedAnimationSettings(skeletalModel,
                clipIndex,
                clipName.data(),
                autoplay,
                loop,
                speed);
        }
    }

    if (selected->light) {
        if (ImGui::CollapsingHeader("Light", ImGuiTreeNodeFlags_DefaultOpen)) {
            engine::ecs::Light light = selected->lightData;
            if (const engine::ecs::Light* component = context.scene->TryGetLight(selected->entity)) {
                light = *component;
            }

            int typeIndex = LightTypeIndex(light.type);
            const char* lightTypes[] = {"Directional", "Point", "Spot", "Area"};
            if (ImGui::Combo("Light Type", &typeIndex, lightTypes, 4)) {
                light.type = LightTypeFromIndex(typeIndex);
                context.scene->SetSelectedLight(light);
            }
            if (ImGui::ColorEdit3("Light Color", &light.color.x)) {
                context.scene->SetSelectedLight(light);
            }
            if (ImGui::DragFloat("Intensity", &light.intensity, 0.1f, 0.0f, 10000.0f)) {
                context.scene->SetSelectedLight(light);
            }
            if (ImGui::DragFloat3("Direction", &light.direction.x, 0.02f)) {
                context.scene->SetSelectedLight(light);
            }
            if (ImGui::DragFloat("Inner Angle", &light.innerAngle, 0.25f, 0.0f, 179.0f)) {
                context.scene->SetSelectedLight(light);
            }
            if (ImGui::DragFloat("Outer Angle", &light.outerAngle, 0.25f, 0.0f, 179.0f)) {
                context.scene->SetSelectedLight(light);
            }
            if (ImGui::DragFloat("Range", &light.range, 0.25f, 0.0f, 10000.0f)) {
                context.scene->SetSelectedLight(light);
            }
            if (ImGui::DragFloat("Source Radius", &light.sourceRadius, 0.05f, 0.0f, 1000.0f)) {
                context.scene->SetSelectedLight(light);
            }
        }
    }

    if (selected->audioSourceEnabled) {
        if (ImGui::CollapsingHeader("Audio Source", ImGuiTreeNodeFlags_DefaultOpen)) {
            bool enabled = selected->audioSourceEnabled;
            std::string path = selected->audioAssetPath;
            float volume = selected->audioVolume;
            float pitch = selected->audioPitch;
            bool spatial = selected->audioSpatial;
            bool loop = selected->audioLoop;
            bool autoplay = selected->audioAutoplay;
            float minDistance = selected->audioMinDistance;
            float maxDistance = selected->audioMaxDistance;
            float rolloff = selected->audioRolloff;
            float dopplerFactor = selected->audioDopplerFactor;
            float coneInnerAngle = selected->audioConeInnerAngle;
            float coneOuterAngle = selected->audioConeOuterAngle;
            float coneOuterGain = selected->audioConeOuterGain;
            float occlusion = selected->audioOcclusion;
            int priority = selected->audioPriority;
            engine::AudioBus bus = selected->audioBus;
            bool changed = false;

            changed |= ImGui::Checkbox("Enabled##AudioSource", &enabled);
            const char* preview = path.empty() ? "Select audio asset..." : path.c_str();
            if (ImGui::BeginCombo("Audio Clip", preview)) {
                if (ImGui::Selectable("None", path.empty())) { path.clear(); changed = true; }
                if (context.assets) {
                    const std::vector<EditorAssets::Asset> audioAssets = FindAudioAssets(*context.assets);
                    for (const EditorAssets::Asset& asset : audioAssets) {
                        const std::string fullPath = (std::filesystem::path(context.assets->RootPath()) / asset.relativePath).string();
                        const bool current = path == fullPath;
                        if (ImGui::Selectable(asset.relativePath.c_str(), current)) {
                            path = fullPath;
                            changed = true;
                        }
                        if (current) ImGui::SetItemDefaultFocus();
                    }
                }
                ImGui::EndCombo();
            }
            ImGui::Button("Drop audio asset here", ImVec2(-1.0f, 0.0f));
            if (ImGui::BeginDragDropTarget()) {
                if (const ImGuiPayload* payload = ImGui::AcceptDragDropPayload("3DGEDITOR_ASSET")) {
                    const std::string dropped(static_cast<const char*>(payload->Data));
                    std::string extension = std::filesystem::path(dropped).extension().string();
                    std::transform(extension.begin(), extension.end(), extension.begin(),
                        [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
                    if (extension == ".wav" || extension == ".flac" || extension == ".mp3" || extension == ".ogg") {
                        path = dropped;
                        changed = true;
                    }
                }
                ImGui::EndDragDropTarget();
            }
            changed |= ImGui::SliderFloat("Volume", &volume, 0.0f, 2.0f, "%.2f");
            changed |= ImGui::SliderFloat("Pitch", &pitch, 0.25f, 4.0f, "%.2f");
            if (ImGui::BeginCombo("Mixer Bus", engine::AudioBusName(bus))) {
                for (int i = static_cast<int>(engine::AudioBus::Master);
                     i <= static_cast<int>(engine::AudioBus::Ambient); ++i) {
                    const engine::AudioBus candidate = static_cast<engine::AudioBus>(i);
                    const bool current = candidate == bus;
                    if (ImGui::Selectable(engine::AudioBusName(candidate), current)) {
                        bus = candidate;
                        changed = true;
                    }
                    if (current) ImGui::SetItemDefaultFocus();
                }
                ImGui::EndCombo();
            }
            changed |= ImGui::Checkbox("Spatial (3D)", &spatial);
            ImGui::SameLine();
            changed |= ImGui::Checkbox("Loop", &loop);
            ImGui::SameLine();
            changed |= ImGui::Checkbox("Autoplay", &autoplay);
            if (spatial) {
                changed |= ImGui::DragFloat("Min Distance", &minDistance, 0.1f, 0.01f, 10000.0f);
                changed |= ImGui::DragFloat("Max Distance", &maxDistance, 0.25f, 0.01f, 10000.0f);
                maxDistance = std::max(maxDistance, minDistance);
                changed |= ImGui::DragFloat("Rolloff", &rolloff, 0.05f, 0.0f, 20.0f);
                changed |= ImGui::DragFloat("Doppler", &dopplerFactor, 0.05f, 0.0f, 10.0f);
                changed |= ImGui::SliderFloat("Cone Inner", &coneInnerAngle, 0.0f, 360.0f, "%.0f deg");
                changed |= ImGui::SliderFloat("Cone Outer", &coneOuterAngle,
                    coneInnerAngle, 360.0f, "%.0f deg");
                changed |= ImGui::SliderFloat("Cone Outer Gain", &coneOuterGain, 0.0f, 1.0f);
                changed |= ImGui::SliderFloat("Occlusion", &occlusion, 0.0f, 1.0f);
                ImGui::TextDisabled("Inner and outer attenuation ranges are shown in the viewport.");
            }
            changed |= ImGui::SliderInt("Voice Priority", &priority, 0, 100);
            if (changed) {
                context.scene->SetSelectedAudioSource(enabled, path, volume, pitch, spatial,
                    loop, autoplay, minDistance, maxDistance, rolloff, bus,
                    dopplerFactor, coneInnerAngle, coneOuterAngle, coneOuterGain,
                    occlusion, priority);
            }

            const bool canPreview = context.audioAvailable && !path.empty();
            if (!canPreview) ImGui::BeginDisabled();
            if (ImGui::Button("Preview")) {
                context.previewAudioRequested = true;
                context.previewAudioPath = path;
                context.previewAudioVolume = volume;
                context.previewAudioPitch = pitch;
                context.previewAudioSpatial = spatial;
                context.previewAudioLoop = loop;
                context.previewAudioMinDistance = minDistance;
                context.previewAudioMaxDistance = maxDistance;
                context.previewAudioRolloff = rolloff;
                context.previewAudioBus = bus;
            }
            if (!canPreview) ImGui::EndDisabled();
            ImGui::SameLine();
            if (ImGui::Button("Stop Preview")) context.stopAudioPreviewRequested = true;
            if (!context.audioAvailable) {
                ImGui::TextColored(ImVec4(1.0f, 0.55f, 0.25f, 1.0f), "No audio device is available.");
            }
            if (context.playMode) {
                ImGui::Separator();
                ImGui::TextUnformatted("Runtime Transport");
                if (!context.selectedRuntimeAudioAvailable) ImGui::BeginDisabled();
                if (ImGui::Button("Restart##RuntimeAudio")) context.runtimeAudioRestartRequested = true;
                ImGui::SameLine();
                const char* pauseLabel = context.selectedRuntimeAudioPaused
                    ? "Resume##RuntimeAudio" : "Pause##RuntimeAudio";
                if (ImGui::Button(pauseLabel)) context.runtimeAudioPauseResumeRequested = true;
                ImGui::SameLine();
                if (ImGui::Button("Stop##RuntimeAudio")) context.runtimeAudioStopRequested = true;
                if (!context.selectedRuntimeAudioAvailable) ImGui::EndDisabled();
                ImGui::Text("State: %s  |  %.2f s",
                    context.selectedRuntimeAudioPlaying ? "Playing"
                    : context.selectedRuntimeAudioPaused ? "Paused" : "Stopped",
                    context.selectedRuntimeAudioCursor);
            }
            if (ImGui::Button("Remove Audio Source")) {
                context.scene->SetSelectedAudioSource(false, path, volume, pitch, spatial,
                    loop, autoplay, minDistance, maxDistance, rolloff, bus,
                    dopplerFactor, coneInnerAngle, coneOuterAngle, coneOuterGain,
                    occlusion, priority);
            }
        }
    }

    if (selected->particleSystemEnabled) {
        if (ImGui::CollapsingHeader("Particle System", ImGuiTreeNodeFlags_DefaultOpen)) {
            ImGui::Text("Asset: %s%s", selected->particleAssetPath.empty()
                ? "(instance settings)" : selected->particleAssetPath.c_str(),
                selected->particleAssetOverride ? " (overridden)" : "");
            ImGui::TextDisabled("Particle authoring is available in the dedicated Particle Editor.");
            if (ImGui::Button("Open Particle Editor")) {
                context.panels->SetOpen(EditorPanels::Panel::ParticleEditor, true);
            }
            ImGui::SameLine();
            if (ImGui::Button("Remove Particle System Component")) {
                engine::ParticleSystemComponent settings;
                context.scene->SetSelectedParticleSystem(false, settings);
            }
        }
    }

// Legacy duplicate particle authoring UI is intentionally excluded. Particle
// settings are owned by ParticleEditorPanel; the Inspector only exposes the
// component summary and navigation button above.
#if 0
    if (selected->particleSystemEnabled) {
        if (ImGui::CollapsingHeader("Particle System", ImGuiTreeNodeFlags_DefaultOpen)) {
            engine::ParticleSystemComponent settings;
            settings.config = selected->particleConfig;
            settings.autoplay = selected->particleAutoplay;
            settings.loop = selected->particleLoop;
            settings.prewarm = selected->particlePrewarm;
            settings.duration = selected->particleDuration;
            settings.startDelay = selected->particleStartDelay;
            settings.simulationSpeed = selected->particleSimulationSpeed;
            settings.localSpace = selected->particleLocalSpace;
            settings.burstCount = selected->particleBurstCount;
            settings.burstInterval = selected->particleBurstInterval;
            bool enabled = selected->particleSystemEnabled;
            bool changed = false;

            ImGui::Text("Asset: %s%s", selected->particleAssetPath.empty()
                ? "(none - instance settings)" : selected->particleAssetPath.c_str(),
                selected->particleAssetOverride ? " (overridden)" : "");
            ImGui::Button("Drop .particle asset here", ImVec2(-1.0f, 0.0f));
            if (ImGui::BeginDragDropTarget()) {
                if (const ImGuiPayload* payload = ImGui::AcceptDragDropPayload("3DGEDITOR_ASSET")) {
                    const char* path = static_cast<const char*>(payload->Data);
                    if (path && std::filesystem::path(path).extension() == ".particle") {
                        engine::ParticleSystemComponent loaded;
                        std::string error;
                        if (particle_asset::Load(path, &loaded, &error))
                            context.scene->SetSelectedParticleAsset(path, loaded, false);
                        else if (context.log) context.log->Error("Particle asset: " + error);
                    }
                }
                ImGui::EndDragDropTarget();
            }

            changed |= ImGui::Checkbox("Enabled##ParticleSystem", &enabled);
            if (ImGui::TreeNodeEx("Playback", ImGuiTreeNodeFlags_DefaultOpen)) {
                changed |= ImGui::Checkbox("Autoplay##Particles", &settings.autoplay);
                ImGui::SameLine();
                changed |= ImGui::Checkbox("Loop##Particles", &settings.loop);
                ImGui::SameLine();
                changed |= ImGui::Checkbox("Prewarm##Particles", &settings.prewarm);
                ImGui::SameLine();
                changed |= ImGui::Checkbox("Local Space", &settings.localSpace);
                int simulationBackend = static_cast<int>(settings.config.simulationBackend);
                const char* simulationBackends[] = {"Auto", "CPU", "GPU Compute"};
                if (ImGui::Combo("Simulation Backend##Particles", &simulationBackend,
                                 simulationBackends, 3)) {
                    settings.config.simulationBackend =
                        static_cast<engine::ParticleSimulationBackend>(simulationBackend);
                    changed = true;
                }
                ImGui::TextDisabled("GPU compute requires OpenGL 4.3 and a supported feature set.");
                changed |= ImGui::DragFloat("Duration", &settings.duration, 0.1f, 0.0f, 10000.0f, "%.2f s");
                changed |= ImGui::DragFloat("Start Delay", &settings.startDelay, 0.05f, 0.0f, 10000.0f, "%.2f s");
                changed |= ImGui::DragFloat("Simulation Speed", &settings.simulationSpeed, 0.05f, 0.0f, 20.0f, "%.2fx");
                ImGui::TreePop();
            }
            if (ImGui::TreeNodeEx("Emission", ImGuiTreeNodeFlags_DefaultOpen)) {
                changed |= ImGui::DragFloat("Rate", &settings.config.rate, 1.0f, 0.0f, 100000.0f, "%.1f /s");
                changed |= ImGui::DragInt("Maximum", &settings.config.maxParticles, 10.0f, 1, 1000000);
                changed |= ImGui::DragInt("Burst Count", &settings.burstCount, 1.0f, 0, 1000000);
                changed |= ImGui::DragFloat("Burst Interval", &settings.burstInterval, 0.05f, 0.0f, 10000.0f, "%.2f s");
                ImGui::TreePop();
            }
            if (ImGui::TreeNodeEx("Shape", ImGuiTreeNodeFlags_DefaultOpen)) {
                int shape = static_cast<int>(settings.config.shape);
                const char* shapes[] = {"Point", "Sphere", "Cone"};
                if (ImGui::Combo("Emit Shape", &shape, shapes, 3)) {
                    settings.config.shape = static_cast<engine::EmitShape>(shape);
                    changed = true;
                }
                changed |= ImGui::DragFloat("Shape Radius", &settings.config.shapeRadius, 0.01f, 0.0f, 10000.0f);
                changed |= ImGui::DragFloat3("Direction##Particles", &settings.config.direction.x, 0.02f);
                if (settings.config.shape == engine::EmitShape::Cone)
                    changed |= ImGui::DragFloat("Cone Angle", &settings.config.coneAngleDeg, 0.5f, 0.0f, 180.0f, "%.1f deg");
                ImGui::TreePop();
            }
            if (ImGui::TreeNodeEx("Motion", ImGuiTreeNodeFlags_DefaultOpen)) {
                changed |= ImGui::DragFloatRange2("Speed", &settings.config.speedMin,
                    &settings.config.speedMax, 0.05f, -10000.0f, 10000.0f, "Min %.2f", "Max %.2f");
                changed |= ImGui::DragFloatRange2("Lifetime", &settings.config.lifeMin,
                    &settings.config.lifeMax, 0.05f, 0.001f, 10000.0f, "Min %.2f", "Max %.2f");
                changed |= ImGui::DragFloat3("Gravity##Particles", &settings.config.gravity.x, 0.05f);
                changed |= ImGui::DragFloat("Drag##Particles", &settings.config.drag, 0.02f, 0.0f, 1000.0f);
                ImGui::TreePop();
            }
            if (ImGui::TreeNodeEx("Collision", ImGuiTreeNodeFlags_DefaultOpen)) {
                changed |= ImGui::Checkbox("Enable Particle Collision", &settings.config.collisionEnabled);
                if (settings.config.collisionEnabled) {
                    int response = static_cast<int>(settings.config.collisionResponse);
                    const char* responses[] = {"Bounce", "Kill"};
                    if (ImGui::Combo("Response", &response, responses, 2)) {
                        settings.config.collisionResponse =
                            static_cast<engine::ParticleCollisionResponse>(response);
                        changed = true;
                    }
                    changed |= ImGui::DragFloat("Collision Radius", &settings.config.collisionRadius,
                        0.005f, 0.0f, 100.0f);
                    if (settings.config.collisionResponse == engine::ParticleCollisionResponse::Bounce) {
                        changed |= ImGui::SliderFloat("Bounce", &settings.config.collisionBounce, 0.0f, 2.0f);
                        changed |= ImGui::SliderFloat("Collision Friction", &settings.config.collisionFriction, 0.0f, 1.0f);
                        changed |= ImGui::SliderFloat("Lifetime Loss", &settings.config.collisionLifetimeLoss, 0.0f, 1.0f, "%.0f%%");
                    }
                    ImGui::TextDisabled("Plane, sphere and box are exact; other colliders use their bounds.");
                }
                ImGui::TreePop();
            }
            if (ImGui::TreeNodeEx("Trails / Ribbons", ImGuiTreeNodeFlags_DefaultOpen)) {
                changed |= ImGui::Checkbox("Enable Trails", &settings.config.trailsEnabled);
                if (settings.config.trailsEnabled) {
                    changed |= ImGui::SliderInt("Trail Segments", &settings.config.trailSegments, 2, 16);
                    changed |= ImGui::DragFloat("Trail Length", &settings.config.trailLength, 0.05f, 0.001f, 1000.0f);
                    changed |= ImGui::DragFloat("Trail Width", &settings.config.trailWidth, 0.01f, 0.0f, 100.0f);
                    changed |= ImGui::SliderFloat("Trail Opacity", &settings.config.trailOpacity, 0.0f, 1.0f);
                    ImGui::TextDisabled("Ribbons face the camera and taper along the motion history.");
                }
                ImGui::TreePop();
            }
            if (ImGui::TreeNodeEx("Renderer", ImGuiTreeNodeFlags_DefaultOpen)) {
                int renderMode = static_cast<int>(settings.config.renderMode);
                const char* renderModes[] = {"Billboard", "Mesh"};
                if (ImGui::Combo("Render Mode##Particles", &renderMode, renderModes, 2)) {
                    settings.config.renderMode = static_cast<engine::ParticleRenderMode>(renderMode);
                    changed = true;
                }
                if (settings.config.renderMode == engine::ParticleRenderMode::Mesh) {
                    int meshShape = static_cast<int>(settings.config.meshShape);
                    const char* meshShapes[] = {"Cube", "Sphere", "Cone", "Cylinder", "Model Asset"};
                    if (ImGui::Combo("Particle Mesh", &meshShape, meshShapes, 5)) {
                        settings.config.meshShape = static_cast<engine::ParticleMeshShape>(meshShape);
                        changed = true;
                    }
                    changed |= ImGui::DragFloat("Mesh Scale##Particles", &settings.config.meshScale,
                                                0.01f, 0.001f, 1000.0f);
                    changed |= ImGui::Checkbox("Align To Velocity##Particles",
                                               &settings.config.meshAlignToVelocity);
                    if (settings.config.meshShape == engine::ParticleMeshShape::Model) {
                        std::array<char, 512> particleMesh{};
                        std::snprintf(particleMesh.data(), particleMesh.size(), "%s",
                                      settings.config.meshPath.c_str());
                        if (ImGui::InputText("Model Asset##Particles", particleMesh.data(),
                                             particleMesh.size())) {
                            settings.config.meshPath = particleMesh.data(); changed = true;
                        }
                        if (ImGui::BeginDragDropTarget()) {
                            if (const ImGuiPayload* payload = ImGui::AcceptDragDropPayload("3DGEDITOR_ASSET")) {
                                const char* path = static_cast<const char*>(payload->Data);
                                if (path && *path) { settings.config.meshPath = path; changed = true; }
                            }
                            ImGui::EndDragDropTarget();
                        }
                        ImGui::TextDisabled("Drag a model from Assets. Failed models fall back to a cube.");
                    }
                }
                ImGui::TreePop();
            }
            if (ImGui::TreeNodeEx("Appearance", ImGuiTreeNodeFlags_DefaultOpen)) {
                changed |= ImGui::ColorEdit4("Start Color", &settings.config.startColor.x,
                    ImGuiColorEditFlags_Float | ImGuiColorEditFlags_HDR);
                changed |= ImGui::ColorEdit4("End Color", &settings.config.endColor.x,
                    ImGuiColorEditFlags_Float | ImGuiColorEditFlags_HDR);
                changed |= ImGui::DragFloat("Start Size", &settings.config.startSize, 0.01f, 0.0f, 10000.0f);
                changed |= ImGui::DragFloat("End Size", &settings.config.endSize, 0.01f, 0.0f, 10000.0f);
                changed |= ImGui::DragFloatRange2("Start Rotation", &settings.config.rotationMinDeg,
                    &settings.config.rotationMaxDeg, 1.0f, -360.0f, 360.0f, "Min %.0f", "Max %.0f");
                changed |= ImGui::DragFloatRange2("Rotation Speed", &settings.config.angularVelocityMinDeg,
                    &settings.config.angularVelocityMaxDeg, 1.0f, -2000.0f, 2000.0f, "Min %.0f", "Max %.0f");
                int blend = static_cast<int>(settings.config.blend);
                const char* blends[] = {"Additive", "Alpha"};
                if (ImGui::Combo("Blend", &blend, blends, 2)) {
                    settings.config.blend = static_cast<engine::ParticleBlend>(blend);
                    changed = true;
                }
                changed |= ImGui::Checkbox("Size Curve##Particles", &settings.config.useSizeCurve);
                if (settings.config.useSizeCurve)
                    changed |= ImGui::SliderFloat4("Size Keys", settings.config.sizeCurve.data(), 0.0f, 1.0f, "%.2f");
                changed |= ImGui::Checkbox("Color Curve##Particles", &settings.config.useColorCurve);
                if (settings.config.useColorCurve)
                    changed |= ImGui::SliderFloat4("Color Keys", settings.config.colorCurve.data(), 0.0f, 1.0f, "%.2f");

                std::array<char, 512> particleTexture{};
                std::snprintf(particleTexture.data(), particleTexture.size(), "%s",
                              settings.config.texturePath.c_str());
                if (ImGui::InputText("Texture##Particles", particleTexture.data(), particleTexture.size())) {
                    settings.config.texturePath = particleTexture.data(); changed = true;
                }
                if (ImGui::BeginDragDropTarget()) {
                    if (const ImGuiPayload* payload = ImGui::AcceptDragDropPayload("3DGEDITOR_ASSET")) {
                        const char* path = static_cast<const char*>(payload->Data);
                        if (path && *path) { settings.config.texturePath = path; changed = true; }
                    }
                    ImGui::EndDragDropTarget();
                }
                changed |= ImGui::DragInt("Texture Columns", &settings.config.textureColumns, 1.0f, 1, 64);
                changed |= ImGui::DragInt("Texture Rows", &settings.config.textureRows, 1.0f, 1, 64);
                changed |= ImGui::DragFloat("Texture FPS", &settings.config.textureFps, 0.5f, 0.0f, 240.0f);
                changed |= ImGui::Checkbox("Loop Flipbook", &settings.config.textureLoop);
                changed |= ImGui::Checkbox("Frustum Culling", &settings.config.cullingEnabled);
                changed |= ImGui::DragFloat("Bounds Radius", &settings.config.boundsRadius,
                                            0.05f, 0.01f, 10000.0f);
                ImGui::TreePop();
            }
            ImGui::TextUnformatted("Presets:");
            ImGui::SameLine();
            for (int i = 0; i < 5; ++i) {
                if (i > 0) ImGui::SameLine();
                const auto preset = static_cast<ParticlePreset>(i);
                if (ImGui::SmallButton(ParticlePresetName(preset))) {
                    settings = MakeParticlePreset(preset);
                    enabled = true;
                    context.scene->SetSelectedParticleSystem(true, settings);
                }
            }
            ImGui::SameLine();
            if (ImGui::SmallButton("Reset")) {
                settings = engine::ParticleSystemComponent{};
                enabled = true;
                context.scene->SetSelectedParticleSystem(true, settings);
            }
            if (changed) {
                if (ImGui::IsAnyItemActive()) context.scene->BeginParticleEdit();
                context.scene->SetSelectedParticleSystem(enabled, settings);
            }
            if (!ImGui::IsAnyItemActive()) context.scene->EndParticleEdit();
            for (const std::string& warning : ValidateParticleSettings(settings))
                ImGui::TextColored(ImVec4(1.0f, 0.72f, 0.2f, 1.0f), "! %s", warning.c_str());
            if (ImGui::Button("Remove Particle System"))
                context.scene->SetSelectedParticleSystem(false, settings);
        }
    }
#endif

    // Each runtime/physics component added via "+ Add Component" gets its own collapsing
    // header with a Remove button; the shared quick-setup buttons live in "Physics Setup".
    if (!isCharacter && selected->linearVelocityEnabled
        && ImGui::CollapsingHeader("Linear Velocity", ImGuiTreeNodeFlags_DefaultOpen)) {
        if (ImGui::SmallButton("Remove##LinearVelocity")) {
            context.scene->SetSelectedLinearVelocityEnabled(false);
        }
        glm::vec3 linearVelocity = selected->linearVelocity;
        if (ImGui::DragFloat3("Velocity", &linearVelocity.x, 0.05f)) {
            context.scene->SetSelectedLinearVelocity(linearVelocity);
        }
    }

    if (!isCharacter && selected->angularVelocityEnabled
        && ImGui::CollapsingHeader("Angular Velocity", ImGuiTreeNodeFlags_DefaultOpen)) {
        if (ImGui::SmallButton("Remove##AngularVelocity")) {
            context.scene->SetSelectedAngularVelocityEnabled(false);
        }
        glm::vec3 angularAxis = selected->angularVelocityAxis;
        float angularSpeed = selected->angularVelocityRadians;
        if (ImGui::DragFloat3("Axis", &angularAxis.x, 0.05f)) {
            context.scene->SetSelectedAngularVelocity(angularAxis, angularSpeed);
        }
        if (ImGui::DragFloat("Speed", &angularSpeed, 0.05f)) {
            context.scene->SetSelectedAngularVelocity(angularAxis, angularSpeed);
        }
        if (ImGui::Button("Spin Y")) {
            context.scene->SetSelectedAngularVelocity(glm::vec3(0.0f, 1.0f, 0.0f), 1.57f);
        }
    }

    // Shared physics quick-setup: always available on non-character objects, collapsed by
    // default so it stays out of the way. Adds/clears RigidBody + Collider in one click.
    if (!isCharacter && ImGui::CollapsingHeader("Physics Setup")) {
        if (ImGui::Button("Clear Runtime Motion")) {
            context.scene->SetSelectedLinearVelocityEnabled(false);
            context.scene->SetSelectedAngularVelocityEnabled(false);
        }
        const engine::ecs::Transform* selectedTransform = context.scene->TryGetTransform(selected->entity);
        if (ImGui::Button("Dynamic Body")) {
            engine::ecs::RigidBody rigidBody = engine::ecs::RigidBody::Dynamic(1.0f);
            rigidBody.velocity = selected->rigidBody.velocity;
            context.scene->SetSelectedRigidBody(rigidBody);

            engine::ecs::Collider collider = selected->colliderEnabled
                ? selected->collider
                : DefaultColliderForObject(*selected, selectedTransform);
            collider.isTrigger = false;
            context.scene->SetSelectedCollider(collider);
        }
        ImGui::SameLine();
        if (ImGui::Button("Static Collider")) {
            context.scene->SetSelectedRigidBodyEnabled(false);
            engine::ecs::Collider collider = selected->colliderEnabled
                ? selected->collider
                : DefaultColliderForObject(*selected, selectedTransform);
            collider.isTrigger = false;
            context.scene->SetSelectedCollider(collider);
        }
        if (ImGui::Button("Trigger##PhysicsPreset")) {
            context.scene->SetSelectedRigidBodyEnabled(false);
            engine::ecs::Collider collider = selected->colliderEnabled
                ? selected->collider
                : DefaultColliderForObject(*selected, selectedTransform);
            collider.isTrigger = true;
            context.scene->SetSelectedCollider(collider);
        }
        ImGui::SameLine();
        if (ImGui::Button("Clear Physics")) {
            context.scene->SetSelectedRigidBodyEnabled(false);
            context.scene->SetSelectedColliderEnabled(false);
        }

        // Colliders are world-sized (physics ignores Transform.scale), so a resized
        // object leaves its collider stale. Re-fit the collider's dimensions to the
        // current scale while preserving its shape, material and trigger flag.
        if (selected->colliderEnabled && selectedTransform) {
            if (ImGui::Button("Match Collider to Scale")) {
                engine::ecs::Collider collider = selected->collider;
                const glm::vec3 s = selectedTransform->scale;
                switch (collider.shape) {
                    case engine::ecs::ColliderShape::Box:
                        collider.halfExtents = glm::max(s * 0.5f, glm::vec3(0.001f));
                        break;
                    case engine::ecs::ColliderShape::Sphere:
                        collider.radius = std::max(std::max(s.x, std::max(s.y, s.z)) * 0.5f, 0.001f);
                        break;
                    case engine::ecs::ColliderShape::Capsule:
                        collider.radius = std::max(std::max(s.x, s.z) * 0.5f, 0.001f);
                        collider.halfHeight = std::max(s.y * 0.5f - collider.radius, 0.0f);
                        break;
                    case engine::ecs::ColliderShape::Cylinder:
                    case engine::ecs::ColliderShape::Cone:
                        collider.radius = std::max(std::max(s.x, s.z) * 0.5f, 0.001f);
                        collider.halfHeight = std::max(s.y * 0.5f, 0.001f);
                        collider.halfExtents = glm::vec3(collider.radius, collider.halfHeight, collider.radius);
                        break;
                    case engine::ecs::ColliderShape::Pyramid:
                    case engine::ecs::ColliderShape::Staircase:
                        collider.halfExtents = glm::max(s * 0.5f, glm::vec3(0.001f));
                        break;
                    case engine::ecs::ColliderShape::Torus:
                        collider.minorRadius = std::max(s.y * 0.5f, 0.001f);
                        collider.majorRadius = std::max(std::max(s.x, s.z) * 0.5f - collider.minorRadius, 0.001f);
                        collider.halfExtents = glm::vec3(collider.majorRadius + collider.minorRadius,
                            collider.minorRadius, collider.majorRadius + collider.minorRadius);
                        break;
                    case engine::ecs::ColliderShape::Plane:
                    default:
                        break;   // plane offset tracks position, not scale
                }
                context.scene->SetSelectedCollider(collider);
            }
            if (ImGui::IsItemHovered()) {
                ImGui::SetTooltip("Re-fit the collider to the object's current scale "
                                  "(physics uses collider size, not Transform scale).");
            }
        }

    }   // end Physics Setup

    if (!isCharacter && selected->rigidBodyEnabled
        && ImGui::CollapsingHeader("Rigid Body", ImGuiTreeNodeFlags_DefaultOpen)) {
        if (ImGui::SmallButton("Remove##RigidBody")) {
            context.scene->SetSelectedRigidBodyEnabled(false);
        }
            engine::ecs::RigidBody rigidBody = selected->rigidBody;
            bool dynamicBody = rigidBody.invMass > 0.0f;
            if (ImGui::Checkbox("Dynamic", &dynamicBody)) {
                if (dynamicBody && rigidBody.invMass <= 0.0f) {
                    rigidBody.invMass = 1.0f;
                    rigidBody.useGravity = true;
                } else if (!dynamicBody) {
                    rigidBody.invMass = 0.0f;
                    rigidBody.useGravity = false;
                }
                context.scene->SetSelectedRigidBody(rigidBody);
            }
            float mass = rigidBody.invMass > 0.0f ? 1.0f / rigidBody.invMass : 0.0f;
            if (ImGui::DragFloat("Mass", &mass, 0.05f, 0.0f, 10000.0f)) {
                rigidBody.invMass = mass > 0.0f ? 1.0f / mass : 0.0f;
                if (rigidBody.invMass == 0.0f) {
                    rigidBody.useGravity = false;
                }
                context.scene->SetSelectedRigidBody(rigidBody);
            }
            if (ImGui::DragFloat3("Physics Velocity", &rigidBody.velocity.x, 0.05f)) {
                context.scene->SetSelectedRigidBody(rigidBody);
            }
            if (ImGui::Checkbox("Gravity", &rigidBody.useGravity)) {
                context.scene->SetSelectedRigidBody(rigidBody);
            }
            if (ImGui::Checkbox("Allow Sleep", &rigidBody.allowSleep)) {
                context.scene->SetSelectedRigidBody(rigidBody);
            }
            if (ImGui::Checkbox("CCD", &rigidBody.ccd)) {
                context.scene->SetSelectedRigidBody(rigidBody);
            }
            if (ImGui::Checkbox("Freeze Rotation", &rigidBody.freezeRotation)) {
                if (rigidBody.freezeRotation) {
                    rigidBody.angularVelocity = glm::vec3(0.0f);
                    rigidBody.accumTorque = glm::vec3(0.0f);
                }
                context.scene->SetSelectedRigidBody(rigidBody);
            }
            if (ImGui::Checkbox("Kinematic", &rigidBody.kinematic)) {
                context.scene->SetSelectedRigidBody(rigidBody);
            }
            if (rigidBody.kinematic && ImGui::IsItemHovered()) {
                ImGui::SetTooltip("Moved by its velocity only (script/animation). Pushes dynamics; never pushed, never sleeps.");
            }
        }

    if (!isCharacter && selected->colliderEnabled
        && ImGui::CollapsingHeader("Collider", ImGuiTreeNodeFlags_DefaultOpen)) {
        if (ImGui::SmallButton("Remove##Collider")) {
            context.scene->SetSelectedColliderEnabled(false);
        }
            engine::ecs::Collider collider = selected->collider;
            int shapeIndex = ColliderShapeIndex(collider.shape);
            const char* shapes[] = {"Sphere", "Box", "Plane", "Capsule", "Cylinder", "Cone", "Pyramid", "Torus", "Staircase"};
            if (ImGui::Combo("Collider Shape", &shapeIndex, shapes, IM_ARRAYSIZE(shapes))) {
                const engine::ecs::ColliderShape newShape = ColliderShapeFromIndex(shapeIndex);
                if (newShape == engine::ecs::ColliderShape::Cylinder) {
                    // A shape switch should produce usable cylinder dimensions
                    // instead of inheriting arbitrary radius/height values from
                    // the previous collider type.
                    const engine::ecs::Transform* transform =
                        context.scene->TryGetTransform(selected->entity);
                    const float radius = transform
                        ? 0.5f * std::max(transform->scale.x, transform->scale.z)
                        : 0.5f;
                    const float height = transform ? transform->scale.y : 1.0f;

                    const float restitution = collider.restitution;
                    const float friction = collider.friction;
                    const bool trigger = collider.isTrigger;
                    const std::uint32_t layer = collider.layer;
                    const std::uint32_t mask = collider.mask;
                    collider = engine::ecs::Collider::MakeCylinder(
                        std::max(radius, 0.001f), std::max(height, 0.002f));
                    collider.restitution = restitution;
                    collider.friction = friction;
                    collider.isTrigger = trigger;
                    collider.layer = layer;
                    collider.mask = mask;
                } else {
                    collider.shape = newShape;
                }
                context.scene->SetSelectedCollider(collider);
            }
            if (collider.shape == engine::ecs::ColliderShape::Sphere) {
                if (ImGui::DragFloat("Radius", &collider.radius, 0.02f, 0.001f, 1000.0f)) {
                    context.scene->SetSelectedCollider(collider);
                }
            } else if (collider.shape == engine::ecs::ColliderShape::Box) {
                if (ImGui::DragFloat3("Half Extents", &collider.halfExtents.x, 0.02f, 0.001f, 1000.0f)) {
                    context.scene->SetSelectedCollider(collider);
                }
            } else if (collider.shape == engine::ecs::ColliderShape::Capsule) {
                bool changed = false;
                changed |= ImGui::DragFloat("Radius", &collider.radius, 0.02f, 0.001f, 1000.0f);
                changed |= ImGui::DragFloat("Half Height", &collider.halfHeight, 0.02f, 0.0f, 1000.0f);
                if (changed) {
                    context.scene->SetSelectedCollider(collider);
                }
            } else if (collider.shape == engine::ecs::ColliderShape::Cylinder
                || collider.shape == engine::ecs::ColliderShape::Cone) {
                bool changed = false;
                changed |= ImGui::DragFloat("Radius", &collider.radius, 0.02f, 0.001f, 1000.0f);
                changed |= ImGui::DragFloat("Half Height", &collider.halfHeight, 0.02f, 0.001f, 1000.0f);
                if (collider.shape == engine::ecs::ColliderShape::Cylinder) {
                    ImGui::TextDisabled("Vertical Y-axis cylinder. Total height = 2 x Half Height.");
                }
                if (changed) {
                    collider.halfExtents = glm::vec3(collider.radius, collider.halfHeight, collider.radius);
                    context.scene->SetSelectedCollider(collider);
                }
            } else if (collider.shape == engine::ecs::ColliderShape::Pyramid
                || collider.shape == engine::ecs::ColliderShape::Staircase) {
                bool changed = ImGui::DragFloat3("Half Extents", &collider.halfExtents.x, 0.02f, 0.001f, 1000.0f);
                if (collider.shape == engine::ecs::ColliderShape::Staircase)
                    changed |= ImGui::DragInt("Steps", &collider.steps, 0.1f, 1, 32);
                if (changed) context.scene->SetSelectedCollider(collider);
            } else if (collider.shape == engine::ecs::ColliderShape::Torus) {
                bool changed = false;
                changed |= ImGui::DragFloat("Major Radius", &collider.majorRadius, 0.02f, 0.001f, 1000.0f);
                changed |= ImGui::DragFloat("Minor Radius", &collider.minorRadius, 0.02f, 0.001f, 1000.0f);
                if (changed) {
                    const float outer = collider.majorRadius + collider.minorRadius;
                    collider.halfExtents = glm::vec3(outer, collider.minorRadius, outer);
                    context.scene->SetSelectedCollider(collider);
                }
            } else if (collider.shape == engine::ecs::ColliderShape::Plane) {
                if (ImGui::DragFloat3("Plane Normal", &collider.planeNormal.x, 0.02f)) {
                    context.scene->SetSelectedCollider(collider);
                }
                if (ImGui::DragFloat("Plane Offset", &collider.planeOffset, 0.02f)) {
                    context.scene->SetSelectedCollider(collider);
                }
            }
            if (ImGui::DragFloat("Restitution", &collider.restitution, 0.02f, 0.0f, 1.0f)) {
                context.scene->SetSelectedCollider(collider);
            }
            if (ImGui::DragFloat("Friction", &collider.friction, 0.02f, 0.0f, 10.0f)) {
                context.scene->SetSelectedCollider(collider);
            }
            if (ImGui::Checkbox("Overlap Only (Trigger)", &collider.isTrigger)) {
                context.scene->SetSelectedCollider(collider);
            }
            if (ImGui::IsItemHovered()) {
                ImGui::SetTooltip("Overlap events are generated, but this collider never blocks movement.");
            }

            int presetIndex = CollisionPresetIndex(collider);
            const char* presetPreview = presetIndex == 0
                ? "Custom" : kCollisionPresets[presetIndex - 1].name;
            if (ImGui::BeginCombo("Collision Preset", presetPreview)) {
                if (ImGui::Selectable("Custom", presetIndex == 0)) presetIndex = 0;
                for (int i = 0; i < static_cast<int>(IM_ARRAYSIZE(kCollisionPresets)); ++i) {
                    if (ImGui::Selectable(kCollisionPresets[i].name, presetIndex == i + 1)) {
                        const CollisionPresetDesc& preset = kCollisionPresets[i];
                        collider.layer = preset.layer;
                        collider.mask = preset.mask;
                        collider.isTrigger = preset.trigger;
                        context.scene->SetSelectedCollider(collider);
                    }
                }
                ImGui::EndCombo();
            }
            if (ImGui::IsItemHovered()) {
                ImGui::SetTooltip("Collectible overlaps Player, and is ignored by player movement and camera collision.");
            }

            int channelIndex = CollisionChannelIndex(collider.layer);
            if (ImGui::BeginCombo("Object Channel", kCollisionChannels[channelIndex].name)) {
                for (int i = 0; i < static_cast<int>(IM_ARRAYSIZE(kCollisionChannels)); ++i) {
                    if (ImGui::Selectable(kCollisionChannels[i].name, channelIndex == i)) {
                        collider.layer = kCollisionChannels[i].bit;
                        context.scene->SetSelectedCollider(collider);
                    }
                }
                ImGui::EndCombo();
            }

            if (ImGui::TreeNode("Channel Responses (Block / Ignore)")) {
                ImGui::TextDisabled("Checked channels interact; unchecked channels are ignored.");
                for (const CollisionChannelDesc& channel : kCollisionChannels) {
                    ImGui::PushID(static_cast<int>(channel.bit));
                    bool responds = (collider.mask & channel.bit) != 0u;
                    if (ImGui::Checkbox(channel.name, &responds)) {
                        if (responds) collider.mask |= channel.bit;
                        else collider.mask &= ~channel.bit;
                        context.scene->SetSelectedCollider(collider);
                    }
                    ImGui::PopID();
                }
                ImGui::TreePop();
            }
        }

        // Physics joints connect rigid bodies, so only surface this section when the
        // object is a rigid body or already participates in a joint (otherwise it's noise).
        const std::vector<EditorScene::PhysicsJoint>& allJoints = context.scene->PhysicsJoints();
        const bool showJoints = selected->rigidBodyEnabled
            || std::any_of(allJoints.begin(), allJoints.end(),
                [&](const EditorScene::PhysicsJoint& j) {
                    return j.objectA == selected->name || j.objectB == selected->name;
                });
        if (showJoints) ImGui::Separator();
        if (showJoints && ImGui::CollapsingHeader("Physics Joints", ImGuiTreeNodeFlags_DefaultOpen)) {
            static int jointTargetIndex = 0;
            const std::vector<EditorScene::Object>& objects = context.scene->Objects();
            if (jointTargetIndex >= static_cast<int>(objects.size())) {
                jointTargetIndex = 0;
            }

            const char* preview = "None";
            if (jointTargetIndex >= 0 && jointTargetIndex < static_cast<int>(objects.size())) {
                preview = objects[static_cast<std::size_t>(jointTargetIndex)].name.c_str();
            }

            if (ImGui::BeginCombo("Target", preview)) {
                for (std::size_t i = 0; i < objects.size(); ++i) {
                    if (objects[i].name == selected->name) {
                        continue;
                    }
                    const bool isSelected = jointTargetIndex == static_cast<int>(i);
                    if (ImGui::Selectable(objects[i].name.c_str(), isSelected)) {
                        jointTargetIndex = static_cast<int>(i);
                    }
                    if (isSelected) {
                        ImGui::SetItemDefaultFocus();
                    }
                }
                ImGui::EndCombo();
            }

            auto addJoint = [&](EditorScene::PhysicsJoint::Type type, bool rope) {
                if (jointTargetIndex < 0 || jointTargetIndex >= static_cast<int>(objects.size())) {
                    return;
                }
                const EditorScene::Object& target = objects[static_cast<std::size_t>(jointTargetIndex)];
                if (target.name == selected->name) {
                    return;
                }

                EditorScene::PhysicsJoint joint;
                joint.type = type;
                joint.objectA = selected->name;
                joint.objectB = target.name;
                joint.rope = rope;

                const engine::ecs::Transform* selectedJointTransform = context.scene->TryGetTransform(selected->entity);
                const engine::ecs::Transform* targetTransform = context.scene->TryGetTransform(target.entity);
                if (selectedJointTransform && targetTransform) {
                    joint.restLength = glm::length(targetTransform->position - selectedJointTransform->position);
                }
                if (joint.restLength <= 0.001f) {
                    joint.restLength = 1.0f;
                }
                context.scene->AddPhysicsJoint(joint);
            };

            if (ImGui::Button("Add Distance")) {
                addJoint(EditorScene::PhysicsJoint::Type::Distance, false);
            }
            ImGui::SameLine();
            if (ImGui::Button("Add Rope")) {
                addJoint(EditorScene::PhysicsJoint::Type::Distance, true);
            }
            ImGui::SameLine();
            if (ImGui::Button("Add Spring")) {
                addJoint(EditorScene::PhysicsJoint::Type::Spring, false);
            }

            const std::vector<EditorScene::PhysicsJoint>& joints = context.scene->PhysicsJoints();
            int shown = 0;
            for (std::size_t i = 0; i < joints.size(); ++i) {
                const EditorScene::PhysicsJoint& joint = joints[i];
                if (joint.objectA != selected->name && joint.objectB != selected->name) {
                    continue;
                }

                ImGui::PushID(static_cast<int>(i));
                EditorScene::PhysicsJoint edited = joint;
                if (ImGui::Checkbox("Enabled", &edited.enabled)) {
                    context.scene->SetPhysicsJoint(i, edited);
                }
                ImGui::SameLine();
                ImGui::Text("%s: %s <-> %s",
                    PhysicsJointTypeName(joint.type, joint.rope),
                    joint.objectA.c_str(),
                    joint.worldAnchor ? "World" : joint.objectB.c_str());
                if (ImGui::DragFloat("Rest Length", &edited.restLength, 0.05f, 0.001f, 10000.0f)) {
                    context.scene->SetPhysicsJoint(i, edited);
                }
                if (edited.type == EditorScene::PhysicsJoint::Type::Spring) {
                    bool changed = false;
                    changed |= ImGui::DragFloat("Stiffness", &edited.stiffness, 1.0f, 0.0f, 100000.0f);
                    changed |= ImGui::DragFloat("Damping", &edited.damping, 0.05f, 0.0f, 10000.0f);
                    if (changed) {
                        context.scene->SetPhysicsJoint(i, edited);
                    }
                }
                if (ImGui::Button("Delete Joint")) {
                    context.scene->RemovePhysicsJoint(i);
                    ImGui::PopID();
                    break;
                }
                ImGui::Separator();
                ImGui::PopID();
                ++shown;
            }
            if (shown == 0) {
                ImGui::TextUnformatted("No joints connected to this object.");
            }
        }   // end Physics Joints

    // A script is present as soon as it has a class or path (even before it is enabled --
    // "+ Add Script" registers the class name). It gets its own section below, separate
    // from the gameplay components, so adding a script never opens this section.
    const bool hasScript = selected->scriptEnabled
        || !selected->scriptClassName.empty() || !selected->scriptPath.empty();
    // Each gameplay component added via "+ Add Component" gets its own collapsing header;
    // its Remove button deletes it, after which the header no longer appears.
    if (!isCharacter && selected->rotatorEnabled
        && ImGui::CollapsingHeader("Rotator", ImGuiTreeNodeFlags_DefaultOpen)) {
            if (ImGui::SmallButton("Remove##Rotator")) {
                context.scene->SetSelectedRotatorEnabled(false);
            }
            engine::ecs::Rotator rotator = selected->rotator;
            bool changed = false;
            changed |= ImGui::DragFloat3("Rotator Axis", &rotator.axis.x, 0.05f);
            changed |= ImGui::DragFloat("Rotator Speed", &rotator.radiansPerSecond, 0.05f, -100.0f, 100.0f);
            if (changed) {
                context.scene->SetSelectedRotator(rotator);
            }
            if (ImGui::Button("Spin Y##Rotator")) {
                rotator.axis = glm::vec3(0.0f, 1.0f, 0.0f);
                rotator.radiansPerSecond = 1.57f;
                context.scene->SetSelectedRotator(rotator);
            }
        }

    if (!isCharacter && selected->moverEnabled
        && ImGui::CollapsingHeader("Mover", ImGuiTreeNodeFlags_DefaultOpen)) {
            if (ImGui::SmallButton("Remove##Mover")) {
                context.scene->SetSelectedMoverEnabled(false);
            }
            engine::ecs::Mover mover = selected->mover;
            bool changed = false;
            changed |= ImGui::DragFloat3("Mover Axis", &mover.axis.x, 0.05f);
            changed |= ImGui::DragFloat("Mover Distance", &mover.distance, 0.05f, 0.0f, 1000.0f);
            changed |= ImGui::DragFloat("Mover Speed", &mover.speed, 0.05f, -100.0f, 100.0f);
            changed |= ImGui::DragFloat("Mover Phase", &mover.phase, 0.05f, -1000.0f, 1000.0f);
            if (changed) {
                mover.initialized = false;
                context.scene->SetSelectedMover(mover);
            }
            if (ImGui::Button("Move X##Mover")) {
                mover.axis = glm::vec3(1.0f, 0.0f, 0.0f);
                mover.distance = 2.0f;
                mover.speed = 1.0f;
                mover.phase = 0.0f;
                mover.initialized = false;
                context.scene->SetSelectedMover(mover);
            }
        }

    if (!isCharacter && selected->playerControllerEnabled
        && ImGui::CollapsingHeader("Player Controller", ImGuiTreeNodeFlags_DefaultOpen)) {
            if (ImGui::SmallButton("Remove##PlayerController")) {
                context.scene->SetSelectedPlayerControllerEnabled(false);
            }
            EditorScene::PlayerControllerSettings player = selected->playerController;
            bool changed = false;
            const char* cameraModes[] = { "Third Person", "First Person", "Isometric", "Platformer" };
            int cameraMode = std::clamp(player.cameraMode, 0, 3);
            if (player.firstPerson && cameraMode == 0) cameraMode = 1; // legacy scene
            if (ImGui::Combo("Camera Mode", &cameraMode, cameraModes, IM_ARRAYSIZE(cameraModes))) {
                player.cameraMode = cameraMode;
                player.firstPerson = cameraMode == 1;
                changed = true;
            }
            const bool firstPerson = cameraMode == 1;
            const bool isometric = cameraMode == 2;
            const bool platformer = cameraMode == 3;
            changed |= ImGui::DragFloat("Walk Speed", &player.walkSpeed, 0.05f, 0.0f, 100.0f);
            changed |= ImGui::DragFloat("Run Speed", &player.runSpeed, 0.05f, 0.0f, 100.0f);
            changed |= ImGui::DragFloat("Jump Speed", &player.jumpSpeed, 0.05f, 0.0f, 100.0f);
            if (ImGui::TreeNodeEx("Crouching", ImGuiTreeNodeFlags_DefaultOpen
                    | ImGuiTreeNodeFlags_SpanAvailWidth)) {
                changed |= ImGui::DragFloat("Crouch Speed", &player.crouchSpeed,
                                            0.05f, 0.0f, 100.0f);
                changed |= ImGui::DragFloat("Crouched Height", &player.crouchedHeight,
                                            0.01f, player.capsuleRadius * 2.0f,
                                            player.capsuleHeight);
                ImGui::TextDisabled("Hold Ctrl or C. The capsule only stands when clear.");
                ImGui::TreePop();
            }
            if (ImGui::TreeNodeEx("Swimming", ImGuiTreeNodeFlags_DefaultOpen
                    | ImGuiTreeNodeFlags_SpanAvailWidth)) {
                changed |= ImGui::DragFloat("Swim Speed", &player.swimSpeed,
                                            0.05f, 0.0f, 100.0f);
                changed |= ImGui::DragFloat("Vertical Swim Speed", &player.swimVerticalSpeed,
                                            0.05f, 0.0f, 100.0f);
                ImGui::TextDisabled("WASD swims; Space rises; Ctrl or C descends.");
                ImGui::TreePop();
            }
            changed |= ImGui::DragFloat("Look Sensitivity", &player.lookSensitivity, 0.005f, 0.001f, 10.0f);
            changed |= ImGui::DragFloat("Capsule Radius", &player.capsuleRadius, 0.01f, 0.01f, 100.0f);
            changed |= ImGui::DragFloat("Capsule Height", &player.capsuleHeight, 0.01f, 0.02f, 100.0f);
            ImGui::TextDisabled("The controller capsule is authoritative in Play mode; the scene collider is an overlap proxy.");
            changed |= ImGui::DragFloat("Eye Height", &player.eyeHeight, 0.01f, 0.0f, 100.0f);
            changed |= ImGui::DragFloat("Camera Target Height", &player.cameraTargetHeight, 0.01f, 0.0f, 100.0f);
            if (isometric) {
                changed |= ImGui::DragFloat("Isometric Distance", &player.isometricDistance,
                                            0.1f, 0.0f, 500.0f);
                changed |= ImGui::SliderFloat("Isometric Yaw", &player.isometricYaw,
                                              -180.0f, 180.0f, "%.1f deg");
                changed |= ImGui::SliderFloat("Isometric Pitch", &player.isometricPitch,
                                              -89.0f, -5.0f, "%.1f deg");
                ImGui::TextDisabled("Fixed-angle camera; movement remains camera-relative.");
            } else if (platformer) {
                changed |= ImGui::DragFloat("Side Distance", &player.isometricDistance,
                                            0.1f, 0.0f, 500.0f);
                changed |= ImGui::SliderFloat("Camera Yaw", &player.platformerYaw,
                                              -180.0f, 180.0f, "%.1f deg");
                ImGui::TextDisabled("Side-on 2.5D camera: yaw picks the run axis "
                                    "(-90 = along X, 0 = along Z); the character faces "
                                    "its travel direction.");
            } else if (!firstPerson) {
                changed |= ImGui::DragFloat("Camera Distance", &player.cameraDistance,
                                            0.05f, 0.0f, 100.0f);
            }
            if (!firstPerson && ImGui::TreeNodeEx("Camera Collision",
                    ImGuiTreeNodeFlags_DefaultOpen | ImGuiTreeNodeFlags_SpanAvailWidth)) {
                changed |= ImGui::Checkbox("Collision Enabled", &player.cameraCollision);
                ImGui::BeginDisabled(!player.cameraCollision);
                changed |= ImGui::DragFloat("Probe Radius", &player.cameraProbeRadius,
                                            0.01f, 0.0f, 5.0f);
                changed |= ImGui::DragFloat("Wall Padding", &player.cameraCollisionPadding,
                                            0.005f, 0.0f, 2.0f);
                changed |= ImGui::DragFloat("Return Speed", &player.cameraReturnSpeed,
                                            0.1f, 0.0f, 100.0f);
                ImGui::TextDisabled("Retracts immediately; Return Speed smooths recovery.");
                ImGui::EndDisabled();
                ImGui::TreePop();
            }
            if (!firstPerson && ImGui::TreeNodeEx("Rotation",
                    ImGuiTreeNodeFlags_DefaultOpen | ImGuiTreeNodeFlags_SpanAvailWidth)) {
                const char* facingModes[] = { "Face Camera (strafe)", "Face Movement (free camera)" };
                int facing = (player.facingMode == 1) ? 1 : 0;
                if (ImGui::Combo("Orientation", &facing, facingModes, IM_ARRAYSIZE(facingModes))) {
                    player.facingMode = facing; changed = true;
                }
                if (player.facingMode == 1) {
                    changed |= ImGui::DragFloat("Turn Speed", &player.turnSpeed, 0.25f, 0.0f, 40.0f);
                    ImGui::TextDisabled("Character turns toward its travel direction; the camera orbits freely.");
                } else {
                    ImGui::TextDisabled("Character always faces the camera direction.");
                }
                ImGui::TreePop();
            }
            if (cameraMode == 0 && ImGui::TreeNodeEx("Shoulder Camera",
                    ImGuiTreeNodeFlags_DefaultOpen | ImGuiTreeNodeFlags_SpanAvailWidth)) {
                changed |= ImGui::Checkbox("Shoulder Camera Enabled", &player.shoulderCamera);
                ImGui::BeginDisabled(!player.shoulderCamera);
                changed |= ImGui::DragFloat("Shoulder Offset", &player.shoulderOffset,
                                            0.01f, 0.0f, 5.0f);
                changed |= ImGui::DragFloat("Shoulder Switch Speed", &player.shoulderSwitchSpeed,
                                            0.1f, 0.0f, 100.0f);
                changed |= ImGui::Checkbox("Start On Right Shoulder", &player.rightShoulder);
                ImGui::TextDisabled("Press Q in Play mode to switch shoulders.");
                ImGui::EndDisabled();
                ImGui::TreePop();
            }
            if (cameraMode == 0 && ImGui::TreeNodeEx("Lock-On Targeting",
                    ImGuiTreeNodeFlags_DefaultOpen | ImGuiTreeNodeFlags_SpanAvailWidth)) {
                changed |= ImGui::Checkbox("Lock-On Enabled", &player.lockOnEnabled);
                ImGui::BeginDisabled(!player.lockOnEnabled);
                changed |= ImGui::DragFloat("Lock-On Range", &player.lockOnRange,
                                            0.25f, 0.0f, 1000.0f);
                changed |= ImGui::SliderFloat("Acquisition View Angle", &player.lockOnViewAngle,
                                              0.0f, 180.0f, "%.1f deg");
                changed |= ImGui::DragFloat("Target Height", &player.lockOnTargetHeight,
                                            0.01f, -100.0f, 100.0f);
                changed |= ImGui::DragFloat("Tracking Speed", &player.lockOnTrackingSpeed,
                                            0.1f, 0.0f, 100.0f);
                ImGui::TextDisabled("Press T in Play mode to lock or release a living Health target.");
                ImGui::EndDisabled();
                ImGui::TreePop();
            }
            changed |= ImGui::DragFloat("Max Slope", &player.maxSlopeDegrees, 0.5f, 0.0f, 89.0f);
            changed |= ImGui::DragFloat("Step Height", &player.stepHeight, 0.01f, 0.0f, 10.0f);
            player.capsuleHeight = std::max(player.capsuleHeight, player.capsuleRadius * 2.0f);
            player.crouchedHeight = std::clamp(player.crouchedHeight,
                player.capsuleRadius * 2.0f, player.capsuleHeight);
            if (changed) {
                context.scene->SetSelectedPlayerController(player);
            }
        }

    if (!isCharacter && selected->cameraZoneEnabled
        && ImGui::CollapsingHeader("Camera Zone", ImGuiTreeNodeFlags_DefaultOpen)) {
            if (ImGui::SmallButton("Remove##CameraZone")) {
                context.scene->SetSelectedCameraZone(false,
                    selected->cameraZonePresetName,
                    selected->cameraZoneRestoreOnExit,
                    selected->cameraZonePriority,
                    selected->cameraZoneReturnBlend);
            }
            std::string presetName = selected->cameraZonePresetName;
            bool restoreOnExit = selected->cameraZoneRestoreOnExit;
            int priority = selected->cameraZonePriority;
            float returnBlend = selected->cameraZoneReturnBlend;
            bool changed = false;

            const char* preview = presetName.empty() ? "Choose camera..." : presetName.c_str();
            if (ImGui::BeginCombo("Zone Camera", preview)) {
                for (const EditorScene::CameraPreset& camera : context.scene->CameraPresets()) {
                    const bool selectedCamera = camera.name == presetName;
                    if (ImGui::Selectable(camera.name.c_str(), selectedCamera)) {
                        presetName = camera.name;
                        changed = true;
                    }
                    if (selectedCamera) ImGui::SetItemDefaultFocus();
                }
                if (context.scene->CameraPresets().empty()) {
                    ImGui::TextDisabled("Create a camera in Camera Manager first.");
                }
                ImGui::EndCombo();
            }
            changed |= ImGui::Checkbox("Restore Camera On Exit", &restoreOnExit);
            changed |= ImGui::DragInt("Zone Priority", &priority, 1.0f, -1000, 1000);
            changed |= ImGui::DragFloat("Exit Blend", &returnBlend, 0.05f, 0.0f, 30.0f, "%.2f s");
            if (!selected->colliderEnabled || !selected->collider.isTrigger) {
                ImGui::TextColored(ImVec4(1.0f, 0.72f, 0.2f, 1.0f),
                                   "Camera Zone requires a trigger collider.");
                if (ImGui::Button("Configure Trigger Collider")) changed = true;
            }
            if (changed) {
                context.scene->SetSelectedCameraZone(
                    true, presetName, restoreOnExit, priority, returnBlend);
            }
        }

    if (!isCharacter && selected->healthEnabled
        && ImGui::CollapsingHeader("Health", ImGuiTreeNodeFlags_DefaultOpen)) {
            if (ImGui::SmallButton("Remove##Health")) {
                context.scene->SetSelectedHealthEnabled(false);
            }
            engine::Health health = selected->health;
            bool changed = false;
            changed |= ImGui::DragFloat("HP", &health.hp, 1.0f, 0.0f, 100000.0f);
            changed |= ImGui::DragFloat("Max HP", &health.maxHp, 1.0f, 1.0f, 100000.0f);
            changed |= ImGui::Checkbox("Alive", &health.alive);
            if (ImGui::Button("Full Health")) {
                health.Reset(std::max(health.maxHp, 1.0f));
                changed = true;
            }
            if (changed) {
                context.scene->SetSelectedHealth(health);
            }

            bool ragdollEnabled = selected->ragdollEnabled;
            if (ImGui::Checkbox("Ragdoll On Death", &ragdollEnabled)) {
                context.scene->SetSelectedRagdollEnabled(ragdollEnabled);
            }
            if (ragdollEnabled) {
                engine::Ragdoll ragdoll = selected->ragdoll;
                bool ragdollChanged = false;
                ragdollChanged |= ImGui::DragFloat(
                    "Ragdoll Mass", &ragdoll.totalMass, 1.0f, 1.0f, 500.0f, "%.1f kg");
                ragdollChanged |= ImGui::SliderInt(
                    "Physics Bodies", &ragdoll.maxBodies, 4, 32);
                ragdollChanged |= ImGui::SliderFloat(
                    "Body Thickness", &ragdoll.bodyRadiusScale, 0.04f, 0.4f);
                ragdollChanged |= ImGui::DragFloat(
                    "Death Impulse", &ragdoll.deathImpulse, 0.05f, 0.0f, 20.0f);
                ragdollChanged |= ImGui::DragFloat(
                    "Linear Damping", &ragdoll.linearDamping, 0.02f, 0.0f, 10.0f);
                ragdollChanged |= ImGui::DragFloat(
                    "Angular Damping", &ragdoll.angularDamping, 0.02f, 0.0f, 20.0f);
                if (ragdollChanged) context.scene->SetSelectedRagdoll(ragdoll);
                ImGui::TextDisabled(
                    "Replaces animation with connected physics bodies at zero HP.");
            }
        }

    // Script is its own section, independent of the gameplay components -- adding a script
    // never opens Gameplay Components. Shown as soon as a script is present.
    if (!isCharacter && hasScript
        && ImGui::CollapsingHeader("Script", ImGuiTreeNodeFlags_DefaultOpen)) {
        if (g_scriptEntity != selected->entity) {
            std::snprintf(g_scriptClassBuffer.data(),
                g_scriptClassBuffer.size(),
                "%s",
                selected->scriptClassName.empty() ? "NewObjectScript" : selected->scriptClassName.c_str());
            g_scriptEntity = selected->entity;
            g_scriptLanguageIndex =
                std::filesystem::path(selected->scriptPath).extension() == ".lua" ? 1 : 0;
        }

        bool scriptEnabled = selected->scriptEnabled;
        if (ImGui::Checkbox("Script Enabled", &scriptEnabled)) {
            bool toggled = false;
            if (scriptEnabled) {
                // The class text box is intentionally buffered so it can be edited
                // without creating an undo entry for every key press. Enabling the
                // component is an explicit commit point, just like Attach.
                const std::string className = SanitizeScriptClassName(g_scriptClassBuffer.data());
                if (!className.empty() && className != selected->scriptClassName) {
                    toggled = context.scene->SetSelectedScript(
                        className, ScriptPathFor(
                            context, className, g_scriptLanguageIndex == 1), true);
                    if (toggled) {
                        std::snprintf(g_scriptClassBuffer.data(), g_scriptClassBuffer.size(), "%s", className.c_str());
                    }
                } else {
                    toggled = context.scene->SetSelectedScriptEnabled(true);
                }
            } else {
                toggled = context.scene->SetSelectedScriptEnabled(false);
            }

            if (!toggled && context.log) {
                context.log->Warning("Script toggle failed: enter a script class or unlock the object");
            }
        }

        const std::vector<SavedScriptEntry> savedScripts = SavedScriptsFor(context);
        const std::string bufferedClass = SanitizeScriptClassName(g_scriptClassBuffer.data());
        const auto selectedSavedScript = std::find_if(savedScripts.begin(), savedScripts.end(),
            [&bufferedClass, selected](const SavedScriptEntry& entry) {
                return entry.className == bufferedClass
                    && (selected->scriptPath.empty()
                        || std::filesystem::path(entry.storedPath).lexically_normal()
                            == std::filesystem::path(selected->scriptPath).lexically_normal());
            });
        const std::string savedScriptPreview = selectedSavedScript != savedScripts.end()
            ? selectedSavedScript->className
                + (selectedSavedScript->lua ? " (Lua)" : " (C++)")
            : "Choose saved script...";
        if (ImGui::BeginCombo("Saved Script", savedScriptPreview.c_str())) {
            for (const SavedScriptEntry& entry : savedScripts) {
                const bool isSelected = entry.className == bufferedClass
                    && entry.lua == (g_scriptLanguageIndex == 1);
                const std::string label =
                    entry.className + (entry.lua ? " (Lua)" : " (C++)");
                if (ImGui::Selectable(label.c_str(), isSelected)) {
                    std::snprintf(g_scriptClassBuffer.data(), g_scriptClassBuffer.size(),
                        "%s", entry.className.c_str());
                    g_scriptLanguageIndex = entry.lua ? 1 : 0;
                }
                if (isSelected) ImGui::SetItemDefaultFocus();
            }
            if (savedScripts.empty()) {
                ImGui::TextDisabled("No scripts found in Content/Scripts");
            }
            ImGui::EndCombo();
        }
        ImGui::InputText("Script Class", g_scriptClassBuffer.data(), g_scriptClassBuffer.size());
        const char* scriptLanguages[] = {"Native C++", "Lua"};
        ImGui::Combo("Language", &g_scriptLanguageIndex, scriptLanguages,
                     IM_ARRAYSIZE(scriptLanguages));
        ImGui::Text("Script Path: %s", selected->scriptPath.empty() ? "-" : selected->scriptPath.c_str());
        if (!selected->scriptClassName.empty()) {
            int executionOrder = selected->scriptExecutionOrder;
            if (ImGui::DragInt("Execution Order", &executionOrder, 1.0f, -10000, 10000)) {
                context.scene->SetSelectedScriptScheduling(
                    executionOrder, selected->scriptDependencies);
            }
            if (ImGui::IsItemHovered()) {
                ImGui::SetTooltip(
                    "Lower values run first. Required scripts always run before this value.");
            }

            std::vector<std::string> dependencies = selected->scriptDependencies;
            const std::string dependencyPreview = dependencies.empty()
                ? "None" : std::to_string(dependencies.size()) + " selected";
            if (ImGui::BeginCombo("Required Scripts", dependencyPreview.c_str())) {
                for (const SavedScriptEntry& entry : savedScripts) {
                    if (entry.className == selected->scriptClassName) continue;
                    const auto found = std::find(
                        dependencies.begin(), dependencies.end(), entry.className);
                    bool required = found != dependencies.end();
                    if (ImGui::Selectable(entry.className.c_str(), required,
                                          ImGuiSelectableFlags_DontClosePopups)) {
                        if (required) dependencies.erase(found);
                        else dependencies.push_back(entry.className);
                        context.scene->SetSelectedScriptScheduling(
                            selected->scriptExecutionOrder, dependencies);
                    }
                }
                if (savedScripts.empty())
                    ImGui::TextDisabled("No saved scripts are available.");
                ImGui::EndCombo();
            }
            ImGui::TextDisabled(
                "Dependencies control initialization, frame, fixed, and event order.");
        }
        const std::string currentClass = SanitizeScriptClassName(g_scriptClassBuffer.data());
        const bool creatingLua = g_scriptLanguageIndex == 1;
        const bool classExists = std::any_of(savedScripts.begin(), savedScripts.end(),
            [&currentClass, creatingLua](const SavedScriptEntry& entry) {
                return entry.className == currentClass && entry.lua == creatingLua;
            });

        // The template picker only matters when creating a brand-new script.
        if (!classExists && !creatingLua) {
            const char* scriptTemplates[] = {
                "Empty",
                "Player Movement",
                "Door Opener",
                "Pickup",
                "Damage Zone",
                "Patrol",
                "Follow",
                "Projectile"
            };
            ImGui::Combo("New Script Template", &g_scriptTemplateIndex, scriptTemplates,
                         IM_ARRAYSIZE(scriptTemplates));
        } else if (!classExists) {
            ImGui::TextDisabled(
                "Lua creates a lifecycle starter; add inspector fields below.");
        }

        // One context-aware action replaces the old Create/Attach split: attach the class
        // if it already exists in Content/Scripts, otherwise create it from the template.
        if (ImGui::Button(classExists ? "Attach Script" : "Create + Attach")) {
            const std::string className = currentClass;
            if (className.empty()) {
                if (context.log) context.log->Warning("Enter a script class name first");
            } else if (classExists) {
                const auto saved = std::find_if(savedScripts.begin(), savedScripts.end(),
                    [&className, creatingLua](const SavedScriptEntry& entry) {
                        return entry.className == className && entry.lua == creatingLua;
                    });
                const std::string scriptPath = saved != savedScripts.end()
                    ? saved->storedPath
                    : ScriptPathFor(context, className, creatingLua);
                if (context.scene->SetSelectedScript(className, scriptPath, true)) {
                    if (context.log) context.log->Info("Attached script: " + className);
                } else if (context.log) {
                    const EditorScene::Object* current = context.scene->SelectedObject();
                    if (current && current->scriptEnabled
                        && current->scriptClassName == className) {
                        context.log->Info("Script is already attached: " + className);
                    } else {
                        context.log->Warning("Script attach failed: no unlocked object selected");
                    }
                }
            } else {
                const ScriptTemplate scriptTemplate = creatingLua
                    ? ScriptTemplate::Empty
                    : ScriptTemplateFromIndex(g_scriptTemplateIndex);
                std::string scriptPath;
                std::string error;
                if (CreateScriptFiles(context, className, scriptTemplate, creatingLua,
                                      &scriptPath, &error)) {
                    if (!IsBehaviorTreeTemplate(scriptTemplate)) {
                        context.scene->SetSelectedScript(className, scriptPath, true);
                        context.scene->SetSelectedScriptFields(DefaultFieldsForTemplate(scriptTemplate));
                    }
                    std::snprintf(g_scriptClassBuffer.data(), g_scriptClassBuffer.size(), "%s", className.c_str());
                    std::string sourceError;
                    if (!LoadScriptSource(scriptPath, &sourceError)) {
                        if (context.log) context.log->Warning(
                            "Created script but could not open source: " + sourceError);
                    } else {
                        g_scriptEditorWindowOpen = true;
                    }
                    if (context.assets) {
                        std::string refreshError;
                        context.assets->Refresh(context.assets->RootPath(), &refreshError);
                    }
                    if (context.log) {
                        if (IsBehaviorTreeTemplate(scriptTemplate)) {
                            context.log->Info("Created AI script: " + scriptPath
                                + " (compile it, then select the class in the Behavior Graph)");
                        } else {
                            context.log->Info(std::string("Created ")
                                + (creatingLua ? "Lua script: " : "script: ") + scriptPath);
                        }
                    }
                } else if (context.log) {
                    context.log->Error("Script create failed: " + error);
                }
            }
        }
        ImGui::SameLine();
        if (ImGui::Button("Remove")) {
            if (context.scene->SetSelectedScript(std::string(), std::string(), false)) {
                std::snprintf(g_scriptClassBuffer.data(), g_scriptClassBuffer.size(), "%s", "NewObjectScript");
                if (context.log) {
                    context.log->Info("Removed script from selected object");
                }
            } else if (context.log) {
                context.log->Warning("Script remove failed: selected object is locked");
            }
        }

        if (!selected->scriptPath.empty()) {
            ImGui::SameLine();
            if (ImGui::Button("Edit Source")) {
                std::string error;
                if (!LoadScriptSource(selected->scriptPath, &error) && context.log) {
                    context.log->Error("Script source open failed: " + error);
                }
            }
        }

        if (g_scriptSourceLoaded && !selected->scriptPath.empty()
            && std::filesystem::path(g_scriptSourcePath).lexically_normal()
                == std::filesystem::path(selected->scriptPath).lexically_normal()
            && ImGui::TreeNode("Script Source")) {
            const bool editingLua =
                std::filesystem::path(selected->scriptPath).extension() == ".lua";
            ImGui::TextWrapped(editingLua
                ? "Lua runs in Editor Play and packaged games. Save it, then restart Play to load the new source."
                : "This header is compiled into both Editor Play and the standalone game. Save it, then rebuild and restart the editor to load native code changes.");
            if (ImGui::InputTextMultiline("##ScriptSource",
                    g_scriptSourceBuffer.data(), g_scriptSourceBuffer.size(),
                    ImVec2(-1.0f, 340.0f), ImGuiInputTextFlags_AllowTabInput)) {
                g_scriptSourceDirty = true;
            }
            if (ImGui::Button(g_scriptSourceDirty ? "Save Source *" : "Save Source")) {
                std::string error;
                if (WriteTextFile(g_scriptSourcePath, g_scriptSourceBuffer.data(), &error)) {
                    g_scriptSourceDirty = false;
                    if (context.log) context.log->Info("Saved script source: " + g_scriptSourcePath);
                } else if (context.log) {
                    context.log->Error("Script source save failed: " + error);
                }
            }
            ImGui::SameLine();
            if (ImGui::Button("Reload Source")) {
                std::string error;
                if (!LoadScriptSource(g_scriptSourcePath, &error) && context.log) {
                    context.log->Error("Script source reload failed: " + error);
                }
            }
            ImGui::SameLine();
            ImGui::TextDisabled(g_scriptSourceDirty ? "Unsaved changes"
                : (editingLua ? "Saved - restart Play to reload"
                              : "Saved - rebuild required"));
            ImGui::TreePop();
        }

        if (ImGui::Button("Add Field")) {
            if (!context.scene->AddSelectedScriptField() && context.log) {
                context.log->Warning("Script field add failed: selected object is locked");
            }
        }
        ImGui::SameLine();
        if (ImGui::Button("Detect Fields from Source")) {
            if (selected->scriptPath.empty()) {
                if (context.log) context.log->Warning("Attach or create a script first, then detect fields");
            } else {
                std::string sourceError;
                if (!LoadScriptSource(selected->scriptPath, &sourceError)) {
                    if (context.log) context.log->Error("Detect fields failed: " + sourceError);
                } else {
                    const std::vector<EditorScene::ScriptField> detected =
                        DetectScriptFields(g_scriptSourceBuffer.data());
                    std::vector<EditorScene::ScriptField> merged = selected->scriptFields;
                    int added = 0;
                    for (const EditorScene::ScriptField& d : detected) {
                        const bool exists = std::any_of(merged.begin(), merged.end(),
                            [&](const EditorScene::ScriptField& f) { return f.name == d.name; });
                        if (!exists) { merged.push_back(d); ++added; }
                    }
                    if (added > 0) context.scene->SetSelectedScriptFields(merged);
                    if (context.log) context.log->Info("Detected "
                        + std::to_string(detected.size()) + " field(s) from source; added "
                        + std::to_string(added) + " new");
                }
            }
        }

        // Group fields under collapsible headers by their (editor-only) group name; the
        // ungrouped set ("") renders first with no header.
        std::vector<std::string> scriptFieldGroups;
        for (const EditorScene::ScriptField& groupField : selected->scriptFields) {
            if (std::find(scriptFieldGroups.begin(), scriptFieldGroups.end(), groupField.group)
                == scriptFieldGroups.end()) {
                scriptFieldGroups.push_back(groupField.group);
            }
        }
        bool scriptFieldRemoved = false;
        for (const std::string& scriptFieldGroup : scriptFieldGroups) {
            if (scriptFieldRemoved) break;
            if (!scriptFieldGroup.empty()
                && !ImGui::CollapsingHeader((scriptFieldGroup + "##scriptfieldgroup").c_str(),
                                            ImGuiTreeNodeFlags_DefaultOpen)) {
                continue;
            }
            for (std::size_t i = 0; i < selected->scriptFields.size(); ++i) {
                if (selected->scriptFields[i].group != scriptFieldGroup) continue;
            const EditorScene::ScriptField& sourceField = selected->scriptFields[i];
            EditorScene::ScriptField field = sourceField;
            ImGui::PushID(static_cast<int>(i));
            ImGui::Separator();

            std::array<char, 64> nameBuffer{};
            std::array<char, 128> valueBuffer{};
            std::snprintf(nameBuffer.data(), nameBuffer.size(), "%s", field.name.c_str());
            std::snprintf(valueBuffer.data(), valueBuffer.size(), "%s", field.value.c_str());

            bool changed = false;
            if (ImGui::InputText("Field", nameBuffer.data(), nameBuffer.size())) {
                field.name = SanitizeScriptClassName(nameBuffer.data());
                changed = true;
            }

            int typeIndex = ScriptFieldTypeIndex(field.type);
            const char* fieldTypes[] = {"Float", "Int", "Bool", "String",
                                        "Vec3", "Color", "Entity", "Asset"};
            if (ImGui::Combo("Type", &typeIndex, fieldTypes, IM_ARRAYSIZE(fieldTypes))) {
                field.type = ScriptFieldTypeFromIndex(typeIndex);
                if (field.type == EditorScene::ScriptField::Type::Bool
                    && field.value != "0"
                    && field.value != "1") {
                    field.value = "0";
                }
                changed = true;
            }

            using FieldType = EditorScene::ScriptField::Type;
            if (field.type == FieldType::Bool) {
                bool value = field.value == "1" || field.value == "true" || field.value == "True";
                if (ImGui::Checkbox("Value", &value)) {
                    field.value = value ? "1" : "0";
                    changed = true;
                }
            } else if (field.type == FieldType::Vec3 || field.type == FieldType::Color) {
                float v[3] = {0.0f, 0.0f, 0.0f};
                std::sscanf(field.value.c_str(), "%f %f %f", &v[0], &v[1], &v[2]);
                const bool edited = field.type == FieldType::Color
                    ? ImGui::ColorEdit3("Value", v)
                    : ImGui::DragFloat3("Value", v, 0.05f);
                if (edited) {
                    std::array<char, 96> out{};
                    std::snprintf(out.data(), out.size(), "%g %g %g", v[0], v[1], v[2]);
                    field.value = out.data();
                    changed = true;
                }
            } else if (field.type == FieldType::Entity) {
                const char* preview = field.value.empty() ? "None" : field.value.c_str();
                if (ImGui::BeginCombo("Value", preview)) {
                    if (ImGui::Selectable("None", field.value.empty())) {
                        field.value.clear();
                        changed = true;
                    }
                    for (const EditorScene::Object& object : context.scene->Objects()) {
                        if (ImGui::Selectable(object.name.c_str(), object.name == field.value)) {
                            field.value = object.name;
                            changed = true;
                        }
                    }
                    ImGui::EndCombo();
                }
            } else if ((field.type == FieldType::Float || field.type == FieldType::Int)
                       && field.maxValue > field.minValue) {
                // A range was set, so present a bounded slider instead of a free input.
                if (field.type == FieldType::Float) {
                    float v = 0.0f;
                    std::sscanf(field.value.c_str(), "%f", &v);
                    if (ImGui::SliderFloat("Value", &v, field.minValue, field.maxValue)) {
                        std::array<char, 64> out{};
                        std::snprintf(out.data(), out.size(), "%g", v);
                        field.value = out.data();
                        changed = true;
                    }
                } else {
                    int v = 0;
                    std::sscanf(field.value.c_str(), "%d", &v);
                    if (ImGui::SliderInt("Value", &v,
                            static_cast<int>(field.minValue), static_cast<int>(field.maxValue))) {
                        field.value = std::to_string(v);
                        changed = true;
                    }
                }
            } else if (ImGui::InputText("Value", valueBuffer.data(), valueBuffer.size())) {
                // Float / Int / String / Asset are edited as text (Asset holds a path).
                field.value = valueBuffer.data();
                if (field.value.empty()) {
                    field.value = (field.type == FieldType::String
                                   || field.type == FieldType::Asset) ? "-" : "0";
                }
                changed = true;
            }
            if (!field.tooltip.empty() && ImGui::IsItemHovered()) {
                ImGui::SetTooltip("%s", field.tooltip.c_str());
            }

            if (ImGui::TreeNode("Field settings")) {
                std::array<char, 64> groupBuffer{};
                std::snprintf(groupBuffer.data(), groupBuffer.size(), "%s", field.group.c_str());
                if (ImGui::InputText("Group", groupBuffer.data(), groupBuffer.size())) {
                    field.group = groupBuffer.data();
                    changed = true;
                }
                if (field.type == FieldType::Float || field.type == FieldType::Int) {
                    if (ImGui::DragFloat("Min", &field.minValue, 0.1f)) changed = true;
                    if (ImGui::DragFloat("Max", &field.maxValue, 0.1f)) changed = true;
                    ImGui::TextDisabled("Set Max > Min to show a slider.");
                }
                std::array<char, 160> tipBuffer{};
                std::snprintf(tipBuffer.data(), tipBuffer.size(), "%s", field.tooltip.c_str());
                if (ImGui::InputText("Tooltip", tipBuffer.data(), tipBuffer.size())) {
                    field.tooltip = tipBuffer.data();
                    changed = true;
                }
                ImGui::TreePop();
            }

            if (changed) {
                context.scene->SetSelectedScriptField(i, field);
            }

            if (ImGui::Button("Remove Field")) {
                context.scene->RemoveSelectedScriptField(i);
                ImGui::PopID();
                scriptFieldRemoved = true;
                break;
            }
            ImGui::PopID();
            }
        }
    }   // end Script

    if (!isCharacter && selected->colliderEnabled && selected->collider.isTrigger) {
            ImGui::Separator();
            std::string targetName = selected->triggerTargetName;
            EditorScene::TriggerActionMode enterMoverAction = selected->triggerEnterMoverAction;
            EditorScene::TriggerActionMode enterRotatorAction = selected->triggerEnterRotatorAction;
            EditorScene::TriggerActionMode exitMoverAction = selected->triggerExitMoverAction;
            EditorScene::TriggerActionMode exitRotatorAction = selected->triggerExitRotatorAction;
            engine::ecs::AudioAction enterAudioAction = selected->triggerEnterAudioAction;
            engine::ecs::AudioAction exitAudioAction = selected->triggerExitAudioAction;
            engine::ParticleAction enterParticleAction = selected->triggerEnterParticleAction;
            engine::ParticleAction exitParticleAction = selected->triggerExitParticleAction;
            const char* preview = targetName.empty() ? "None" : targetName.c_str();
            if (ImGui::BeginCombo("Trigger Target", preview)) {
                if (ImGui::Selectable("None", targetName.empty())) {
                    targetName.clear();
                    context.scene->SetSelectedTriggerAction(targetName,
                        enterMoverAction,
                        enterRotatorAction,
                        exitMoverAction,
                        exitRotatorAction,
                        enterAudioAction,
                        exitAudioAction,
                        enterParticleAction,
                        exitParticleAction);
                }
                for (const EditorScene::Object& object : context.scene->Objects()) {
                    if (object.name == selected->name) {
                        continue;
                    }
                    const bool isSelectedTarget = object.name == targetName;
                    if (ImGui::Selectable(object.name.c_str(), isSelectedTarget)) {
                        targetName = object.name;
                        context.scene->SetSelectedTriggerAction(targetName,
                            enterMoverAction,
                            enterRotatorAction,
                            exitMoverAction,
                            exitRotatorAction,
                            enterAudioAction,
                            exitAudioAction,
                            enterParticleAction,
                            exitParticleAction);
                    }
                    if (isSelectedTarget) {
                        ImGui::SetItemDefaultFocus();
                    }
                }
                ImGui::EndCombo();
            }
            bool changed = false;
            changed |= DrawTriggerActionModeCombo("Enter Mover", &enterMoverAction);
            changed |= DrawTriggerActionModeCombo("Enter Rotator", &enterRotatorAction);
            changed |= DrawTriggerActionModeCombo("Exit Mover", &exitMoverAction);
            changed |= DrawTriggerActionModeCombo("Exit Rotator", &exitRotatorAction);
            changed |= DrawAudioActionCombo("Enter Audio", &enterAudioAction);
            changed |= DrawAudioActionCombo("Exit Audio", &exitAudioAction);
            changed |= DrawParticleActionCombo("Enter Particles", &enterParticleAction);
            changed |= DrawParticleActionCombo("Exit Particles", &exitParticleAction);
            if ((enterAudioAction != engine::ecs::AudioAction::None
                 || exitAudioAction != engine::ecs::AudioAction::None)
                && !targetName.empty()) {
                const EditorScene::Object* targetObject = nullptr;
                for (const EditorScene::Object& object : context.scene->Objects()) {
                    if (object.name == targetName) { targetObject = &object; break; }
                }
                if (!targetObject || !targetObject->audioSourceEnabled) {
                    ImGui::TextColored(ImVec4(1.0f, 0.72f, 0.25f, 1.0f),
                        "Target has no Audio Source component.");
                }
            }
            if ((enterParticleAction != engine::ParticleAction::None
                 || exitParticleAction != engine::ParticleAction::None)
                && !targetName.empty()) {
                const EditorScene::Object* targetObject = nullptr;
                for (const EditorScene::Object& object : context.scene->Objects()) {
                    if (object.name == targetName) { targetObject = &object; break; }
                }
                if (!targetObject || !targetObject->particleSystemEnabled) {
                    ImGui::TextColored(ImVec4(1.0f, 0.72f, 0.25f, 1.0f),
                        "Target has no Particle System component.");
                }
            }
            if (changed) {
                context.scene->SetSelectedTriggerAction(targetName,
                    enterMoverAction,
                    enterRotatorAction,
                    exitMoverAction,
                    exitRotatorAction,
                    enterAudioAction,
                    exitAudioAction,
                    enterParticleAction,
                    exitParticleAction);
            }

            ImGui::Separator();
            ImGui::TextUnformatted("Cinematic Trigger");
            std::string sequenceName = selected->triggerCameraSequenceName;
            auto enterCameraAction = selected->triggerEnterCameraAction;
            auto exitCameraAction = selected->triggerExitCameraAction;
            bool lockInput = selected->triggerCameraLockInput;
            bool skippable = selected->triggerCameraSkippable;
            bool cameraChanged = false;
            const char* sequencePreview = sequenceName.empty()
                ? "Choose sequence..." : sequenceName.c_str();
            if (ImGui::BeginCombo("Cinematic Sequence", sequencePreview)) {
                if (ImGui::Selectable("None", sequenceName.empty())) {
                    sequenceName.clear();
                    cameraChanged = true;
                }
                for (const EditorScene::CameraSequence& sequence
                     : context.scene->CameraSequences()) {
                    const bool isSelected = sequence.name == sequenceName;
                    if (ImGui::Selectable(sequence.name.c_str(), isSelected)) {
                        sequenceName = sequence.name;
                        cameraChanged = true;
                    }
                    if (isSelected) ImGui::SetItemDefaultFocus();
                }
                ImGui::EndCombo();
            }
            cameraChanged |= DrawCameraSequenceTriggerActionCombo(
                "Enter Cinematic", &enterCameraAction);
            cameraChanged |= DrawCameraSequenceTriggerActionCombo(
                "Exit Cinematic", &exitCameraAction);
            cameraChanged |= ImGui::Checkbox("Lock Player Input", &lockInput);
            cameraChanged |= ImGui::Checkbox("Allow Enter To Skip", &skippable);
            if (cameraChanged) {
                context.scene->SetSelectedTriggerCameraSequence(
                    sequenceName, enterCameraAction, exitCameraAction,
                    lockInput, skippable);
            }
            if ((enterCameraAction == EditorScene::CameraSequenceTriggerAction::Play
                 || exitCameraAction == EditorScene::CameraSequenceTriggerAction::Play)
                && sequenceName.empty()) {
                ImGui::TextColored(ImVec4(1.0f, 0.72f, 0.25f, 1.0f),
                                   "Choose a sequence for the Play action.");
            }
        }

    // Only shown once a Navigation Agent has been added via "+ Add Component".
    if (!isCharacter && selected->navAgentEnabled
        && ImGui::CollapsingHeader("AI Agent", ImGuiTreeNodeFlags_DefaultOpen)) {
        bool  enabled  = selected->navAgentEnabled;
        float speed    = selected->navAgentSpeed;
        float maxForce = selected->navAgentMaxForce;
        float reach    = selected->navAgentReachRadius;
        float repath   = selected->navAgentRepathInterval;
        std::string targetName = selected->navAgentTargetName;
        float visionRange = selected->navAgentVisionRange;
        float visionHalfAngle = selected->navAgentVisionHalfAngle;
        float hearingRange = selected->navAgentHearingRange;
        float squadAlertRadius = selected->navAgentSquadAlertRadius;
        float squadForgetTime = selected->navAgentSquadForgetTime;
        bool changed = false;
        changed |= ImGui::Checkbox("Nav Agent", &enabled);
        if (enabled) {
            changed |= ImGui::DragFloat("Speed", &speed, 0.05f, 0.0f, 50.0f, "%.2f");
            changed |= ImGui::DragFloat("Max Force", &maxForce, 0.1f, 0.0f, 200.0f, "%.1f");
            changed |= ImGui::DragFloat("Reach Radius", &reach, 0.02f, 0.05f, 10.0f, "%.2f");
            changed |= ImGui::DragFloat("Repath (s)", &repath, 0.02f, 0.05f, 5.0f, "%.2f");

            // Chase target: an object the agent pursues when it can see it.
            const char* targetPreview = targetName.empty() ? "None (patrol only)" : targetName.c_str();
            if (ImGui::BeginCombo("Chase Target", targetPreview)) {
                if (ImGui::Selectable("None (patrol only)", targetName.empty())) {
                    targetName.clear();
                    changed = true;
                }
                for (const EditorScene::Object& object : context.scene->Objects()) {
                    if (object.name == selected->name) {
                        continue;
                    }
                    const bool isTarget = object.name == targetName;
                    if (ImGui::Selectable(object.name.c_str(), isTarget)) {
                        targetName = object.name;
                        changed = true;
                    }
                    if (isTarget) {
                        ImGui::SetItemDefaultFocus();
                    }
                }
                ImGui::EndCombo();
            }
            if (!targetName.empty()) {
                changed |= ImGui::DragFloat("Vision Range", &visionRange, 0.1f, 0.0f, 100.0f, "%.1f");
                changed |= ImGui::DragFloat("Vision Half-Angle", &visionHalfAngle, 0.5f, 1.0f, 180.0f, "%.0f deg");
            }
            changed |= ImGui::DragFloat("Hearing Range", &hearingRange, 0.1f, 0.0f, 100.0f, "%.1f");
            if (ImGui::IsItemHovered()) {
                ImGui::SetTooltip("Omnidirectional radius for hearing noises (footsteps, combat). 0 = deaf.");
            }
            changed |= ImGui::DragFloat("Squad Alert Radius", &squadAlertRadius, 0.1f, 0.0f, 100.0f, "%.1f");
            if (ImGui::IsItemHovered()) {
                ImGui::SetTooltip("How close a teammate must be to respond to this agent's alert.");
            }
            changed |= ImGui::DragFloat("Squad Forget (s)", &squadForgetTime, 0.1f, 0.1f, 60.0f, "%.1f");
            if (ImGui::IsItemHovered()) {
                ImGui::SetTooltip("How long this agent's sighting keeps its squad alerted after losing the target.");
            }

            // Faction targeting: team id + auto-acquire nearest hostile.
            int  team = selected->navAgentTeam;
            bool autoTarget = selected->navAgentAutoTarget;
            bool teamChanged = false;
            teamChanged |= ImGui::DragInt("Team (0 = neutral)", &team, 0.1f, 0, 32);
            teamChanged |= ImGui::Checkbox("Auto-target nearest hostile", &autoTarget);
            if (autoTarget) {
                ImGui::TextDisabled("Chases the nearest agent on a different non-zero team.");
            }
            if (teamChanged) {
                context.scene->SetSelectedNavAgentTeam(team, autoTarget);
            }
        }
        if (changed) {
            context.scene->SetSelectedNavAgent(enabled, speed, maxForce, reach, repath,
                                               targetName, visionRange, visionHalfAngle, hearingRange,
                                               squadAlertRadius, squadForgetTime);
        }
        if (enabled) {
            ImGui::Text("Patrol points: %d", static_cast<int>(selected->patrolPoints.size()));
            if (ImGui::Button("Add Waypoint (object pos)")) {
                if (const engine::ecs::Transform* t = context.scene->TryGetTransform(selected->entity)) {
                    context.scene->AddSelectedPatrolPoint(t->position);
                }
            }
            ImGui::SameLine();
            if (ImGui::Button("Clear Waypoints")) {
                context.scene->ClearSelectedPatrolPoints();
            }
            ImGui::TextDisabled("Move the object between adds to build a patrol loop, then Play.");

            if (ImGui::TreeNodeEx("AI Movement", ImGuiTreeNodeFlags_DefaultOpen)) {
                int movementMode = selected->navMovementMode == engine::ai::AiMovementMode::Flying
                    ? 1 : 0;
                float gravity = selected->navMovementGravity;
                float maxFallSpeed = selected->navMovementMaxFallSpeed;
                float groundProbe = selected->navMovementGroundProbe;
                float stepHeight = selected->navMovementStepHeight;
                float maxSlope = selected->navMovementMaxSlope;
                const char* modes[] = {"Grounded / Falling", "Flying"};
                bool movementChanged = ImGui::Combo("Movement Mode", &movementMode,
                                                     modes, IM_ARRAYSIZE(modes));
                if (movementMode == 0) {
                    movementChanged |= ImGui::DragFloat(
                        "Gravity", &gravity, 0.1f, -100.0f, 0.0f, "%.2f m/s2");
                    movementChanged |= ImGui::DragFloat(
                        "Maximum Fall Speed", &maxFallSpeed, 0.25f, 0.0f, 200.0f, "%.2f m/s");
                    movementChanged |= ImGui::DragFloat(
                        "Ground Probe", &groundProbe, 0.01f, 0.02f, 5.0f, "%.2f m");
                    movementChanged |= ImGui::DragFloat(
                        "Step Height", &stepHeight, 0.01f, 0.0f, 5.0f, "%.2f m");
                    movementChanged |= ImGui::DragFloat(
                        "Maximum Slope", &maxSlope, 0.5f, 0.0f, 89.0f, "%.1f deg");
                    ImGui::TextDisabled("Navigation stays horizontal; gravity and floor probes control height.");
                } else {
                    ImGui::TextDisabled("Flying agents follow the Behavior Tree target in 3D and ignore gravity.");
                }
                if (movementChanged) {
                    context.scene->SetSelectedNavAgentMovement(
                        movementMode == 1 ? engine::ai::AiMovementMode::Flying
                                          : engine::ai::AiMovementMode::Grounded,
                        gravity, maxFallSpeed, groundProbe, stepHeight, maxSlope);
                }
                ImGui::TreePop();
            }

            // An optional authored tree overrides the built-in patrol/chase/search
            // brain at Play time. Every .btgraph under Content is available here.
            ImGui::Separator();
            const std::string& brain = selected->navAgentBrainAsset;
            const std::string brainPreview = brain.empty()
                ? "Built-in (patrol/chase/search)"
                : std::filesystem::path(brain).filename().string();
            ImGui::SetNextItemWidth(280.0f);
            if (ImGui::BeginCombo("Behavior Tree", brainPreview.c_str())) {
                if (ImGui::Selectable("Built-in (patrol/chase/search)", brain.empty())) {
                    context.scene->SetSelectedNavAgentBrain(std::string());
                }
                if (context.assets) {
                    const std::vector<EditorAssets::Asset> graphs =
                        FindBehaviorGraphAssets(*context.assets);
                    if (graphs.empty()) ImGui::TextDisabled("No .btgraph assets in Content");
                    for (const EditorAssets::Asset& graph : graphs) {
                        const std::string fullPath =
                            (std::filesystem::path(context.assets->RootPath()) /
                             graph.relativePath).lexically_normal().string();
                        const bool current = std::filesystem::path(brain).lexically_normal()
                            == std::filesystem::path(fullPath).lexically_normal();
                        const std::string itemLabel =
                            graph.displayName + "###BehaviorTree/" + graph.relativePath;
                        if (ImGui::Selectable(itemLabel.c_str(), current)) {
                            context.scene->SetSelectedNavAgentBrain(fullPath);
                        }
                        if (ImGui::IsItemHovered()
                            && graph.relativePath != graph.displayName) {
                            ImGui::SetTooltip("Content/%s", graph.relativePath.c_str());
                        }
                        if (current) ImGui::SetItemDefaultFocus();
                    }
                }
                ImGui::EndCombo();
            }
            ImGui::TextDisabled("Choose a saved Behavior Tree asset to run during Play.");
        }
    }

    if (selected->decal && ImGui::CollapsingHeader(
            "Decal", ImGuiTreeNodeFlags_DefaultOpen)) {
        float opacity = selected->decalOpacity;
        float offset = selected->decalSurfaceOffset;
        bool changed = false;
        changed |= ImGui::SliderFloat("Opacity##Decal", &opacity, 0.0f, 1.0f, "%.2f");
        changed |= ImGui::SliderFloat("Surface Offset##Decal", &offset,
                                      0.001f, 0.08f, "%.3f m");
        if (changed) context.scene->SetSelectedDecalSettings(opacity, offset);
        ImGui::TextDisabled("Use W/E/R to position, rotate and resize this decal.");
    }

    // Landscape authoring belongs to the dedicated Terrain Creator. Keep the
    // former scene-object controls dormant so selecting a placed landscape in
    // the level only exposes ordinary object controls in the Inspector.
    constexpr bool terrainAuthoringInInspector = false;
    if (terrainAuthoringInInspector && selected->isTerrain
        && ImGui::CollapsingHeader("Terrain", ImGuiTreeNodeFlags_DefaultOpen)) {
        int   res = selected->terrainRes;
        float size = selected->terrainSize;
        float maxHeight = selected->terrainMaxHeight;
        int   seed = selected->terrainSeed;
        int   octaves = selected->terrainOctaves;
        float frequency = selected->terrainFrequency;
        bool changed = false;
        {
            changed |= ImGui::DragInt("Resolution", &res, 1.0f, 8, 1024);
            changed |= ImGui::DragFloat("Size (m)", &size, 0.5f, 1.0f, 2000.0f, "%.1f");
            changed |= ImGui::DragFloat("Max Height", &maxHeight, 0.1f, 0.0f, 500.0f, "%.1f");
            changed |= ImGui::DragInt("Seed", &seed, 1.0f, 0, 1000000);
            changed |= ImGui::DragInt("Octaves", &octaves, 0.1f, 1, 10);
            changed |= ImGui::DragFloat("Frequency", &frequency, 0.05f, 0.1f, 16.0f, "%.2f");
            if (ImGui::Button("Randomize Seed")) {
                seed = static_cast<int>((static_cast<unsigned>(seed) * 1103515245u + 12345u) & 0x7fffffffu);
                changed = true;
            }
            ImGui::TextDisabled("Regenerates on change. Positioned by the object's Transform; "
                                "grass/rock/snow colouring is by height + slope.");

            if (ImGui::TreeNodeEx("Import from Gaea", ImGuiTreeNodeFlags_DefaultOpen)) {
                const std::string selectedPath = context.assets
                    ? context.assets->SelectedAssetFullPath() : std::string{};
                const std::string selectedExt = LowerExtension(selectedPath);
                const bool supported = selectedExt == ".png" || selectedExt == ".raw" || selectedExt == ".r16";
                ImGui::TextWrapped("Export a heightfield from Gaea as 16-bit grayscale PNG or RAW16, "
                                   "place it in Content, and select it in Assets.");
                ImGui::Text("Selected: %s", selectedPath.empty()
                    ? "(select a heightmap in Assets)"
                    : std::filesystem::path(selectedPath).filename().string().c_str());
                ImGui::DragFloat("Imported World Size (m)", &g_gaeaImport.worldSize, 1.0f, 1.0f, 100000.0f, "%.1f");
                ImGui::DragFloat("Imported Max Height (m)", &g_gaeaImport.maxHeight, 1.0f, 0.0f, 10000.0f, "%.1f");
                const char* resolutionCaps[] = {"256", "512", "1024"};
                ImGui::Combo("Maximum Resolution", &g_gaeaImport.maxResolutionIndex,
                             resolutionCaps, IM_ARRAYSIZE(resolutionCaps));
                ImGui::Checkbox("Flip X", &g_gaeaImport.flipX);
                ImGui::SameLine();
                ImGui::Checkbox("Flip Z", &g_gaeaImport.flipZ);
                ImGui::SameLine();
                ImGui::Checkbox("Invert Height", &g_gaeaImport.invertHeight);
                if (selectedExt == ".raw" || selectedExt == ".r16")
                    ImGui::Checkbox("RAW Big Endian", &g_gaeaImport.rawBigEndian);

                if (!supported) ImGui::BeginDisabled();
                if (ImGui::Button("Import Selected Heightmap")) {
                    GaeaRaster raster;
                    std::string importError;
                    if (!LoadGaeaRaster(selectedPath, g_gaeaImport.rawBigEndian, raster, importError)) {
                        if (context.log) context.log->Error("Gaea import: " + importError);
                    } else {
                        const int caps[] = {256, 512, 1024};
                        const int cap = caps[std::clamp(g_gaeaImport.maxResolutionIndex, 0, 2)];
                        const int importedResolution = std::clamp(
                            std::max(raster.width, raster.height), 8, cap);
                        std::vector<float> imported = ResampleGaeaRaster(
                            raster, importedResolution, g_gaeaImport.flipX,
                            g_gaeaImport.flipZ, g_gaeaImport.invertHeight);
                        for (float& value : imported) value *= std::max(g_gaeaImport.maxHeight, 0.0f);
                        if (context.scene->SetSelectedTerrain(
                                true, importedResolution, g_gaeaImport.worldSize,
                                g_gaeaImport.maxHeight, seed, octaves, frequency)
                            && context.scene->SetSelectedTerrainHeights(std::move(imported))) {
                            if (context.log) {
                                context.log->Info("Imported Gaea heightmap: "
                                    + std::to_string(raster.width) + "x" + std::to_string(raster.height)
                                    + " (" + std::to_string(raster.bitDepth) + "-bit) -> terrain "
                                    + std::to_string(importedResolution) + "x"
                                    + std::to_string(importedResolution));
                            }
                        } else if (context.log) {
                            context.log->Error("Gaea import failed: terrain is locked or unavailable.");
                        }
                    }
                }
                if (!supported) ImGui::EndDisabled();
                if (selectedExt == ".exr")
                    ImGui::TextColored(ImVec4(1.0f, 0.65f, 0.25f, 1.0f),
                                       "EXR is not supported; export PNG16 or RAW16 from Gaea.");

                ImGui::Separator();
                ImGui::TextUnformatted("Gaea Mask to Paint Layer");
                const char* maskLayers[] = {"Grass", "Rock", "Dirt", "Snow", "Sand"};
                int maskLayerIndex = std::clamp(g_gaeaImport.maskLayer - 1, 0, 4);
                if (ImGui::Combo("Target Layer", &maskLayerIndex, maskLayers, IM_ARRAYSIZE(maskLayers)))
                    g_gaeaImport.maskLayer = maskLayerIndex + 1;
                ImGui::SliderFloat("Mask Threshold", &g_gaeaImport.maskThreshold, 0.0f, 1.0f, "%.2f");
                ImGui::Checkbox("Invert Mask", &g_gaeaImport.invertMask);
                ImGui::Checkbox("Replace Existing Target Layer", &g_gaeaImport.clearLayerBeforeMask);
                if (!supported) ImGui::BeginDisabled();
                if (ImGui::Button("Import Selected Mask")) {
                    GaeaRaster raster;
                    std::string importError;
                    if (!LoadGaeaRaster(selectedPath, g_gaeaImport.rawBigEndian, raster, importError)) {
                        if (context.log) context.log->Error("Gaea mask import: " + importError);
                    } else {
                        const int targetRes = selected->terrainRes;
                        const std::vector<float> mask = ResampleGaeaRaster(
                            raster, targetRes, g_gaeaImport.flipX, g_gaeaImport.flipZ,
                            g_gaeaImport.invertMask);
                        std::vector<unsigned char> paint = selected->terrainPaint;
                        if (paint.size() != mask.size()) paint.assign(mask.size(), 0);
                        if (g_gaeaImport.clearLayerBeforeMask) {
                            for (unsigned char& layer : paint)
                                if (layer == g_gaeaImport.maskLayer) layer = 0;
                        }
                        std::size_t painted = 0;
                        for (std::size_t i = 0; i < mask.size(); ++i) {
                            if (mask[i] >= g_gaeaImport.maskThreshold) {
                                paint[i] = static_cast<unsigned char>(g_gaeaImport.maskLayer);
                                ++painted;
                            }
                        }
                        if (context.scene->SetSelectedTerrainPaint(std::move(paint))) {
                            if (context.log) context.log->Info("Imported Gaea mask to terrain layer "
                                + std::to_string(g_gaeaImport.maskLayer) + " ("
                                + std::to_string(painted) + " vertices painted)");
                        } else if (context.log) {
                            context.log->Error("Gaea mask import failed: terrain is locked.");
                        }
                    }
                }
                if (!supported) ImGui::EndDisabled();
                ImGui::TreePop();
            }

            // Sculpting: brush tools that edit the heightmap directly in the viewport.
            if (context.terrainSculpt && context.terrainSculptMode &&
                context.terrainBrushRadius && context.terrainBrushStrength) {
                ImGui::Separator();
                ImGui::Checkbox("Sculpt mode (left-drag in viewport)", context.terrainSculpt);
                if (*context.terrainSculpt) {
                    const char* modes[] = {"Raise", "Lower", "Smooth", "Flatten", "Paint", "Erase"};
                    ImGui::Combo("Brush", context.terrainSculptMode, modes, IM_ARRAYSIZE(modes));
                    if (*context.terrainSculptMode == 4 && context.terrainPaintLayer) {
                        const char* layers[] = {"Erase (auto)", "Grass", "Rock", "Dirt", "Snow", "Sand"};
                        ImGui::Combo("Layer", context.terrainPaintLayer, layers, IM_ARRAYSIZE(layers));
                        const int activeLayer = *context.terrainPaintLayer;   // 0 = erase, 1..5 = paintable
                        if (activeLayer >= 1 && activeLayer <= 5) {
                            const std::string& assigned =
                                selected->terrainLayerMaterials[static_cast<std::size_t>(activeLayer - 1)];
                            ImGui::Text("Material: %s", assigned.empty() ? "(default colour)" : assigned.c_str());
                            const EditorAssets::Asset* sel =
                                context.assets ? context.assets->SelectedAsset() : nullptr;
                            const bool selIsMaterial = sel && IsMaterialDocument(sel->relativePath);
                            if (!selIsMaterial) ImGui::BeginDisabled();
                            if (ImGui::Button("Use Selected Material")) {
                                context.scene->SetSelectedTerrainLayerMaterial(activeLayer, sel->relativePath);
                            }
                            if (!selIsMaterial) ImGui::EndDisabled();
                            ImGui::SameLine();
                            if (ImGui::Button("Clear Material")) {
                                context.scene->SetSelectedTerrainLayerMaterial(activeLayer, std::string());
                            }
                            ImGui::TextDisabled("Select a .3dgmat in Assets, then Use Selected Material. "
                                                "Empty layers keep the default palette colour.");
                        }
                    }
                    ImGui::DragFloat("Brush Radius", context.terrainBrushRadius, 0.1f, 0.5f, 100.0f, "%.1f");
                    if (*context.terrainSculptMode != 4 && *context.terrainSculptMode != 5) {
                        ImGui::DragFloat("Brush Strength", context.terrainBrushStrength, 0.1f, 0.1f, 50.0f, "%.1f");
                    }
                    if (*context.terrainSculptMode == 5) {
                        ImGui::TextDisabled("Erase: clears paint + grass under the brush.");
                    }
                    ImGui::TextColored(ImVec4(0.5f, 0.8f, 1.0f, 1.0f),
                                       "Editing: object selection/move is paused.");
                }
            }
        }
        if (changed) {
            context.scene->SetSelectedTerrain(true, res, size, maxHeight, seed, octaves, frequency);
        }

        // Grass: instanced blades grown on the painted Grass layer.
        ImGui::Separator();
        bool grassEnabled = selected->grassEnabled;
        if (ImGui::Checkbox("Grass (grows on painted Grass layer)", &grassEnabled)) {
            context.scene->SetSelectedTerrainGrass(grassEnabled, selected->grassDensity,
                selected->grassHeight, selected->grassWindStrength, selected->grassWindSpeed,
                selected->grassBaseColor, selected->grassTipColor,
                selected->grassRandomizeHeight, selected->grassMinHeightScale,
                selected->grassMaxHeightScale);
        }
        if (selected->grassEnabled) {
            float density = selected->grassDensity, height = selected->grassHeight;
            float windStr = selected->grassWindStrength, windSpd = selected->grassWindSpeed;
            bool randomizeHeight = selected->grassRandomizeHeight;
            float minHeightScale = selected->grassMinHeightScale;
            float maxHeightScale = selected->grassMaxHeightScale;
            glm::vec3 base = selected->grassBaseColor, tip = selected->grassTipColor;
            bool gc = false;
            gc |= ImGui::DragFloat("Grass Density", &density, 0.05f, 0.05f, 40.0f, "%.2f");
            gc |= ImGui::DragFloat("Grass Height", &height, 0.01f, 0.05f, 5.0f, "%.2f");
            gc |= ImGui::Checkbox("Randomize Grass Height", &randomizeHeight);
            ImGui::BeginDisabled(!randomizeHeight);
            gc |= ImGui::DragFloatRange2("Height Range", &minHeightScale, &maxHeightScale,
                0.01f, 0.05f, 4.0f, "Min %.2fx", "Max %.2fx");
            ImGui::EndDisabled();
            gc |= ImGui::DragFloat("Wind Strength", &windStr, 0.01f, 0.0f, 2.0f, "%.2f");
            gc |= ImGui::DragFloat("Wind Speed", &windSpd, 0.02f, 0.0f, 8.0f, "%.2f");
            gc |= ImGui::ColorEdit3("Grass Root", &base.x);
            gc |= ImGui::ColorEdit3("Grass Tip", &tip.x);
            if (gc) {
                context.scene->SetSelectedTerrainGrass(true, density, height, windStr, windSpd,
                    base, tip, randomizeHeight, minHeightScale, maxHeightScale);
            }
            ImGui::TextDisabled("These settings apply to grass you paint NEXT. Grass already on the "
                                "field keeps the settings it was painted with. Paint the Grass layer "
                                "(Sculpt > Paint > Grass) to grow grass; wind is shared by all grass.");
            ImGui::TextDisabled("Height randomization is a multiplier of Grass Height and applies "
                                "to the whole field when enabled.");
        }
    }

    if (selected->isFoliage && ImGui::CollapsingHeader("Foliage", ImGuiTreeNodeFlags_DefaultOpen)) {
        const EditorAssets::Asset* contentSelection = context.assets
            ? context.assets->SelectedAsset() : nullptr;
        const bool selectedStaticMesh = contentSelection
            && contentSelection->type == EditorAssets::Type::Model;
        if (!selectedStaticMesh) ImGui::BeginDisabled();
        if (ImGui::Button("Create Type From Selected Mesh") && context.assets) {
            const std::string meshPath = context.assets->SelectedAssetFullPath();
            const std::filesystem::path folder =
                std::filesystem::path(context.assets->RootPath()) / "Assets" / "Foliage";
            std::error_code directoryError;
            std::filesystem::create_directories(folder, directoryError);
            engine::FoliageAssetData foliage;
            foliage.name = std::filesystem::path(meshPath).stem().string() + " Foliage";
            engine::FoliageTypeAsset type;
            type.name = std::filesystem::path(meshPath).stem().string();
            type.meshPath = meshPath;
            foliage.types.push_back(std::move(type));
            const std::filesystem::path savePath = folder /
                (std::filesystem::path(meshPath).stem().string() + ".3dgfoliage");
            std::string saveError;
            if (!directoryError && engine::SaveFoliageAsset(savePath.string(), foliage, &saveError)) {
                context.scene->SetSelectedFoliageAsset(savePath.string());
                std::string refreshError;
                context.assets->Refresh(context.assets->RootPath(), &refreshError);
                if (context.runtimeAssets)
                    context.runtimeAssets->ResolveRegistryAssets(context.scene->Registry());
                if (context.log) context.log->Info("Created foliage asset: " + savePath.string());
            } else if (context.log) {
                context.log->Error("Could not create foliage asset: "
                    + (saveError.empty() ? directoryError.message() : saveError));
            }
        }
        if (!selectedStaticMesh) ImGui::EndDisabled();
        ImGui::SameLine();
        ImGui::TextDisabled("Select a static mesh in Content first");

        const std::vector<std::string> assets = context.assets
            ? context.assets->ContentAssetPaths(EditorAssets::Type::Foliage)
            : std::vector<std::string>{};
        std::string currentLabel = selected->foliageAssetPath.empty()
            ? std::string("Choose foliage asset...")
            : std::filesystem::path(selected->foliageAssetPath).filename().string();
        if (ImGui::BeginCombo("Foliage Asset", currentLabel.c_str())) {
            for (const std::string& relative : assets) {
                const std::string full = context.assets
                    ? (std::filesystem::path(context.assets->RootPath()) / relative).string()
                    : relative;
                const bool chosen = selected->foliageAssetPath == full
                    || selected->foliageAssetPath == relative;
                if (ImGui::Selectable(relative.c_str(), chosen)) {
                    context.scene->SetSelectedFoliageAsset(full);
                    if (context.runtimeAssets) {
                        const auto report = context.runtimeAssets->ResolveRegistryAssets(
                            context.scene->Registry());
                        if (context.log) {
                            for (const std::string& error : report.errors)
                                context.log->Warning("Foliage: " + error);
                        }
                    }
                }
            }
            ImGui::EndCombo();
        }

        const engine::ecs::FoliageComponent* component =
            context.scene->Registry().TryGet<engine::ecs::FoliageComponent>(selected->entity);
        ImGui::Text("Instances: %zu", selected->foliageInstances.size());
        ImGui::Text("Types: %zu", component ? component->types.size() : 0u);
        if (context.foliageTypeIndex && component && !component->types.empty()) {
            *context.foliageTypeIndex = std::clamp(
                *context.foliageTypeIndex, 0, static_cast<int>(component->types.size()) - 1);
            const std::string typeLabel = component->types[
                static_cast<std::size_t>(*context.foliageTypeIndex)].name;
            if (ImGui::BeginCombo("Paint Type", typeLabel.c_str())) {
                for (std::size_t i = 0; i < component->types.size(); ++i) {
                    const bool active = static_cast<int>(i) == *context.foliageTypeIndex;
                    if (ImGui::Selectable(component->types[i].name.c_str(), active))
                        *context.foliageTypeIndex = static_cast<int>(i);
                }
                ImGui::EndCombo();
            }
        }

        if (!selected->foliageAssetPath.empty()) {
            if (g_foliageDraftPath != selected->foliageAssetPath) {
                std::string loadError;
                engine::FoliageAssetData loaded;
                if (engine::LoadFoliageAsset(selected->foliageAssetPath, &loaded, &loadError)) {
                    g_foliageDraft = std::move(loaded);
                    g_foliageDraftPath = selected->foliageAssetPath;
                    g_foliageDraftDirty = false;
                } else if (context.log) {
                    context.log->Warning("Could not edit foliage asset: " + loadError);
                }
            }
            if (!g_foliageDraft.types.empty() && context.foliageTypeIndex
                && ImGui::TreeNodeEx("Type Settings", ImGuiTreeNodeFlags_DefaultOpen)) {
                const std::size_t draftIndex = static_cast<std::size_t>(std::clamp(
                    *context.foliageTypeIndex, 0,
                    static_cast<int>(g_foliageDraft.types.size()) - 1));
                engine::FoliageTypeAsset& type = g_foliageDraft.types[draftIndex];
                ImGui::PushID(static_cast<int>(draftIndex));
                std::array<char, 96> typeName{};
                std::snprintf(typeName.data(), typeName.size(), "%s", type.name.c_str());
                if (ImGui::InputText("Name", typeName.data(), typeName.size())) {
                    type.name = typeName.data();
                    g_foliageDraftDirty = true;
                }
                bool changed = false;
                changed |= ImGui::DragFloat("Density", &type.density, 0.05f, 0.01f, 100.0f, "%.2f /m2");
                changed |= ImGui::DragFloat3("Minimum Scale", &type.minScale.x, 0.01f, 0.01f, 20.0f, "%.2f");
                changed |= ImGui::DragFloat3("Maximum Scale", &type.maxScale.x, 0.01f, 0.01f, 20.0f, "%.2f");
                changed |= ImGui::DragFloat3("Minimum Rotation", &type.minRotation.x, 1.0f, -360.0f, 360.0f, "%.0f deg");
                changed |= ImGui::DragFloat3("Maximum Rotation", &type.maxRotation.x, 1.0f, -360.0f, 360.0f, "%.0f deg");
                changed |= ImGui::DragFloat("Minimum Spacing", &type.minimumSpacing, 0.05f, 0.0f, 100.0f, "%.2f m");
                changed |= ImGui::DragFloatRange2("Allowed Slope", &type.minimumSlopeDegrees,
                    &type.maximumSlopeDegrees, 0.5f, 0.0f, 89.0f, "Min %.1f deg", "Max %.1f deg");
                changed |= ImGui::DragFloatRange2("World Height", &type.minimumWorldHeight,
                    &type.maximumWorldHeight, 0.5f, -100000.0f, 100000.0f, "Min %.1f", "Max %.1f");
                changed |= ImGui::DragFloatRange2("Cull Distance", &type.cullStartDistance,
                    &type.cullEndDistance, 1.0f, 0.0f, 100000.0f, "Start %.0f m", "End %.0f m");
                changed |= ImGui::DragFloatRange2("LOD Distances", &type.lod1Distance,
                    &type.lod2Distance, 1.0f, 0.0f, 100000.0f, "LOD 1 %.0f m", "LOD 2 %.0f m");
                changed |= ImGui::DragFloat("Wind Strength", &type.windStrength, 0.01f, 0.0f, 10.0f, "%.2f");
                changed |= ImGui::Checkbox("Align to Surface", &type.alignToSurface);
                changed |= ImGui::Checkbox("Random Yaw", &type.randomYaw);
                changed |= ImGui::Checkbox("Cast Shadows", &type.castShadows);
                changed |= ImGui::Checkbox("Generate Collision", &type.collisionEnabled);
                if (changed) g_foliageDraftDirty = true;

                const EditorAssets::Asset* selectedContent = context.assets
                    ? context.assets->SelectedAsset() : nullptr;
                const bool canAssignMesh = selectedContent
                    && selectedContent->type == EditorAssets::Type::Model;
                const bool canAssignMaterial = selectedContent
                    && selectedContent->type == EditorAssets::Type::Material;
                if (!canAssignMesh) ImGui::BeginDisabled();
                if (ImGui::Button("Use Selected Mesh") && context.assets) {
                    type.meshPath = context.assets->SelectedAssetFullPath();
                    type.meshId = {};
                    g_foliageDraftDirty = true;
                }
                if (!canAssignMesh) ImGui::EndDisabled();
                ImGui::SameLine();
                if (!canAssignMesh) ImGui::BeginDisabled();
                if (ImGui::Button("Use as LOD 1") && context.assets) {
                    type.lod1MeshPath = context.assets->SelectedAssetFullPath();
                    type.lod1MeshId = {};
                    g_foliageDraftDirty = true;
                }
                if (!canAssignMesh) ImGui::EndDisabled();
                ImGui::SameLine();
                if (!canAssignMesh) ImGui::BeginDisabled();
                if (ImGui::Button("Use as LOD 2") && context.assets) {
                    type.lod2MeshPath = context.assets->SelectedAssetFullPath();
                    type.lod2MeshId = {};
                    g_foliageDraftDirty = true;
                }
                if (!canAssignMesh) ImGui::EndDisabled();
                ImGui::TextDisabled("LOD1: %s", type.lod1MeshPath.empty() ? "Primary mesh" : type.lod1MeshPath.c_str());
                ImGui::TextDisabled("LOD2: %s", type.lod2MeshPath.empty() ? "LOD1 / primary mesh" : type.lod2MeshPath.c_str());
                ImGui::SameLine();
                if (!canAssignMaterial) ImGui::BeginDisabled();
                if (ImGui::Button("Use Selected Material") && context.assets) {
                    type.materialPath = context.assets->SelectedAssetFullPath();
                    type.materialId = {};
                    g_foliageDraftDirty = true;
                }
                if (!canAssignMaterial) ImGui::EndDisabled();

                if (ImGui::Button("Duplicate Type")) {
                    engine::FoliageTypeAsset duplicate = type;
                    duplicate.name += " Copy";
                    g_foliageDraft.types.push_back(std::move(duplicate));
                    *context.foliageTypeIndex = static_cast<int>(g_foliageDraft.types.size()) - 1;
                    g_foliageDraftDirty = true;
                }
                ImGui::SameLine();
                if (g_foliageDraft.types.size() <= 1) ImGui::BeginDisabled();
                if (ImGui::Button("Remove Type")) {
                    g_foliageDraft.types.erase(g_foliageDraft.types.begin()
                        + static_cast<std::ptrdiff_t>(draftIndex));
                    *context.foliageTypeIndex = std::clamp(*context.foliageTypeIndex,
                        0, static_cast<int>(g_foliageDraft.types.size()) - 1);
                    g_foliageDraftDirty = true;
                }
                if (g_foliageDraft.types.size() <= 1) ImGui::EndDisabled();
                ImGui::SameLine();
                if (!g_foliageDraftDirty) ImGui::BeginDisabled();
                if (ImGui::Button("Save Type Settings")) {
                    std::string saveError;
                    if (engine::SaveFoliageAsset(g_foliageDraftPath,
                                                 g_foliageDraft, &saveError)) {
                        g_foliageDraftDirty = false;
                        if (context.runtimeAssets) {
                            context.runtimeAssets->ReloadFoliage(g_foliageDraftPath, &saveError);
                            context.runtimeAssets->ResolveRegistryAssets(context.scene->Registry());
                        }
                        if (context.log) context.log->Info("Saved foliage settings");
                    } else if (context.log) {
                        context.log->Error("Foliage save failed: " + saveError);
                    }
                }
                if (!g_foliageDraftDirty) ImGui::EndDisabled();
                if (g_foliageDraftDirty) {
                    ImGui::SameLine();
                    ImGui::TextColored(ImVec4(1.0f, 0.72f, 0.18f, 1.0f), "Unsaved");
                }
                ImGui::PopID();
                ImGui::TreePop();
            }
        }
        if (context.foliagePaint) {
            ImGui::Checkbox("Paint in Viewport", context.foliagePaint);
            if (*context.foliagePaint && context.terrainSculpt) *context.terrainSculpt = false;
        }
        if (context.foliageErase) ImGui::Checkbox("Erase", context.foliageErase);
        if (context.foliageBrushRadius)
            ImGui::DragFloat("Brush Radius", context.foliageBrushRadius, 0.1f, 0.1f, 100.0f, "%.1f m");
        if (context.foliagePaintDensity)
            ImGui::DragFloat("Density Multiplier", context.foliagePaintDensity, 0.02f, 0.01f, 10.0f, "%.2fx");
        if (ImGui::Button("Clear All Instances"))
            context.scene->ClearSelectedFoliageInstances();
        if (ImGui::TreeNodeEx("Placed Instances", ImGuiTreeNodeFlags_DefaultOpen)) {
            const int instanceCount = static_cast<int>(selected->foliageInstances.size());
            g_foliageInstanceSelection = std::clamp(
                g_foliageInstanceSelection, -1, instanceCount - 1);
            ImGui::BeginChild("FoliageInstanceList", ImVec2(0.0f, 145.0f), true);
            ImGuiListClipper clipper;
            clipper.Begin(instanceCount);
            while (clipper.Step()) {
                for (int index = clipper.DisplayStart; index < clipper.DisplayEnd; ++index) {
                    const engine::ecs::FoliageInstance& instance =
                        selected->foliageInstances[static_cast<std::size_t>(index)];
                    std::string label = "#" + std::to_string(instance.id)
                        + "  Type " + std::to_string(instance.typeIndex)
                        + (instance.enabled ? "" : "  (Disabled)");
                    if (ImGui::Selectable(label.c_str(), index == g_foliageInstanceSelection))
                        g_foliageInstanceSelection = index;
                }
            }
            ImGui::EndChild();
            if (g_foliageInstanceSelection >= 0
                && g_foliageInstanceSelection < instanceCount) {
                const engine::ecs::FoliageInstance current = selected->foliageInstances[
                    static_cast<std::size_t>(g_foliageInstanceSelection)];
                engine::ecs::FoliageInstance edited = current;
                bool instanceChanged = false;
                ImGui::PushID(static_cast<int>(current.id));
                instanceChanged |= ImGui::Checkbox("Enabled", &edited.enabled);
                instanceChanged |= ImGui::DragFloat3("Local Position", &edited.position.x,
                    0.05f, -100000.0f, 100000.0f, "%.2f");
                instanceChanged |= ImGui::DragFloat3("Rotation", &edited.rotationDegrees.x,
                    1.0f, -360.0f, 360.0f, "%.1f deg");
                instanceChanged |= ImGui::DragFloat3("Scale", &edited.scale.x,
                    0.01f, 0.001f, 100.0f, "%.2f");
                if (instanceChanged)
                    context.scene->SetSelectedFoliageInstance(current.id, edited);
                if (ImGui::Button("Duplicate Instance")) {
                    std::uint32_t newId = 0;
                    if (context.scene->DuplicateSelectedFoliageInstance(current.id, &newId)) {
                        const EditorScene::Object* refreshed = context.scene->SelectedObject();
                        if (refreshed) {
                            for (std::size_t i = 0; i < refreshed->foliageInstances.size(); ++i) {
                                if (refreshed->foliageInstances[i].id == newId) {
                                    g_foliageInstanceSelection = static_cast<int>(i);
                                    break;
                                }
                            }
                        }
                    }
                }
                ImGui::SameLine();
                if (ImGui::Button("Delete Instance")) {
                    if (context.scene->RemoveSelectedFoliageInstance(current.id))
                        g_foliageInstanceSelection = -1;
                }
                ImGui::PopID();
            }
            ImGui::TreePop();
        }
        ImGui::TextDisabled("Left-drag in the viewport to paint. Enable Erase to remove instances.");
        ImGui::TextDisabled("Placement follows terrain height and the foliage asset's spacing/scale rules.");
    }

    if (selected->isWater && ImGui::CollapsingHeader("Water", ImGuiTreeNodeFlags_DefaultOpen)) {
        float size = selected->waterSize;
        int   res = selected->waterResolution;
        float level = selected->waterLevel;
        glm::vec3 shallow = selected->waterShallow;
        glm::vec3 deep = selected->waterDeep;
        glm::vec3 refl = selected->waterReflection;
        float transparency = selected->waterTransparency;
        float fresnel = selected->waterFresnel;
        float spec = selected->waterSpecular;
        float shininess = selected->waterShininess;
        bool changed = false;
        changed |= ImGui::DragFloat("Size (m)", &size, 0.5f, 1.0f, 4000.0f, "%.1f");
        changed |= ImGui::DragInt("Resolution", &res, 1.0f, 8, 512);
        changed |= ImGui::DragFloat("Surface Level (Y)", &level, 0.05f, -1000.0f, 1000.0f, "%.2f");
        changed |= ImGui::ColorEdit3("Shallow", &shallow.x);
        changed |= ImGui::ColorEdit3("Deep", &deep.x);
        changed |= ImGui::ColorEdit3("Reflection (sky)", &refl.x);
        changed |= ImGui::DragFloat("Transparency", &transparency, 0.01f, 0.0f, 1.0f, "%.2f");
        changed |= ImGui::DragFloat("Fresnel Power", &fresnel, 0.05f, 0.1f, 12.0f, "%.2f");
        changed |= ImGui::DragFloat("Specular", &spec, 0.02f, 0.0f, 8.0f, "%.2f");
        changed |= ImGui::DragFloat("Shininess", &shininess, 1.0f, 1.0f, 1000.0f, "%.0f");
        if (changed) {
            context.scene->SetSelectedWater(size, res, level, shallow, deep, refl,
                                            transparency, fresnel, spec, shininess);
        }

        // Surface motion (differs per water type: lake/ocean/river presets).
        ImGui::Separator();
        const char* typeNames[] = {"Custom", "Lake", "Ocean", "River"};
        const int typeIdx = (selected->waterType >= 0 && selected->waterType <= 3) ? selected->waterType : 0;
        ImGui::Text("Type: %s", typeNames[typeIdx]);
        float seaHeight = selected->waterSeaHeight;
        float seaChoppy = selected->waterSeaChoppy;
        float seaSpeed  = selected->waterSeaSpeed;
        float seaFreq   = selected->waterSeaFreq;
        float foam      = selected->waterFoam;
        bool waveChanged = false;
        waveChanged |= ImGui::DragFloat("Wave Height", &seaHeight, 0.01f, 0.0f, 5.0f, "%.2f");
        waveChanged |= ImGui::DragFloat("Choppiness", &seaChoppy, 0.02f, 0.0f, 10.0f, "%.2f");
        waveChanged |= ImGui::DragFloat("Flow Speed", &seaSpeed, 0.02f, 0.0f, 5.0f, "%.2f");
        waveChanged |= ImGui::DragFloat("Wave Scale", &seaFreq, 0.005f, 0.01f, 1.0f, "%.3f");
        waveChanged |= ImGui::DragFloat("Foam", &foam, 0.02f, 0.0f, 4.0f, "%.2f");
        ImGui::TextDisabled("Noise-wave surface. Centre = object Transform XZ; level = calm Y.");
        if (waveChanged) {
            // Editing motion by hand makes it "Custom" (0).
            context.scene->SetSelectedWaterWaves(seaHeight, seaChoppy, seaSpeed, seaFreq, foam, 0);
        }

        ImGui::Separator();
        ImGui::TextUnformatted("Depth + Shoreline");
        float depthFade = selected->waterDepthFadeDistance;
        float shoreWidth = selected->waterShoreFoamWidth;
        float shoreStrength = selected->waterShoreFoamStrength;
        bool depthChanged = false;
        depthChanged |= ImGui::DragFloat("Deep Color Distance", &depthFade,
            0.05f, 0.05f, 100.0f, "%.2f m");
        depthChanged |= ImGui::DragFloat("Shore Foam Width", &shoreWidth,
            0.02f, 0.01f, 20.0f, "%.2f m");
        depthChanged |= ImGui::DragFloat("Shore Foam Strength", &shoreStrength,
            0.02f, 0.0f, 4.0f, "%.2f");
        if (depthChanged) {
            context.scene->SetSelectedWaterDepth(
                depthFade, shoreWidth, shoreStrength);
        }
        ImGui::TextDisabled("Uses opaque scene depth for shallow water and bank foam.");

        ImGui::Separator();
        ImGui::TextUnformatted("Reflection + Refraction");
        float refractionStrength = selected->waterRefractionStrength;
        float reflectionRoughness = selected->waterReflectionRoughness;
        float environmentReflection = selected->waterEnvironmentReflectionStrength;
        float absorption = selected->waterAbsorptionStrength;
        bool opticsChanged = false;
        opticsChanged |= ImGui::DragFloat("Refraction Distortion", &refractionStrength,
            0.001f, 0.0f, 0.25f, "%.3f");
        opticsChanged |= ImGui::DragFloat("Reflection Roughness", &reflectionRoughness,
            0.01f, 0.0f, 1.0f, "%.2f");
        opticsChanged |= ImGui::DragFloat("Environment Reflection", &environmentReflection,
            0.01f, 0.0f, 1.0f, "%.2f");
        opticsChanged |= ImGui::DragFloat("Depth Absorption", &absorption,
            0.01f, 0.0f, 2.0f, "%.2f");
        if (opticsChanged) {
            context.scene->SetSelectedWaterOptics(
                refractionStrength, reflectionRoughness,
                environmentReflection, absorption);
        }
        ImGui::TextDisabled("Refraction samples the opaque scene; reflections use World IBL.");

        ImGui::Separator();
        ImGui::TextUnformatted("Caustics + Underwater");
        float causticsStrength = selected->waterCausticsStrength;
        float causticsScale = selected->waterCausticsScale;
        float maxRenderDistance = selected->waterMaxRenderDistance;
        glm::vec3 underwaterTint = selected->waterUnderwaterTint;
        float underwaterFog = selected->waterUnderwaterFogDensity;
        float underwaterDistortion = selected->waterUnderwaterDistortion;
        float transitionSpeed = selected->waterUnderwaterTransitionSpeed;
        bool effectsChanged = false;
        effectsChanged |= ImGui::DragFloat("Caustics Strength", &causticsStrength,
            0.01f, 0.0f, 4.0f, "%.2f");
        effectsChanged |= ImGui::DragFloat("Caustics Scale", &causticsScale,
            0.02f, 0.05f, 20.0f, "%.2f");
        effectsChanged |= ImGui::DragFloat("Render Distance", &maxRenderDistance,
            10.0f, 0.0f, 100000.0f, "%.0f m");
        effectsChanged |= ImGui::ColorEdit3("Underwater Tint", &underwaterTint.x);
        effectsChanged |= ImGui::DragFloat("Underwater Fog", &underwaterFog,
            0.005f, 0.0f, 2.0f, "%.3f");
        effectsChanged |= ImGui::DragFloat("Underwater Distortion", &underwaterDistortion,
            0.0005f, 0.0f, 0.1f, "%.4f");
        effectsChanged |= ImGui::DragFloat("Surface Transition", &transitionSpeed,
            0.1f, 0.1f, 20.0f, "%.1f /s");
        if (effectsChanged) {
            context.scene->SetSelectedWaterEffects(
                causticsStrength, causticsScale, maxRenderDistance,
                underwaterTint, underwaterFog, underwaterDistortion,
                transitionSpeed);
        }
        ImGui::TextDisabled("Render Distance 0 disables distance culling.");

        // River flow: make the surface scroll along a spline's direction.
        ImGui::Separator();
        const std::string& currentFlow = selected->waterFlowSpline;
        if (ImGui::BeginCombo("Flow Spline", currentFlow.empty() ? "(none)" : currentFlow.c_str())) {
            if (ImGui::Selectable("(none)", currentFlow.empty())) {
                context.scene->SetSelectedWaterFlowSpline(std::string());
            }
            for (const EditorScene::Object& o : context.scene->Objects()) {
                if (!o.isSpline) continue;
                if (ImGui::Selectable(o.name.c_str(), o.name == currentFlow)) {
                    context.scene->SetSelectedWaterFlowSpline(o.name);
                }
            }
            ImGui::EndCombo();
        }
        if (!currentFlow.empty()) {
            float width = selected->waterRiverWidth;
            if (ImGui::DragFloat("River Width", &width, 0.1f, 0.1f, 500.0f, "%.2f m")) {
                context.scene->SetSelectedWaterRiverWidth(width);
            }
            ImGui::TextDisabled("The surface, position, length and curved flow update live from the spline.");
        } else {
            ImGui::TextDisabled("Assign a spline to turn this water patch into a flowing river ribbon.");
        }

        // Custom water shader: a .glsl file holding the fragment body (helpers + main()).
        ImGui::Separator();
        const std::string& shaderPath = selected->waterShaderPath;
        ImGui::TextUnformatted("Custom Shader:");
        ImGui::SameLine();
        ImGui::TextWrapped("%s", shaderPath.empty() ? "(built-in)" : shaderPath.c_str());
        if (ImGui::Button("Set GLSL...")) {
            const std::string picked = editor::OpenFileDialog(
                "Choose a water fragment shader", "GLSL shader", "glsl");
            if (!picked.empty()) context.scene->SetSelectedWaterShaderPath(picked);
        }
        ImGui::SameLine();
        if (ImGui::Button("Set Graph Shader...")) {
            const std::string picked = editor::OpenFileDialog(
                "Choose a Shader Editor graph", "Shader graph", "3dgshader");
            if (!picked.empty()) context.scene->SetSelectedWaterShaderPath(picked);
        }
        if (!shaderPath.empty()) {
            ImGui::SameLine();
            if (ImGui::Button("Clear Shader")) {
                context.scene->SetSelectedWaterShaderPath(std::string());
            }
        }
        ImGui::TextDisabled("GLSL: a .glsl file with helper funcs + main() writing FragColor.\n"
                            "Graph: a .3dgshader from the Shader Editor (any domain), adapted "
                            "onto the water surface.\nThe engine prepends the water "
                            "uniforms/varyings. Hot-reloads on save; falls back to built-in "
                            "on error.");
    }

    if (selected->isSpline && ImGui::CollapsingHeader("Spline", ImGuiTreeNodeFlags_DefaultOpen)) {
        bool closed = selected->splineClosed;
        int  type = selected->splineType;
        const char* types[] = {"Path", "River", "Rail"};
        bool metaChanged = false;
        metaChanged |= ImGui::Combo("Use", &type, types, IM_ARRAYSIZE(types));
        metaChanged |= ImGui::Checkbox("Closed loop", &closed);
        if (metaChanged) {
            context.scene->SetSelectedSpline(true, closed, type);
        }

        engine::Spline authoredSpline(selected->splinePoints, selected->splineClosed);
        ImGui::Text("%d points  |  Length %.2f m",
            static_cast<int>(selected->splinePoints.size()), authoredSpline.Length());
        ImGui::TextDisabled("Select a point, then use W to move or E to rotate it. River roll uses local Z.");

        int localSelection = context.selectedSplinePoint ? *context.selectedSplinePoint : -1;
        if (localSelection >= static_cast<int>(selected->splinePoints.size())) localSelection = -1;

        int removeIndex = -1;
        for (std::size_t i = 0; i < selected->splinePoints.size(); ++i) {
            ImGui::PushID(static_cast<int>(i));
            const bool pointSelected = localSelection == static_cast<int>(i);
            char pointLabel[16];
            std::snprintf(pointLabel, sizeof(pointLabel), "%02d", static_cast<int>(i + 1));
            if (ImGui::Selectable(pointLabel, pointSelected, 0, ImVec2(30.0f, 0.0f))) {
                localSelection = static_cast<int>(i);
                if (context.selectedSplinePoint) *context.selectedSplinePoint = localSelection;
            }
            ImGui::SameLine();
            glm::vec3 p = selected->splinePoints[i];
            ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x - 28.0f);
            if (ImGui::DragFloat3("##pt", &p.x, 0.1f, -100000.0f, 100000.0f, "%.2f")) {
                context.scene->SetSelectedSplinePoint(i, p);
                localSelection = static_cast<int>(i);
                if (context.selectedSplinePoint) *context.selectedSplinePoint = localSelection;
            }
            ImGui::SameLine();
            if (ImGui::SmallButton("X")) removeIndex = static_cast<int>(i);
            ImGui::PopID();
        }
        if (removeIndex >= 0) {
            context.scene->RemoveSelectedSplinePoint(static_cast<std::size_t>(removeIndex));
            if (context.selectedSplinePoint) {
                if (*context.selectedSplinePoint == removeIndex) *context.selectedSplinePoint = -1;
                else if (*context.selectedSplinePoint > removeIndex) --*context.selectedSplinePoint;
            }
        }

        if (ImGui::Button("Add Point")) {
            glm::vec3 np(0.0f);
            const auto& pts = selected->splinePoints;
            if (!pts.empty()) {
                np = pts.back();
                if (pts.size() >= 2) np += (pts.back() - pts[pts.size() - 2]);   // extend direction
                else np += glm::vec3(3.0f, 0.0f, 0.0f);
            }
            context.scene->AddSelectedSplinePoint(np);
            if (context.selectedSplinePoint) {
                *context.selectedSplinePoint = static_cast<int>(selected->splinePoints.size()) - 1;
            }
        }
        ImGui::SameLine();
        if (ImGui::Button("Add at View") && context.camera) {
            // Intersect the camera ray with the current spline height. If the view is
            // nearly horizontal, use a stable forward distance instead.
            const glm::vec3 eye = context.camera->Position();
            const glm::vec3 fwd = context.camera->Front();
            const float h = selected->splinePoints.empty() ? 0.0f : selected->splinePoints.back().y;
            float dist = 10.0f;
            if (std::abs(fwd.y) > 1.0e-4f) {
                const float planeHit = (h - eye.y) / fwd.y;
                if (planeHit > 0.0f) dist = std::clamp(planeHit, 2.0f, 60.0f);
            }
            glm::vec3 point = eye + fwd * dist;
            point.y = h;
            context.scene->AddSelectedSplinePoint(point);
            if (context.selectedSplinePoint) {
                *context.selectedSplinePoint = static_cast<int>(selected->splinePoints.size()) - 1;
            }
        }

        const int selectedPoint = context.selectedSplinePoint ? *context.selectedSplinePoint : -1;
        if (selectedPoint >= 0 && selectedPoint < static_cast<int>(selected->splinePoints.size())) {
            if (ImGui::SmallButton("Previous Point")) {
                int previous = selectedPoint - 1;
                if (previous < 0) previous = closed
                    ? static_cast<int>(selected->splinePoints.size()) - 1 : 0;
                if (context.selectedSplinePoint) *context.selectedSplinePoint = previous;
            }
            ImGui::SameLine();
            if (ImGui::SmallButton("Next Point")) {
                int next = selectedPoint + 1;
                if (next >= static_cast<int>(selected->splinePoints.size()))
                    next = closed ? 0 : static_cast<int>(selected->splinePoints.size()) - 1;
                if (context.selectedSplinePoint) *context.selectedSplinePoint = next;
            }
            glm::vec3 pointRotation(0.0f);
            if (static_cast<std::size_t>(selectedPoint) < selected->splinePointRotations.size()) {
                pointRotation = selected->splinePointRotations[static_cast<std::size_t>(selectedPoint)];
            }
            if (ImGui::DragFloat3("Point Rotation", &pointRotation.x, 0.5f,
                                  -3600.0f, 3600.0f, "%.1f deg")) {
                context.scene->SetSelectedSplinePointRotation(
                    static_cast<std::size_t>(selectedPoint), pointRotation);
            }
            ImGui::TextDisabled("Z banks river water; all axes are saved for other spline users.");
            if (ImGui::Button("Insert After")) {
                const std::size_t i = static_cast<std::size_t>(selectedPoint);
                const auto& pts = selected->splinePoints;
                const std::size_t next = i + 1 < pts.size() ? i + 1 : (closed ? 0 : i);
                const glm::vec3 point = next != i ? glm::mix(pts[i], pts[next], 0.5f)
                                                  : pts[i] + glm::vec3(2.0f, 0.0f, 0.0f);
                context.scene->InsertSelectedSplinePoint(i + 1, point);
                if (i < selected->splinePointRotations.size()) {
                    context.scene->SetSelectedSplinePointRotation(i + 1,
                        selected->splinePointRotations[i]);
                }
                if (context.selectedSplinePoint) *context.selectedSplinePoint = selectedPoint + 1;
            }
            ImGui::SameLine();
            if (ImGui::Button("Duplicate")) {
                const std::size_t i = static_cast<std::size_t>(selectedPoint);
                context.scene->InsertSelectedSplinePoint(i + 1,
                    selected->splinePoints[i] + glm::vec3(0.5f, 0.0f, 0.5f));
                if (i < selected->splinePointRotations.size()) {
                    context.scene->SetSelectedSplinePointRotation(i + 1,
                        selected->splinePointRotations[i]);
                }
                if (context.selectedSplinePoint) *context.selectedSplinePoint = selectedPoint + 1;
            }
        }

        if (selected->splinePoints.size() >= 2) {
            if (ImGui::Button("Reverse Direction")) {
                std::vector<glm::vec3> reversed = selected->splinePoints;
                std::vector<glm::vec3> reversedRotations = selected->splinePointRotations;
                std::reverse(reversed.begin(), reversed.end());
                std::reverse(reversedRotations.begin(), reversedRotations.end());
                context.scene->SetSelectedSplinePoints(reversed);
                context.scene->SetSelectedSplinePointRotations(reversedRotations);
                if (context.selectedSplinePoint && *context.selectedSplinePoint >= 0) {
                    *context.selectedSplinePoint = static_cast<int>(reversed.size()) - 1
                        - *context.selectedSplinePoint;
                }
            }
            ImGui::SameLine();
            if (ImGui::Button("Even Spacing")) {
                std::vector<glm::vec3> even;
                authoredSpline.SampleUniform(static_cast<int>(selected->splinePoints.size()), even);
                context.scene->SetSelectedSplinePoints(even);
            }

            ImGui::SeparatorText("Batch Point Tools");
            static float splineSnapSize = 1.0f;
            static float splineSimplifyTolerance = 0.15f;
            ImGui::DragFloat("Grid Size##Spline", &splineSnapSize, 0.05f,
                             0.01f, 100.0f, "%.2f m");
            if (ImGui::Button("Snap All to Grid")) {
                const float grid = std::max(splineSnapSize, 0.01f);
                std::vector<glm::vec3> snapped = selected->splinePoints;
                for (glm::vec3& point : snapped) point = glm::round(point / grid) * grid;
                context.scene->SetSelectedSplinePoints(snapped);
            }
            ImGui::SameLine();
            if (ImGui::Button("Align Heights")) {
                const int anchor = context.selectedSplinePoint
                    ? *context.selectedSplinePoint : -1;
                float height = 0.0f;
                if (anchor >= 0 && anchor < static_cast<int>(selected->splinePoints.size()))
                    height = selected->splinePoints[static_cast<std::size_t>(anchor)].y;
                else {
                    for (const glm::vec3& point : selected->splinePoints) height += point.y;
                    height /= static_cast<float>(selected->splinePoints.size());
                }
                std::vector<glm::vec3> aligned = selected->splinePoints;
                for (glm::vec3& point : aligned) point.y = height;
                context.scene->SetSelectedSplinePoints(aligned);
            }

            if (ImGui::Button("Subdivide Segments")) {
                const auto& points = selected->splinePoints;
                const auto& rotations = selected->splinePointRotations;
                std::vector<glm::vec3> subdivided;
                std::vector<glm::vec3> subdividedRotations;
                const std::size_t segments = closed ? points.size() : points.size() - 1;
                subdivided.reserve(points.size() + segments);
                subdividedRotations.reserve(points.size() + segments);
                for (std::size_t i = 0; i < points.size(); ++i) {
                    const glm::vec3 rotation = i < rotations.size()
                        ? rotations[i] : glm::vec3(0.0f);
                    subdivided.push_back(points[i]);
                    subdividedRotations.push_back(rotation);
                    if (i < segments) {
                        const std::size_t next = (i + 1) % points.size();
                        const glm::vec3 nextRotation = next < rotations.size()
                            ? rotations[next] : glm::vec3(0.0f);
                        subdivided.push_back(glm::mix(points[i], points[next], 0.5f));
                        subdividedRotations.push_back(glm::mix(rotation, nextRotation, 0.5f));
                    }
                }
                context.scene->SetSelectedSplinePoints(subdivided);
                context.scene->SetSelectedSplinePointRotations(subdividedRotations);
            }
            ImGui::SameLine();
            if (ImGui::Button("Reset All Rotations")) {
                context.scene->SetSelectedSplinePointRotations(
                    std::vector<glm::vec3>(selected->splinePoints.size(), glm::vec3(0.0f)));
            }

            ImGui::DragFloat("Simplify Tolerance", &splineSimplifyTolerance,
                             0.01f, 0.001f, 10.0f, "%.3f m");
            if (ImGui::Button("Simplify Curve")) {
                const auto& points = selected->splinePoints;
                const auto& rotations = selected->splinePointRotations;
                std::vector<glm::vec3> simplified;
                std::vector<glm::vec3> simplifiedRotations;
                const float toleranceSq = splineSimplifyTolerance * splineSimplifyTolerance;
                for (std::size_t i = 0; i < points.size(); ++i) {
                    const bool endpoint = !closed && (i == 0 || i + 1 == points.size());
                    bool keep = endpoint || points.size() <= (closed ? 3u : 2u);
                    if (!keep) {
                        const glm::vec3 a = points[(i + points.size() - 1) % points.size()];
                        const glm::vec3 b = points[(i + 1) % points.size()];
                        const glm::vec3 ab = b - a;
                        const float lengthSq = glm::dot(ab, ab);
                        const float t = lengthSq > 1.0e-8f
                            ? std::clamp(glm::dot(points[i] - a, ab) / lengthSq,
                                         0.0f, 1.0f) : 0.0f;
                        const glm::vec3 delta = points[i] - (a + ab * t);
                        keep = glm::dot(delta, delta) > toleranceSq;
                    }
                    if (keep) {
                        simplified.push_back(points[i]);
                        simplifiedRotations.push_back(i < rotations.size()
                            ? rotations[i] : glm::vec3(0.0f));
                    }
                }
                const std::size_t minimum = closed ? 3u : 2u;
                if (simplified.size() >= minimum && simplified.size() < points.size()) {
                    context.scene->SetSelectedSplinePoints(simplified);
                    context.scene->SetSelectedSplinePointRotations(simplifiedRotations);
                    if (context.selectedSplinePoint) *context.selectedSplinePoint = -1;
                }
            }
        }
        if (selected->splineType == 1) {
            ImGui::Separator();
            if (ImGui::Button("Create River Water From Spline")) {
                context.addRiverForSelectedSplineRequested = true;
            }
            ImGui::TextDisabled("Creates river water and assigns this spline as its flow direction.");
        }
    }

    ImGui::End();
}

void DrawAssets(EditorDockspace::Context& context, bool* open) {
    if (!ImGui::Begin(EditorPanels::Name(EditorPanels::Panel::Assets), open)) {
        ImGui::End();
        return;
    }

    if (!context.assets) {
        ImGui::TextUnformatted("Assets unavailable.");
        ImGui::End();
        return;
    }

    static char renameEntryName[128] = "";
    static char newFolderName[128] = "NewFolder";
    static std::string pendingDeleteName;
    bool requestRenamePopup = false;
    bool requestDeletePopup = false;
    bool requestCreateFolderPopup = false;
    bool requestImportPopup = false;

    const auto copySelected = [&]() {
        std::string error;
        if (context.assets->CopySelected(&error)) {
            const EditorAssets::Asset* selectedAsset = context.assets->SelectedAsset();
            if (selectedAsset && selectedAsset->type == EditorAssets::Type::Texture) {
                const std::string texturePath = context.assets->SelectedAssetFullPath();
                ImGui::SetClipboardText(texturePath.c_str());
            }
            if (context.log)
                context.log->Info("Copied Content entry: "
                    + context.assets->CopiedDisplayName());
        } else if (context.log) context.log->Warning(error);
    };
    const auto cutSelected = [&]() {
        std::string error;
        if (context.assets->CutSelected(&error)) {
            if (context.log) context.log->Info("Cut Content entry: "
                + context.assets->CopiedDisplayName() + " (Paste to move)");
        } else if (context.log) context.log->Warning(error);
    };
    const auto pasteCopied = [&]() {
        std::string error;
        const bool wasCut = context.assets->HasCopiedEntry()
            && context.assets->CopiedEntryIsCut();
        if (context.assets->PasteCopied(&error)) {
            if (context.log) context.log->Info(
                wasCut ? "Moved Content entry" : "Pasted Content entry");
        } else if (context.log) context.log->Warning(error);
    };
    const auto beginRename = [&]() {
        std::string currentName;
        if (const EditorAssets::Folder* folder = context.assets->SelectedFolder())
            currentName = folder->displayName;
        else if (const EditorAssets::Asset* asset = context.assets->SelectedAsset())
            currentName = std::filesystem::path(asset->displayName).stem().string();
        std::snprintf(renameEntryName, sizeof(renameEntryName), "%s", currentName.c_str());
        requestRenamePopup = true;
    };
    const auto beginDelete = [&]() {
        if (const EditorAssets::Folder* folder = context.assets->SelectedFolder())
            pendingDeleteName = folder->displayName;
        else if (const EditorAssets::Asset* asset = context.assets->SelectedAsset())
            pendingDeleteName = asset->displayName;
        else
            pendingDeleteName.clear();
        requestDeletePopup = true;
    };
    const auto reimportSelected = [&]() {
        const EditorAssets::Asset* selected = context.assets->SelectedAsset();
        const bool staticMesh = selected && selected->type == EditorAssets::Type::Model
            && std::filesystem::path(selected->relativePath).extension() == ".3dgmesh";
        const bool skeletalMesh = selected
            && selected->type == EditorAssets::Type::SkeletalModel
            && std::filesystem::path(selected->relativePath).extension() == ".3dgskmesh";
        const bool texture = selected && selected->type == EditorAssets::Type::Texture
            && std::filesystem::path(selected->relativePath).extension() == ".3dgtex";
        std::string error;
        const bool reimported = texture
            ? context.assets->ReimportSelectedTexture(&error)
            : skeletalMesh
                ? context.assets->ReimportSelectedSkeletalAssets(&error)
                : staticMesh && context.assets->ReimportSelectedStaticMesh(&error);
        if (!reimported) {
            if (context.log) context.log->Error(error.empty()
                ? "The selected asset cannot be reimported." : error);
            return;
        }
        const std::string assetPath = context.assets->SelectedAssetFullPath();
        const bool liveReloadFailed = context.runtimeAssets && !texture
            && ((skeletalMesh && context.runtimeAssets->FindSkinnedModel(assetPath)
                    && !context.runtimeAssets->ReloadSkinnedModel(assetPath, &error))
                || (staticMesh && context.runtimeAssets->FindModel(assetPath)
                    && !context.runtimeAssets->ReloadModel(assetPath, &error)));
        if (liveReloadFailed) {
            if (context.log) context.log->Error(
                "Asset was reimported but its live preview could not reload: " + error);
        } else if (context.log) context.log->Info(context.assets->LastImportMessage());
    };

    const std::string breadcrumb = context.assets->CurrentFolder().empty()
        ? std::string("Content")
        : std::string("Content/") + context.assets->CurrentFolder();
    ImGui::TextUnformatted(breadcrumb.c_str());
    if (ImGui::IsItemHovered())
        ImGui::SetTooltip("%s", context.assets->RootPath().c_str());
    ImGui::SameLine();
    ImGui::TextDisabled("(%d files)", static_cast<int>(context.assets->TotalFileCount()));
    if (editor::icons::Button(editor::icons::Up, "Up")) {
        std::string error;
        if (!context.assets->GoUp(&error) && context.log) {
            context.log->Error(error);
        }
    }
    ImGui::SameLine();
    if (editor::icons::Button(editor::icons::Refresh, "Refresh")) {
        std::string error;
        if (!context.assets->Refresh(context.assets->RootPath(), &error) && context.log) {
            context.log->Error(error);
        }
    }
    if (ImGui::BeginPopupModal("Rename Content Entry", nullptr,
                               ImGuiWindowFlags_AlwaysAutoResize)) {
        ImGui::TextUnformatted("New name");
        ImGui::SetNextItemWidth(300.0f);
        const bool submitted = ImGui::InputText(
            "##RenameContentEntryName", renameEntryName, sizeof(renameEntryName),
            ImGuiInputTextFlags_EnterReturnsTrue);
        if (context.assets->SelectedType() == EditorAssets::SelectionType::Asset)
            ImGui::TextDisabled("The asset's current file extension is preserved.");
        else
            ImGui::TextDisabled("Assets inside a renamed folder receive a new Content path.");
        const bool confirm = ImGui::Button("Rename", ImVec2(110.0f, 0.0f)) || submitted;
        ImGui::SameLine();
        const bool cancel = ImGui::Button("Cancel", ImVec2(110.0f, 0.0f));
        if (confirm) {
            std::string error;
            if (context.assets->RenameSelectedEntry(renameEntryName, &error)) {
                if (context.log) context.log->Info(
                    std::string("Renamed Content entry to: ") + renameEntryName);
                ImGui::CloseCurrentPopup();
            } else if (context.log) context.log->Error(error);
        } else if (cancel) {
            ImGui::CloseCurrentPopup();
        }
        ImGui::EndPopup();
    }
    if (ImGui::BeginPopupModal("Create Content Folder", nullptr,
                               ImGuiWindowFlags_AlwaysAutoResize)) {
        ImGui::Text("Create inside Content/%s", context.assets->CurrentFolder().c_str());
        ImGui::SetNextItemWidth(300.0f);
        const bool submitted = ImGui::InputText("##NewContentFolderName",
            newFolderName, sizeof(newFolderName), ImGuiInputTextFlags_EnterReturnsTrue);
        const bool confirm = ImGui::Button("Create", ImVec2(110.0f, 0.0f)) || submitted;
        ImGui::SameLine();
        const bool cancel = ImGui::Button("Cancel", ImVec2(110.0f, 0.0f));
        if (confirm) {
            std::string error;
            if (context.assets->CreateFolder(newFolderName, &error)) {
                if (context.log) context.log->Info(
                    std::string("Created Content folder: ") + newFolderName);
                std::snprintf(newFolderName, sizeof(newFolderName), "%s", "NewFolder");
                ImGui::CloseCurrentPopup();
            } else if (context.log) context.log->Error(error);
        } else if (cancel) ImGui::CloseCurrentPopup();
        ImGui::EndPopup();
    }
    if (ImGui::BeginPopupModal("Delete Content Entry", nullptr,
                               ImGuiWindowFlags_AlwaysAutoResize)) {
        ImGui::TextWrapped("Delete '%s'?", pendingDeleteName.c_str());
        ImGui::TextColored(ImVec4(1.0f, 0.45f, 0.35f, 1.0f),
            "Folders and their contents are deleted permanently.");
        if (ImGui::Button("Delete", ImVec2(110.0f, 0.0f))) {
            std::string error;
            if (context.assets->DeleteSelectedEntry(&error)) {
                if (context.log) context.log->Info("Deleted Content entry: "
                    + pendingDeleteName);
                ImGui::CloseCurrentPopup();
            } else if (context.log) context.log->Error(error);
        }
        ImGui::SameLine();
        if (ImGui::Button("Cancel", ImVec2(110.0f, 0.0f)))
            ImGui::CloseCurrentPopup();
        ImGui::EndPopup();
    }
    if (context.assets->HasCopiedEntry())
        ImGui::TextDisabled("Clipboard: %s%s", context.assets->CopiedDisplayName().c_str(),
            context.assets->CopiedEntryIsCut() ? " (cut)" : "");

    static std::string importSource;
    static std::string importDestination;
    static char importFolderName[128] = "";
    static int importModelMode =
        static_cast<int>(EditorAssets::ModelImportMode::Automatic);
    static engine::ModelSourceInfo importModelInfo;
    static bool importModelInspected = false;
    static std::string importInspectionError;
    const auto prepareImportSource = [&](const std::string& selected) {
        importSource = selected;
        importModelInfo = {};
        importModelInspected = false;
        importInspectionError.clear();
        importModelMode =
            static_cast<int>(EditorAssets::ModelImportMode::Automatic);
        const std::string extension = LowerExtension(selected);
        const bool isModel = extension == ".obj" || extension == ".fbx"
            || extension == ".gltf" || extension == ".glb"
            || extension == ".dae" || extension == ".ply"
            || extension == ".stl";
        if (isModel) {
            importModelInspected = engine::InspectModelSource(
                selected, &importModelInfo, &importInspectionError);
            if (importModelInspected) {
                const bool animationOnly = importModelInfo.animationCount > 0
                    && importModelInfo.meshCount == 0;
                importModelMode = static_cast<int>(animationOnly
                    ? EditorAssets::ModelImportMode::Animation
                    : (importModelInfo.IsSkeletal()
                        ? EditorAssets::ModelImportMode::SkeletalMesh
                        : EditorAssets::ModelImportMode::StaticMesh));
                engine::SkeletalImportOptions& settings =
                    context.assets->SkeletalImportSettings();
                settings.importSkeletalMesh = !animationOnly;
                settings.importSkeleton = !animationOnly;
                settings.importEmbeddedAnimations = true;
                if (!animationOnly) settings.reuseSkeletonPath.clear();
            }
        }
    };
    if (editor::icons::Button(editor::icons::Download, "Import Asset")) {
        const std::string selected =
            editor::OpenAssetImportDialog("Import Asset into Content");
        if (!selected.empty()) {
            prepareImportSource(selected);
            importDestination = context.assets->CurrentFolder();
            importFolderName[0] = '\0';
            ImGui::OpenPopup("Asset Import Settings##ContentBrowser");
        }
    }
    if (ImGui::IsItemHovered())
        ImGui::SetTooltip("Browse system files and import into the current Content folder.");

    if (ImGui::BeginPopupModal("Asset Import Settings##ContentBrowser", nullptr,
                               ImGuiWindowFlags_AlwaysAutoResize)) {
        ImGui::TextUnformatted("Source file");
        ImGui::SetNextItemWidth(520.0f);
        ImGui::InputText("##ImportSource", importSource.data(),
                         importSource.size() + 1,
                         ImGuiInputTextFlags_ReadOnly);
        ImGui::SameLine();
        if (ImGui::Button("Browse...##ImportSource")) {
            const std::string selected =
                editor::OpenAssetImportDialog("Import Asset into Content");
            if (!selected.empty()) prepareImportSource(selected);
        }

        const std::string importExtension = LowerExtension(importSource);
        const bool importingModel = importExtension == ".obj"
            || importExtension == ".fbx" || importExtension == ".gltf"
            || importExtension == ".glb" || importExtension == ".dae"
            || importExtension == ".ply" || importExtension == ".stl";
        const bool importingTexture = importExtension == ".png"
            || importExtension == ".jpg" || importExtension == ".jpeg"
            || importExtension == ".tga";
        const bool importingAudio = importExtension == ".wav"
            || importExtension == ".ogg" || importExtension == ".mp3"
            || importExtension == ".flac";

        ImGui::SeparatorText("Asset Settings");
        if (importingModel) {
            const auto selectedImportMode =
                static_cast<EditorAssets::ModelImportMode>(importModelMode);
            const char* importAs = selectedImportMode
                    == EditorAssets::ModelImportMode::SkeletalMesh
                ? "Skeletal Mesh"
                : (selectedImportMode == EditorAssets::ModelImportMode::Animation
                    ? "Animation" : "Static Mesh");
            ImGui::SetNextItemWidth(260.0f);
            if (ImGui::BeginCombo("Import As", importAs)) {
                const bool staticSelected = importModelMode
                    == static_cast<int>(EditorAssets::ModelImportMode::StaticMesh);
                if (ImGui::Selectable("Static Mesh", staticSelected))
                    importModelMode = static_cast<int>(
                        EditorAssets::ModelImportMode::StaticMesh);
                const bool skeletalSelected = importModelMode
                    == static_cast<int>(EditorAssets::ModelImportMode::SkeletalMesh);
                if (ImGui::Selectable("Skeletal Mesh", skeletalSelected)) {
                    importModelMode = static_cast<int>(
                        EditorAssets::ModelImportMode::SkeletalMesh);
                    engine::SkeletalImportOptions& settings =
                        context.assets->SkeletalImportSettings();
                    settings.importSkeletalMesh = true;
                    settings.importSkeleton = true;
                    settings.reuseSkeletonPath.clear();
                }
                const bool animationSelected = importModelMode
                    == static_cast<int>(EditorAssets::ModelImportMode::Animation);
                if (ImGui::Selectable("Animation", animationSelected)) {
                    importModelMode = static_cast<int>(
                        EditorAssets::ModelImportMode::Animation);
                    engine::SkeletalImportOptions& settings =
                        context.assets->SkeletalImportSettings();
                    settings.importSkeletalMesh = false;
                    settings.importSkeleton = false;
                    settings.importEmbeddedAnimations = true;
                }
                ImGui::EndCombo();
            }
            if (importModelInspected) {
                ImGui::TextDisabled(
                    "Detected: %zu mesh(es), %zu animation(s), bones: %s",
                    importModelInfo.meshCount, importModelInfo.animationCount,
                    importModelInfo.hasBones ? "yes" : "no");
            } else if (!importInspectionError.empty()) {
                ImGui::TextColored(
                    ImVec4(1.0f, 0.55f, 0.25f, 1.0f), "%s",
                    importInspectionError.c_str());
            }

            if (importModelMode
                == static_cast<int>(EditorAssets::ModelImportMode::SkeletalMesh)
                || importModelMode
                    == static_cast<int>(EditorAssets::ModelImportMode::Animation)) {
                engine::SkeletalImportOptions& settings =
                    context.assets->SkeletalImportSettings();
                ImGui::DragFloat("Uniform Scale", &settings.uniformScale,
                                 0.01f, 0.001f, 1000.0f, "%.3f");
                ImGui::Checkbox("Generate Smooth Normals",
                                &settings.generateSmoothNormals);
                ImGui::Checkbox("Join Identical Vertices",
                                &settings.joinIdenticalVertices);
                ImGui::Checkbox("Flip UVs", &settings.flipUVs);
                ImGui::Checkbox("Import Animations",
                                &settings.importEmbeddedAnimations);
                const bool animationMode = importModelMode
                    == static_cast<int>(EditorAssets::ModelImportMode::Animation);
                ImGui::SeparatorText(animationMode
                    ? "Animation Import Outputs"
                    : "Skeletal Mesh Import Outputs");
                if (animationMode) {
                    ImGui::Checkbox("Import Mesh Asset",
                                    &settings.importSkeletalMesh);
                } else {
                    // Skeletal Mesh mode always emits the mesh. Its skeleton can
                    // either be created from the source or reused from Content.
                    settings.importSkeletalMesh = true;
                }

                const std::vector<std::string> skeletons =
                    context.assets->ContentAssetPaths(
                        EditorAssets::Type::Skeleton);
                const std::string skeletonLabel =
                    settings.reuseSkeletonPath.empty()
                    ? std::string("Create from source")
                    : settings.reuseSkeletonPath;
                ImGui::SetNextItemWidth(420.0f);
                if (ImGui::BeginCombo("Skeleton", skeletonLabel.c_str())) {
                    const bool createSelected =
                        settings.reuseSkeletonPath.empty();
                    if (ImGui::Selectable(
                            "Create from source", createSelected)) {
                        settings.reuseSkeletonPath.clear();
                        settings.importSkeleton = true;
                    }
                    if (createSelected) ImGui::SetItemDefaultFocus();
                    for (const std::string& path : skeletons) {
                        const bool selected =
                            settings.reuseSkeletonPath == path;
                        if (ImGui::Selectable(path.c_str(), selected)) {
                            settings.reuseSkeletonPath = path;
                            settings.importSkeleton = false;
                        }
                        if (selected) ImGui::SetItemDefaultFocus();
                    }
                    ImGui::EndCombo();
                }

                if (!settings.reuseSkeletonPath.empty()) {
                    settings.importSkeleton = false;
                    ImGui::BeginDisabled();
                }
                ImGui::Checkbox("Import Skeleton Asset",
                                &settings.importSkeleton);
                if (!settings.reuseSkeletonPath.empty())
                    ImGui::EndDisabled();

                if (settings.reuseSkeletonPath.empty()
                    && !settings.importSkeleton) {
                    ImGui::TextColored(
                        ImVec4(1.0f, 0.55f, 0.25f, 1.0f),
                        "Select an existing skeleton or import one from the source.");
                } else if (!settings.reuseSkeletonPath.empty()) {
                    ImGui::TextDisabled(animationMode
                        ? "Animation clips will reference the selected engine skeleton."
                        : "Mesh skin weights will be remapped to the selected engine skeleton.");
                }
                if (animationMode) {
                    ImGui::TextDisabled(
                        "Animation mode defaults to clips only to avoid duplicate meshes and skeletons.");
                } else {
                    ImGui::TextDisabled(
                        "Disable skeleton import by selecting an existing compatible skeleton above.");
                }
            } else {
                engine::StaticMeshImportOptions& settings =
                    context.assets->StaticMeshImportSettings();
                ImGui::DragFloat("Uniform Scale", &settings.uniformScale,
                                 0.01f, 0.001f, 1000.0f, "%.3f");
                ImGui::Checkbox("Generate Smooth Normals",
                                &settings.generateSmoothNormals);
                ImGui::Checkbox("Generate Tangents",
                                &settings.generateTangents);
                ImGui::Checkbox("Join Identical Vertices",
                                &settings.joinIdenticalVertices);
                ImGui::Checkbox("Flip UVs", &settings.flipUVs);
            }
        } else if (importingTexture) {
            engine::TextureImportOptions& settings =
                context.assets->TextureImportSettings();
            ImGui::Checkbox("sRGB Color Texture", &settings.srgb);
            ImGui::Checkbox("Smooth Filtering", &settings.smooth);
            ImGui::TextDisabled(
                "Disable sRGB for normal, roughness, metallic, and data maps.");
        } else if (importingAudio) {
            ImGui::TextUnformatted("Audio");
            ImGui::TextDisabled(
                "The source audio is preserved for the Audio Editor.");
        } else {
            ImGui::TextUnformatted("Project Asset");
            ImGui::TextDisabled(
                "This asset will be copied into the selected Content folder.");
        }

        ImGui::TextUnformatted("Store in project");
        const std::string destinationLabel = importDestination.empty()
            ? std::string("Content/")
            : std::string("Content/") + importDestination;
        ImGui::SetNextItemWidth(520.0f);
        if (ImGui::BeginCombo("##ImportDestination",
                              destinationLabel.c_str())) {
            const std::vector<std::string> folders =
                context.assets->ContentFolderPaths();
            for (const std::string& folder : folders) {
                const bool selected = folder == importDestination;
                const std::string label = folder.empty()
                    ? std::string("Content/")
                    : std::string("Content/") + folder;
                if (ImGui::Selectable(label.c_str(), selected)) {
                    importDestination = folder;
                }
                if (selected) ImGui::SetItemDefaultFocus();
            }
            ImGui::EndCombo();
        }

        ImGui::SeparatorText("Create destination folder");
        ImGui::SetNextItemWidth(390.0f);
        ImGui::InputText("##ImportNewFolder", importFolderName,
                         sizeof(importFolderName));
        ImGui::SameLine();
        if (ImGui::Button("Create and use")) {
            std::string createdFolder;
            std::string error;
            if (context.assets->CreateFolderAt(
                    importDestination, importFolderName,
                    &createdFolder, &error)) {
                importDestination = createdFolder;
                importFolderName[0] = '\0';
                if (context.log) {
                    context.log->Info("Created Content folder: "
                                      + createdFolder);
                }
            } else if (context.log) {
                context.log->Error(error);
            }
        }

        ImGui::Spacing();
        bool skeletalSettingsValid = true;
        if (importModelMode
                == static_cast<int>(EditorAssets::ModelImportMode::Animation)
            || importModelMode
                == static_cast<int>(EditorAssets::ModelImportMode::SkeletalMesh)) {
            const engine::SkeletalImportOptions& settings =
                context.assets->SkeletalImportSettings();
            skeletalSettingsValid = settings.importSkeleton
                || !settings.reuseSkeletonPath.empty();
            if (importModelMode
                == static_cast<int>(EditorAssets::ModelImportMode::Animation)) {
                skeletalSettingsValid = skeletalSettingsValid
                    && settings.importEmbeddedAnimations
                    && (!importModelInspected
                        || importModelInfo.animationCount > 0);
            }
        }
        const bool canImport = !importSource.empty() && skeletalSettingsValid;
        if (!canImport) ImGui::BeginDisabled();
        if (ImGui::Button("Import", ImVec2(120.0f, 0.0f))) {
            std::string error;
            if (context.assets->ImportAssetToFolder(
                    importSource, importDestination,
                    static_cast<EditorAssets::ModelImportMode>(
                        importModelMode),
                    &error)) {
                if (context.log) {
                    context.log->Info(context.assets->LastImportMessage());
                }
                importSource.clear();
                ImGui::CloseCurrentPopup();
            } else if (context.log) {
                context.log->Error(error);
            }
        }
        if (!canImport) ImGui::EndDisabled();
        ImGui::SameLine();
        if (ImGui::Button("Cancel", ImVec2(120.0f, 0.0f))) {
            importSource.clear();
            ImGui::CloseCurrentPopup();
        }
        ImGui::EndPopup();
    }
    ImGui::Separator();

    const std::vector<EditorAssets::Folder>& folders = context.assets->Folders();
    for (int i = 0; i < static_cast<int>(folders.size()); ++i) {
        const EditorAssets::Folder& folder = folders[static_cast<std::size_t>(i)];
        char label[256];
        const std::string folderLabel = editor::icons::Label(
            editor::icons::Folder, folder.displayName.c_str());
        std::snprintf(label, sizeof(label), "%s", folderLabel.c_str());
        const bool selected = context.assets->SelectedType() == EditorAssets::SelectionType::Folder
            && context.assets->SelectedFolderIndex() == i;
        ImGui::PushStyleColor(ImGuiCol_Text, editor::icons::FolderColor());
        if (ImGui::Selectable(label, selected)) {
            context.assets->SelectFolderIndex(i);
        }
        ImGui::PopStyleColor();
        bool openFromContext = false;
        ImGui::PushID(i);
        if (ImGui::BeginPopupContextItem("FolderActions")) {
            context.assets->SelectFolderIndex(i);
            if (editor::icons::MenuItem(editor::icons::Open, "Open"))
                openFromContext = true;
            ImGui::Separator();
            if (editor::icons::MenuItem(editor::icons::Copy, "Copy")) copySelected();
            if (editor::icons::MenuItem(editor::icons::Cut, "Cut")) cutSelected();
            if (editor::icons::MenuItem(editor::icons::Copy, "Duplicate")) {
                copySelected();
                pasteCopied();
            }
            if (editor::icons::MenuItem(editor::icons::Edit, "Rename...")) beginRename();
            ImGui::Separator();
            if (editor::icons::MenuItem(editor::icons::Delete, "Delete...")) beginDelete();
            ImGui::EndPopup();
        }
        ImGui::PopID();
        if (openFromContext
            || (selected && ImGui::IsItemHovered()
                && ImGui::IsMouseDoubleClicked(ImGuiMouseButton_Left))) {
            std::string error;
            if (!context.assets->EnterFolder(i, &error) && context.log) {
                context.log->Error(error);
            }
        }
    }

    const std::vector<EditorAssets::Asset>& assets = context.assets->Assets();
    for (int i = 0; i < static_cast<int>(assets.size()); ++i) {
        const EditorAssets::Asset& asset = assets[static_cast<std::size_t>(i)];
        char label[256];
        const std::string assetText = std::string("[")
            + EditorAssets::TypeName(asset.type) + "] " + asset.displayName;
        const editor::icons::AssetStyle iconStyle = editor::icons::ForAsset(asset.type);
        const std::string assetLabel = editor::icons::Label(
            iconStyle.glyph, assetText.c_str());
        std::snprintf(label, sizeof(label), "%s", assetLabel.c_str());

        const bool selected = context.assets->SelectedType() == EditorAssets::SelectionType::Asset
            && i == context.assets->SelectedIndex();
        ImGui::PushStyleColor(ImGuiCol_Text, iconStyle.color);
        if (ImGui::Selectable(label, selected)) {
            context.assets->SelectIndex(i);
        }
        ImGui::PopStyleColor();
        const bool assetHovered = ImGui::IsItemHovered();
        bool openFromContext = false;
        ImGui::PushID(i);
        if (ImGui::BeginPopupContextItem("AssetActions")) {
            context.assets->SelectIndex(i);
            if (editor::icons::MenuItem(editor::icons::Open, "Open"))
                openFromContext = true;
            ImGui::Separator();
            if (editor::icons::MenuItem(editor::icons::Copy, "Copy")) copySelected();
            if (editor::icons::MenuItem(editor::icons::Cut, "Cut")) cutSelected();
            if (editor::icons::MenuItem(editor::icons::Copy, "Duplicate")) {
                copySelected();
                pasteCopied();
            }
            if (editor::icons::MenuItem(editor::icons::Edit, "Rename...")) beginRename();
            if (editor::icons::MenuItem(editor::icons::Copy, "Copy Asset Path")) {
                const std::string path = context.assets->SelectedAssetFullPath();
                ImGui::SetClipboardText(path.c_str());
                if (context.log) context.log->Info("Copied asset path: " + path);
            }
            const std::string extension =
                std::filesystem::path(asset.relativePath).extension().string();
            const bool canReimport = extension == ".3dgmesh"
                || extension == ".3dgskmesh" || extension == ".3dgtex";
            if (!canReimport) ImGui::BeginDisabled();
            if (editor::icons::MenuItem(editor::icons::Refresh, "Reimport"))
                reimportSelected();
            if (!canReimport) ImGui::EndDisabled();
            ImGui::Separator();
            if (editor::icons::MenuItem(editor::icons::Delete, "Delete...")) beginDelete();
            ImGui::EndPopup();
        }
        ImGui::PopID();
        if (assetHovered && asset.relativePath != asset.displayName) {
            ImGui::SetTooltip("Content/%s", asset.relativePath.c_str());
        }
        if (openFromContext
            || (assetHovered && ImGui::IsMouseDoubleClicked(ImGuiMouseButton_Left))) {
            const std::string fullPath =
                (std::filesystem::path(context.assets->RootPath()) / asset.relativePath).string();
            if (asset.type == EditorAssets::Type::Scene) {
                context.sceneAssetOpenRequested = fullPath;
            } else if (asset.type == EditorAssets::Type::BehaviorGraph) {
                context.behaviorGraphAssetOpenRequested = fullPath;
            } else if (asset.type == EditorAssets::Type::Script) {
                std::string error;
                if (!OpenScriptInPreferredEditor(context, fullPath, &error) && context.log) {
                    context.log->Error("Script source open failed: " + error);
                }
            } else if (asset.type == EditorAssets::Type::Audio) {
                context.panels->SetOpen(EditorPanels::Panel::AudioEditor, true);
                if (IsEditableAudioPath(fullPath)) {
                    LoadAudioIntoEditor(fullPath, context.log);
                } else {
                    std::string extension = std::filesystem::path(fullPath).extension().string();
                    std::transform(extension.begin(), extension.end(), extension.begin(),
                        [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
                    std::string error;
                    if (extension == ".3dgaudio") {
                        std::snprintf(g_audioEditor.cuePath.data(), g_audioEditor.cuePath.size(),
                            "%s", fullPath.c_str());
                        if (engine::LoadAudioCue(fullPath, &g_audioEditor.cue, &error)) {
                            g_audioEditor.selectedCueClip = g_audioEditor.cue.clips.empty() ? -1 : 0;
                        } else if (context.log) context.log->Error("Audio Cue: " + error);
                    } else if (extension == ".3dgmusic") {
                        std::snprintf(g_audioEditor.musicPath.data(), g_audioEditor.musicPath.size(),
                            "%s", fullPath.c_str());
                        if (engine::LoadAdaptiveMusic(fullPath, &g_audioEditor.music, &error)) {
                            g_audioEditor.selectedMusicState = g_audioEditor.music.states.empty() ? -1 : 0;
                        } else if (context.log) context.log->Error("Adaptive Music: " + error);
                    } else if (extension == ".3dgmixer") {
                        context.panels->SetOpen(EditorPanels::Panel::AudioMixer, true);
                        std::snprintf(context.audioMixerPresetPath.data(),
                            context.audioMixerPresetPath.size(), "%s", fullPath.c_str());
                        context.loadAudioMixerPresetRequested = true;
                    }
                }
            } else {
                context.editorAssetOpenRequested = fullPath;
                context.editorAssetOpenType = asset.type;
            }
        }

        if (context.dragDrop && ImGui::BeginDragDropSource(ImGuiDragDropFlags_SourceAllowNullID)) {
            context.assets->SelectIndex(i);
            const ImVec2 mouse = ImGui::GetMousePos();
            const std::string fullPath = (std::filesystem::path(context.assets->RootPath()) / asset.relativePath).string();
            if (!context.dragDrop->IsMouseDriven()
                || context.dragDrop->CurrentPayload().path != fullPath) {
                context.dragDrop->BeginAssetDragAt(fullPath, EditorAssets::TypeName(asset.type), mouse.x, mouse.y);
            } else {
                context.dragDrop->UpdateCursor(mouse.x, mouse.y);
            }

            ImGui::SetDragDropPayload("3DGEDITOR_ASSET", fullPath.c_str(), fullPath.size() + 1);
            ImGui::Text("%s", label);
            ImGui::EndDragDropSource();
        }
    }

    if (ImGui::BeginPopupContextWindow("ContentBrowserActions",
            ImGuiPopupFlags_MouseButtonRight | ImGuiPopupFlags_NoOpenOverItems)) {
        if (editor::icons::MenuItem(editor::icons::Add, "Create Folder..."))
            requestCreateFolderPopup = true;
        if (!context.assets->HasCopiedEntry()) ImGui::BeginDisabled();
        if (editor::icons::MenuItem(editor::icons::Paste, "Paste")) pasteCopied();
        if (!context.assets->HasCopiedEntry()) ImGui::EndDisabled();
        ImGui::Separator();
        if (editor::icons::MenuItem(editor::icons::Download, "Import Asset...")) {
            const std::string selected =
                editor::OpenAssetImportDialog("Import Asset into Content");
            if (!selected.empty()) {
                prepareImportSource(selected);
                importDestination = context.assets->CurrentFolder();
                importFolderName[0] = '\0';
                requestImportPopup = true;
            }
        }
        if (editor::icons::MenuItem(editor::icons::Refresh, "Refresh")) {
            std::string error;
            if (!context.assets->Refresh(context.assets->RootPath(), &error)
                && context.log) context.log->Error(error);
        }
        ImGui::EndPopup();
    }

    if (requestRenamePopup) ImGui::OpenPopup("Rename Content Entry");
    if (requestDeletePopup) ImGui::OpenPopup("Delete Content Entry");
    if (requestCreateFolderPopup) ImGui::OpenPopup("Create Content Folder");
    if (requestImportPopup) ImGui::OpenPopup("Asset Import Settings##ContentBrowser");

    ImGui::End();
}

void DrawStandaloneScriptEditor(EditorDockspace::Context& context) {
    if (!g_scriptEditorWindowOpen || !g_scriptSourceLoaded) return;
    EnsureScriptEditorSettings(context);
    if (!ImGui::Begin("Script Editor", &g_scriptEditorWindowOpen)) {
        ImGui::End();
        return;
    }

    ImGui::TextWrapped("%s", g_scriptSourcePath.c_str());
    const char* editors[] = {"Built-in", "VS Code", "Visual Studio", "Rider", "Custom"};
    if (ImGui::Combo("Code Editor", &g_preferredCodeEditor, editors, 5)) {
        SaveScriptEditorSettings(context);
    }
    if (g_preferredCodeEditor == static_cast<int>(PreferredCodeEditor::Custom)) {
        if (ImGui::InputText("Editor Executable", g_customCodeEditorPath.data(),
                g_customCodeEditorPath.size())) {
            SaveScriptEditorSettings(context);
        }
    }
    if (g_preferredCodeEditor != static_cast<int>(PreferredCodeEditor::BuiltIn)) {
        if (editor::icons::LabeledButton(editor::icons::Open, "Open in Selected Editor")) {
            std::string error;
            if (!EditorScriptTools::OpenExternalEditor(
                    static_cast<PreferredCodeEditor>(g_preferredCodeEditor),
                    g_customCodeEditorPath.data(), g_scriptSourcePath,
                    ProjectRootFor(context), &error) && context.log) {
                context.log->Error("Code editor: " + error);
            }
        }
    }
    const bool editingLua =
        std::filesystem::path(g_scriptSourcePath).extension() == ".lua";
    ImGui::TextDisabled(editingLua
        ? "Lua runs directly. Save it, then restart Play to load changes."
        : "Native scripts can compile and hot-reload automatically after saving.");
    if (!editingLua && context.autoCompileScripts) {
        if (ImGui::Checkbox("Compile automatically when saved", context.autoCompileScripts)) {
            if (context.config) {
                context.config->Set("scripting.auto_compile_on_save", *context.autoCompileScripts);
                context.config->Save();
            }
        }
        ImGui::SameLine();
        if (context.scriptBuildRunning) {
            ImGui::TextDisabled("Building...");
        } else if (context.scriptBuildStatus) {
            ImGui::TextDisabled("%s", context.scriptBuildStatus->c_str());
        }
    }
    ImGui::Separator();
    if (g_scriptEditorTargetLine > 0) ImGui::SetKeyboardFocusHere();
    if (ImGui::InputTextMultiline("##StandaloneScriptSource",
            g_scriptSourceBuffer.data(), g_scriptSourceBuffer.size(),
            ImVec2(-1.0f, -ImGui::GetFrameHeightWithSpacing() * 2.0f),
            ImGuiInputTextFlags_AllowTabInput | ImGuiInputTextFlags_CallbackAlways,
            ScriptSourceNavigationCallback)) {
        g_scriptSourceDirty = true;
    }

    if (editor::icons::LabeledButton(editor::icons::Save,
            g_scriptSourceDirty ? "Save Source *" : "Save Source")) {
        std::string error;
        if (WriteTextFile(g_scriptSourcePath, g_scriptSourceBuffer.data(), &error)) {
            g_scriptSourceDirty = false;
            if (context.log) context.log->Info("Saved script source: " + g_scriptSourcePath);
        } else if (context.log) {
            context.log->Error("Script source save failed: " + error);
        }
    }
    ImGui::SameLine();
    if (editor::icons::LabeledButton(editor::icons::Refresh, "Reload Source")) {
        std::string error;
        if (!LoadScriptSource(g_scriptSourcePath, &error) && context.log) {
            context.log->Error("Script source reload failed: " + error);
        }
    }
    ImGui::SameLine();
    ImGui::TextDisabled(g_scriptSourceDirty ? "Unsaved changes" : "Saved");
    ImGui::Separator();
    ImGui::BeginDisabled(context.playMode || editingLua || context.scriptBuildRunning);
    if (editor::icons::LabeledButton(editor::icons::Code, "Compile Scripts & Restart")) {
        std::string error;
        bool saved = true;
        if (g_scriptSourceDirty) {
            saved = WriteTextFile(g_scriptSourcePath, g_scriptSourceBuffer.data(), &error);
            if (saved) g_scriptSourceDirty = false;
        }
        if (saved) context.scriptCompileAndRestartRequested = true;
        else if (context.log) context.log->Error("Script source save failed: " + error);
    }
    ImGui::EndDisabled();
    if ((context.playMode || editingLua || context.scriptBuildRunning)
        && ImGui::IsItemHovered(ImGuiHoveredFlags_AllowWhenDisabled)) {
        ImGui::SetTooltip(editingLua ? "Lua scripts do not need compilation."
            : (context.scriptBuildRunning ? "A script build is already running."
                                          : "Exit Play mode before compiling and restarting."));
    }
    ImGui::SameLine();
    ImGui::BeginDisabled(editingLua || context.scriptBuildRunning);
    if (editor::icons::LabeledButton(editor::icons::Refresh, "Hot Reload")) {
        std::string error;
        bool saved = true;
        if (g_scriptSourceDirty) {
            saved = WriteTextFile(g_scriptSourcePath, g_scriptSourceBuffer.data(), &error);
            if (saved) g_scriptSourceDirty = false;
        }
        if (saved) context.scriptHotReloadRequested = true;
        else if (context.log) context.log->Error("Script source save failed: " + error);
    }
    ImGui::EndDisabled();
    if (ImGui::IsItemHovered(ImGuiHoveredFlags_AllowWhenDisabled)) {
        ImGui::SetTooltip(editingLua
            ? "Lua scripts reload when Play starts."
            : (context.scriptBuildRunning
                ? "A script build is already running."
                : "Build the project script module and safely reload it in Edit or Play mode."));
    }
    ImGui::SameLine();
    if (editor::icons::LabeledButton(editor::icons::Document, "Last Build Log")) {
        g_scriptBuildLog = EditorScriptTools::ReadLastBuildLog(ProjectRootFor(context));
        if (g_scriptBuildLog.empty()) g_scriptBuildLog = "No script build has run yet.";
        g_scriptBuildLogOpen = true;
    }
    ImGui::End();
}

struct CompileDiagnostic {
    bool error = true;
    std::string file;
    int line = 0;
    int column = 0;
    std::string message;   // e.g. "error C2065: 'foo': undeclared identifier"
};

// Parse MSVC/MSBuild output into structured diagnostics: lines of the form
// "path(line): error C####: msg" (or "warning", "fatal error"), plus file-less
// linker/tool errors ("LINK : fatal error LNK1120: ...").
std::vector<CompileDiagnostic> ParseCompileDiagnostics(const std::string& log) {
    std::vector<CompileDiagnostic> diagnostics;
    std::size_t start = 0;
    while (start < log.size()) {
        std::size_t end = log.find('\n', start);
        if (end == std::string::npos) end = log.size();
        std::string text = log.substr(start, end - start);
        start = end + 1;
        if (!text.empty() && text.back() == '\r') text.pop_back();

        const std::size_t errPos = text.find(": error ");
        const std::size_t fatalPos = text.find(": fatal error ");
        const std::size_t warnPos = text.find(": warning ");
        std::size_t sevPos = std::string::npos;
        bool isError = true;
        auto consider = [&](std::size_t pos, bool err) {
            if (pos != std::string::npos && (sevPos == std::string::npos || pos < sevPos)) {
                sevPos = pos;
                isError = err;
            }
        };
        consider(errPos, true);
        consider(fatalPos, true);
        consider(warnPos, false);
        if (sevPos == std::string::npos) continue;

        CompileDiagnostic diagnostic;
        diagnostic.error = isError;
        diagnostic.message = text.substr(sevPos + 2);   // skip ": "

        std::string before = text.substr(0, sevPos);
        const std::size_t open = before.rfind('(');
        const std::size_t close = before.rfind(')');
        if (open != std::string::npos && close != std::string::npos && close > open) {
            diagnostic.file = before.substr(0, open);
            std::sscanf(before.substr(open + 1, close - open - 1).c_str(),
                        "%d,%d", &diagnostic.line, &diagnostic.column);
        } else {
            diagnostic.file = before;   // file-less (e.g. "LINK")
        }
        while (!diagnostic.file.empty()
               && (diagnostic.file.back() == ' ' || diagnostic.file.back() == '\t')) {
            diagnostic.file.pop_back();
        }
        diagnostics.push_back(std::move(diagnostic));
    }
    return diagnostics;
}

void DrawScriptBuildLog(EditorDockspace::Context& context) {
    static std::string observedBuildStatus;
    if (context.scriptBuildStatus && *context.scriptBuildStatus != observedBuildStatus) {
        observedBuildStatus = *context.scriptBuildStatus;
        if (observedBuildStatus.rfind("Compilation failed", 0) == 0) {
            g_scriptBuildLog = EditorScriptTools::ReadLastBuildLog(ProjectRootFor(context));
            if (g_scriptBuildLog.empty()) g_scriptBuildLog = observedBuildStatus;
            g_scriptBuildLogOpen = true;
        }
    }
    if (!g_scriptBuildLogOpen) return;
    if (ImGui::Begin("Script Compiler Output", &g_scriptBuildLogOpen)) {
        const std::vector<CompileDiagnostic> diagnostics =
            ParseCompileDiagnostics(g_scriptBuildLog);
        int errors = 0, warnings = 0;
        for (const CompileDiagnostic& d : diagnostics) (d.error ? errors : warnings) += 1;

        if (diagnostics.empty()) {
            ImGui::TextDisabled("No errors or warnings parsed from the last build.");
        } else {
            ImGui::Text("%d error(s), %d warning(s) - click one to open its file",
                        errors, warnings);
            ImGui::BeginChild("##scriptdiagnostics", ImVec2(0.0f, 180.0f), true);
            for (std::size_t i = 0; i < diagnostics.size(); ++i) {
                const CompileDiagnostic& d = diagnostics[i];
                ImGui::PushID(static_cast<int>(i));
                ImGui::PushStyleColor(ImGuiCol_Text, d.error
                    ? ImVec4(1.0f, 0.45f, 0.40f, 1.0f)
                    : ImVec4(1.0f, 0.80f, 0.35f, 1.0f));
                std::string label = d.file.empty()
                    ? std::string("(build)")
                    : std::filesystem::path(d.file).filename().string();
                if (d.line > 0) {
                    label += "(" + std::to_string(d.line);
                    if (d.column > 0) label += "," + std::to_string(d.column);
                    label += ")";
                }
                label += ": " + d.message;
                std::filesystem::path resolvedSource = d.file;
                std::error_code sourceErrorCode;
                if (resolvedSource.is_relative()) {
                    const std::filesystem::path fromProject =
                        ProjectRootFor(context) / resolvedSource;
                    if (std::filesystem::is_regular_file(fromProject, sourceErrorCode)) {
                        resolvedSource = fromProject;
                    }
                }
                sourceErrorCode.clear();
                const bool canOpen = !d.file.empty()
                    && std::filesystem::is_regular_file(resolvedSource, sourceErrorCode);
                const bool clicked = ImGui::Selectable(label.c_str(), false,
                    canOpen ? ImGuiSelectableFlags_None : ImGuiSelectableFlags_Disabled);
                ImGui::PopStyleColor();
                if (ImGui::IsItemHovered(ImGuiHoveredFlags_AllowWhenDisabled)) {
                    ImGui::SetTooltip("%s", canOpen ? resolvedSource.string().c_str()
                                                     : "Build-system message (no source location)");
                }
                if (clicked && canOpen) {
                    const std::filesystem::path& sourcePath = resolvedSource;
                    std::string sourceError;
                    EnsureScriptEditorSettings(context);
                    const PreferredCodeEditor preferred = static_cast<PreferredCodeEditor>(
                        std::clamp(g_preferredCodeEditor, 0, 4));
                    if (preferred == PreferredCodeEditor::BuiltIn) {
                        if (LoadScriptSource(sourcePath.string(), &sourceError)) {
                            g_scriptEditorTargetLine = std::max(d.line, 1);
                            g_scriptEditorTargetColumn = std::max(d.column, 1);
                            g_scriptEditorWindowOpen = true;
                        }
                    } else if (!EditorScriptTools::OpenExternalEditor(
                            preferred, g_customCodeEditorPath.data(), sourcePath,
                            ProjectRootFor(context), &sourceError, d.line, d.column)) {
                        // sourceError is reported below.
                    } else {
                        sourceError.clear();
                    }
                    if (!sourceError.empty() && context.log) {
                        context.log->Error("Could not open compiler diagnostic: " + sourceError);
                    }
                }
                ImGui::PopID();
            }
            ImGui::EndChild();
        }

        ImGui::Separator();
        ImGui::TextDisabled("Raw output");
        ImGui::InputTextMultiline("##ScriptBuildLog", g_scriptBuildLog.data(),
            g_scriptBuildLog.size() + 1, ImVec2(-1.0f, -1.0f),
            ImGuiInputTextFlags_ReadOnly);
    }
    ImGui::End();
}

void DrawPackageSettings(EditorDockspace::Context& context) {
    if (context.packageSettingsRequested) ImGui::OpenPopup("Package Project");

    bool open = true;
    if (!ImGui::BeginPopupModal("Package Project", &open,
            ImGuiWindowFlags_AlwaysAutoResize)) return;

    ImGui::TextUnformatted("Build a standalone, distributable game from the current project.");
    ImGui::Separator();

    const bool validSettings = context.packageOutputBuffer
        && context.packageOutputBufferSize > 0
        && context.packageConfiguration
        && context.packageStaticRuntime
        && context.packageCleanOutput
        && context.packageCreateZip;
    if (!validSettings) {
        ImGui::TextColored(ImVec4(1.0f, 0.45f, 0.35f, 1.0f),
            "Packaging settings are unavailable for this project.");
        if (ImGui::Button("Close")) ImGui::CloseCurrentPopup();
        ImGui::EndPopup();
        return;
    }

    ImGui::BeginDisabled(context.packageBuildRunning);
    ImGui::SetNextItemWidth(430.0f);
    if (ImGui::InputText("Output Folder", context.packageOutputBuffer,
            context.packageOutputBufferSize))
        context.packageSettingsChanged = true;
    ImGui::SameLine();
    if (ImGui::Button("Browse...")) context.browsePackageOutputRequested = true;

    static const char* configurations[] = {"Release", "RelWithDebInfo", "Debug"};
    ImGui::SetNextItemWidth(190.0f);
    if (ImGui::Combo("Configuration", context.packageConfiguration,
            configurations, IM_ARRAYSIZE(configurations)))
        context.packageSettingsChanged = true;
    if (ImGui::Checkbox("Static C/C++ runtime", context.packageStaticRuntime))
        context.packageSettingsChanged = true;
    if (ImGui::IsItemHovered())
        ImGui::SetTooltip("Recommended for distribution: reduces runtime prerequisites.");
    if (ImGui::Checkbox("Clean previous staged package", context.packageCleanOutput))
        context.packageSettingsChanged = true;
    if (ImGui::Checkbox("Create ZIP archive", context.packageCreateZip))
        context.packageSettingsChanged = true;

    ImGui::Spacing();
    ImGui::TextDisabled("Pipeline:");
    ImGui::BulletText("Save and cook the current scene and required assets");
    ImGui::BulletText("Build the standalone player and project scripts");
    ImGui::BulletText("Stage a runnable folder in the selected output location");
    if (*context.packageCreateZip)
        ImGui::BulletText("Create a ZIP beside the staged folder");

    const bool canPackage = context.project && !context.playMode
        && context.packageOutputBuffer[0] != '\0';
    ImGui::BeginDisabled(!canPackage);
    if (ImGui::Button(editor::icons::Label(
            editor::icons::Archive, "Package Project").c_str()))
        context.packageProjectRequested = true;
    ImGui::EndDisabled();
    ImGui::SameLine();
    if (ImGui::Button("Cancel")) ImGui::CloseCurrentPopup();
    ImGui::EndDisabled();

    if (context.playMode)
        ImGui::TextDisabled("Stop Play mode before packaging.");
    if (context.packageBuildRunning) {
        ImGui::Spacing();
        ImGui::TextColored(ImVec4(0.25f, 0.75f, 0.90f, 1.0f),
            "Packaging in progress...");
    }
    if (context.packageBuildStatus && !context.packageBuildStatus->empty()) {
        ImGui::PushTextWrapPos(560.0f);
        ImGui::TextWrapped("%s", context.packageBuildStatus->c_str());
        ImGui::PopTextWrapPos();
    }

    if (context.packageProjectRequested) ImGui::CloseCurrentPopup();
    ImGui::EndPopup();
}

void DrawScriptApiBrowser(EditorDockspace::Context& /*context*/, bool* open) {
    if (!ImGui::Begin(EditorPanels::Name(EditorPanels::Panel::ScriptApi), open)) {
        ImGui::End();
        return;
    }

    struct ApiEntry { const char* group; const char* signature; const char* description; };
    static const ApiEntry entries[] = {
        {"Core", "Entity Self()", "This script's own entity."},
        {"Core", "Transform* Transform()", "This entity's transform (position/rotation/scale)."},
        {"Core", "Entity FindObject(\"Name\")", "Find another scene object by name."},
        {"Core", "void DestroySelf()", "Destroy this entity at end of frame."},
        {"Core", "void Destroy(entity)", "Destroy another entity."},
        {"Core", "Entity SpawnFromObject(\"Proto\", pos)", "Spawn a copy of a named object at a position."},
        {"Core", "int Delay(seconds, fn)", "Run fn once after a delay."},
        {"Core", "int SetTimer(seconds, fn, repeat=false)", "Run fn after a delay, optionally repeating."},
        {"Core", "int SetTimerByEvent(seconds, fn, repeat=false)", "Event-style alias for callback timers."},
        {"Core", "bool BindTimerFunction(\"Name\", fn)", "Register a C++ callback for named timers."},
        {"Core", "int SetTimerByFunctionName(\"Name\", sec, repeat=false)", "Run a registered C++ or Lua function by name."},
        {"Core", "void ClearTimer(id)", "Cancel a running timer."},
        {"Core", "int ClearTimerByFunctionName(\"Name\")", "Cancel every timer using a function name."},
        {"Core", "bool IsTimerActive(id or name)", "Query a timer by handle or function name."},
        {"Core", "Sequence().Do(fn).Wait(sec).Do(fn)", "Run steps across frames (coroutine-style)."},
        {"Core", "Sequence().WaitUntil(pred).Do(fn)", "Wait for a condition, then run steps."},
        {"Core", "void RequestSceneLoad(\"path\")", "Load a runtime scene next frame."},

        {"Time", "void SetGlobalTimeDilation(scale)", "Set gameplay speed; 1 normal, 0 frozen."},
        {"Time", "float GlobalTimeDilation()", "Read the configured base gameplay speed."},
        {"Time", "float EffectiveTimeDilation()", "Read base speed with an active hit stop applied."},
        {"Time", "void HitStop(realSeconds, scale=0)", "Temporarily freeze or nearly freeze gameplay."},
        {"Time", "bool IsHitStopActive()", "Is a temporary impact freeze active."},

        {"Components", "T* TryGet<T>()", "Component T on this entity, or nullptr."},
        {"Components", "bool Has<T>()", "Does this entity have component T."},
        {"Components", "T& Add<T>(value)", "Add component T to this entity."},
        {"Components", "void Remove<T>()", "Remove component T from this entity."},

        {"Spline", "int SplinePointCount(entity)", "Number of control points on a spline object."},
        {"Spline", "vec3 GetSplinePoint(entity, index)", "Read a control point (C++ index starts at 0; Lua at 1)."},
        {"Spline", "bool SetSplinePoint(entity, index, pos)", "Move a control point at runtime."},
        {"Spline", "vec3 GetSplinePointRotation(entity, index)", "Read point rotation in degrees."},
        {"Spline", "bool SetSplinePointRotation(entity, index, degrees)", "Rotate a point; Z banks a river."},
        {"Spline", "int AddSplinePoint(entity, pos, rotation={})", "Append a point and return its index."},
        {"Spline", "bool InsertSplinePoint(entity, index, pos, rotation={})", "Insert a control point."},
        {"Spline", "bool RemoveSplinePoint(entity, index)", "Remove a control point."},
        {"Spline", "bool TranslateSpline(entity, delta)", "Move every point together."},
        {"Spline", "bool SetSplineClosed(entity, closed)", "Toggle open or closed-loop mode."},
        {"Spline", "vec3 SplinePositionAt(entity, 0..1)", "Sample an arc-length position."},
        {"Spline", "vec3 SplineTangentAt(entity, 0..1)", "Sample the normalized path direction."},
        {"Spline", "float SplineLength(entity)", "Get the spline's world-space arc length."},
        {"Spline", "vec3 SplineClosestPoint(entity, world)", "Find the nearest point on the curve."},
        {"Spline", "float SplineClosestDistance(entity, world)", "Arc distance from the start to the nearest point."},

        {"Input", "bool Input().KeyDown(key)", "Key currently held."},
        {"Input", "bool Input().KeyPressed(key)", "Key pressed this frame."},
        {"Input", "bool Input().MouseDown(button)", "Mouse button held."},
        {"Input", "bool Input().MousePressed(button)", "Mouse button pressed this frame."},
        {"Input", "float Input().MouseDeltaX()", "Mouse X movement this frame."},
        {"Input", "float Input().MouseDeltaY()", "Mouse Y movement this frame."},

        {"Anim", "bool Anim().PlayAction(clip)", "Play a one-shot action by index or name."},
        {"Anim", "bool Anim().PlayMaskedAction(clip, rootBone)", "Play an action on part of the skeleton."},
        {"Anim", "bool Anim().PlayActionClip(\"Name\")", "Play a named Action Clip."},
        {"Anim", "bool Anim().SetParameter(name, value)", "Set a float animation parameter."},
        {"Anim", "bool Anim().SetBool(name, value)", "Set a bool animation parameter."},
        {"Anim", "bool Anim().SetTrigger(name)", "Fire an animation trigger."},
        {"Anim", "float Anim().GetParameter(name)", "Read a float animation parameter."},
        {"Anim", "bool Anim().IsActionPlaying()", "Is a one-shot action currently playing."},

        {"Audio", "bool Audio().Play(restart=false)", "Play this entity's audio source."},
        {"Audio", "bool Audio().Stop()", "Stop this entity's audio."},
        {"Audio", "bool Audio().SetVolume(v)", "Set audio volume (0..1)."},
        {"Audio", "bool Audio().SetPitch(p)", "Set audio pitch."},
        {"Audio", "bool Audio().PlayCue(\"path\", spatial=true)", "Fire a one-shot sound."},
        {"Audio", "bool Audio().SetMusicState(\"state\")", "Switch adaptive-music state."},

        {"Camera", "bool Camera().Shake(intensity, dur, freq)", "Camera shake."},
        {"Camera", "bool Camera().PlaySequence(\"name\")", "Play an authored camera sequence."},
        {"Camera", "bool Camera().StopSequence()", "Stop the active camera sequence."},
        {"Camera", "bool Camera().IsSequencePlaying()", "Is a camera sequence running."},

        {"Particles", "bool Particles().Play(restart=false)", "Start this entity's particle system."},
        {"Particles", "bool Particles().Stop(clear=false)", "Stop emitting particles."},
        {"Particles", "bool Particles().Burst(count=0)", "Emit a burst of particles."},
        {"Particles", "int Particles().Count()", "Live particle count."},

        {"Fields", "float GetFieldFloat(\"Name\", fallback)", "Read a Float inspector field."},
        {"Fields", "int GetFieldInt(\"Name\", fallback)", "Read an Int field."},
        {"Fields", "bool GetFieldBool(\"Name\", fallback)", "Read a Bool field."},
        {"Fields", "std::string GetFieldString(\"Name\")", "Read a String field."},
        {"Fields", "glm::vec3 GetFieldVec3(\"Name\")", "Read a Vec3 field."},
        {"Fields", "glm::vec3 GetFieldColor(\"Name\")", "Read a Color field."},
        {"Fields", "Entity GetFieldEntity(\"Name\")", "Read an Entity-reference field."},
        {"Fields", "std::string GetFieldAsset(\"Name\")", "Read an Asset-path field."},
    };

    static std::array<char, 64> searchBuffer{};
    ImGui::SetNextItemWidth(-1.0f);
    ImGui::InputTextWithHint("##scriptapisearch", "Search the script API...",
                             searchBuffer.data(), searchBuffer.size());
    const auto toLower = [](std::string s) {
        for (char& c : s) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
        return s;
    };
    const std::string filter = toLower(searchBuffer.data());

    ImGui::TextDisabled("Click a signature to copy it; hover for a description.");
    ImGui::Separator();
    ImGui::BeginChild("##scriptapilist");
    std::string currentGroup;
    for (const ApiEntry& entry : entries) {
        if (!filter.empty()) {
            const std::string hay = toLower(std::string(entry.signature) + ' '
                                            + entry.description + ' ' + entry.group);
            if (hay.find(filter) == std::string::npos) continue;
        }
        if (currentGroup != entry.group) {
            currentGroup = entry.group;
            ImGui::SeparatorText(entry.group);
        }
        if (ImGui::Selectable(entry.signature)) {
            ImGui::SetClipboardText(entry.signature);
        }
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", entry.description);
    }
    ImGui::EndChild();
    ImGui::End();
}

void DrawConsole(EditorDockspace::Context& context, bool* open) {
    if (!ImGui::Begin(EditorPanels::Name(EditorPanels::Panel::Console), open)) {
        ImGui::End();
        return;
    }

    if (!context.log) {
        ImGui::TextUnformatted("Console unavailable.");
        ImGui::End();
        return;
    }

    ImGui::Text("Latest: %s", context.log->LatestMessage().c_str());
    ImGui::Separator();

    const std::vector<EditorLog::Entry>& entries = context.log->Entries();
    const bool followTail =
        ImGui::GetScrollY() >= ImGui::GetScrollMaxY() - 1.0f;
    ImGuiListClipper clipper;
    clipper.Begin(static_cast<int>(entries.size()));
    while (clipper.Step()) {
        for (int i = clipper.DisplayStart; i < clipper.DisplayEnd; ++i) {
            const EditorLog::Entry& entry =
                entries[static_cast<std::size_t>(i)];
            ImGui::TextColored(LogColor(entry.level), "[%s] %s",
                EditorLog::LevelName(entry.level), entry.message.c_str());
        }
    }

    if (followTail) {
        ImGui::SetScrollHereY(1.0f);
    }

    ImGui::End();
}

void DrawAudioEditor(EditorDockspace::Context& context, bool* open) {
    if (!ImGui::Begin(EditorPanels::Name(EditorPanels::Panel::AudioEditor), open)) {
        ImGui::End();
        return;
    }

    DrawAudioCueAuthoring(context);
    DrawAdaptiveMusicAuthoring(context);
    ImGui::Separator();

    if (ImGui::CollapsingHeader("Create Sound", ImGuiTreeNodeFlags_DefaultOpen)) {
        const char* generators[] = {"Sine Tone", "Square Tone", "Noise"};
        ImGui::Combo("Generator", &g_audioEditor.generator, generators, 3);
        if (g_audioEditor.generator != 2) {
            ImGui::DragFloat("Frequency", &g_audioEditor.generatorFrequency, 1.0f, 20.0f, 20000.0f, "%.0f Hz");
        }
        ImGui::DragFloat("Duration", &g_audioEditor.generatorDuration, 0.05f, 0.05f, 30.0f, "%.2f s");
        ImGui::SliderFloat("Amplitude", &g_audioEditor.generatorAmplitude, 0.0f, 1.0f, "%.2f");
        if (ImGui::Button("Generate New Clip")) {
            GenerateAudioEditorClip();
            if (context.assets) {
                const std::filesystem::path output = std::filesystem::path(context.assets->RootPath())
                    / "Audio" / "generated_sound.wav";
                std::snprintf(g_audioEditor.outputPath.data(), g_audioEditor.outputPath.size(), "%s", output.string().c_str());
            }
        }
        ImGui::SameLine();
        if (ImGui::Button("Load Selected Audio")) {
            if (context.assets) {
                const EditorAssets::Asset* selected = context.assets->SelectedAsset();
                const std::string path = context.assets->SelectedAssetFullPath();
                if (selected && IsEditableAudioPath(path)) LoadAudioIntoEditor(path, context.log);
                else if (context.log) context.log->Warning("Audio Editor: select an audio asset first");
            }
        }
        ImGui::Button("Drop audio clip here", ImVec2(-1.0f, 0.0f));
        if (ImGui::BeginDragDropTarget()) {
            if (const ImGuiPayload* payload = ImGui::AcceptDragDropPayload("3DGEDITOR_ASSET")) {
                const std::string path(static_cast<const char*>(payload->Data));
                if (IsEditableAudioPath(path)) LoadAudioIntoEditor(path, context.log);
            }
            ImGui::EndDragDropTarget();
        }
    }

    if (g_audioEditor.buffer.Empty()) {
        ImGui::Separator();
        ImGui::TextDisabled("Generate a sound or load an audio asset to begin editing.");
        ImGui::End();
        return;
    }

    ImGui::Separator();
    ImGui::Text("%s%s", g_audioEditor.sourcePath.empty() ? "Generated Clip" : g_audioEditor.sourcePath.c_str(),
        g_audioEditor.dirty ? " *" : "");
    ImGui::Text("%.2f seconds  |  %u Hz  |  %u channel%s  |  %d frames",
        g_audioEditor.buffer.DurationSeconds(), g_audioEditor.buffer.sampleRate,
        g_audioEditor.buffer.channels, g_audioEditor.buffer.channels == 1 ? "" : "s",
        static_cast<int>(g_audioEditor.buffer.FrameCount()));
    DrawAudioWaveform(g_audioEditor.buffer);

    const float duration = g_audioEditor.buffer.DurationSeconds();
    ImGui::SliderFloat("Waveform Zoom", &g_audioEditor.waveformZoom, 1.0f, 32.0f, "%.1fx",
                       ImGuiSliderFlags_Logarithmic);
    const float visibleDuration = duration / std::max(g_audioEditor.waveformZoom, 1.0f);
    ImGui::SliderFloat("Waveform Scroll", &g_audioEditor.waveformOffset, 0.0f,
        std::max(duration - visibleDuration, 0.001f), "%.2f s");
    g_audioEditor.selectionStart = std::clamp(g_audioEditor.selectionStart, 0.0f, duration);
    g_audioEditor.selectionEnd = std::clamp(g_audioEditor.selectionEnd, g_audioEditor.selectionStart, duration);
    ImGui::DragFloatRange2("Selection", &g_audioEditor.selectionStart, &g_audioEditor.selectionEnd,
        0.01f, 0.0f, duration, "Start %.2f s", "End %.2f s");
    const auto [selectionBegin, selectionEnd] = AudioSelectionFrames();
    const bool validSelection = selectionEnd > selectionBegin;

    if (ImGui::CollapsingHeader("Edit", ImGuiTreeNodeFlags_DefaultOpen)) {
        if (!validSelection) ImGui::BeginDisabled();
        if (ImGui::Button("Trim to Selection")) {
            PushAudioEditUndo();
            const std::size_t channels = g_audioEditor.buffer.channels;
            std::vector<float> trimmed(g_audioEditor.buffer.samples.begin() + selectionBegin * channels,
                g_audioEditor.buffer.samples.begin() + selectionEnd * channels);
            g_audioEditor.buffer.samples = std::move(trimmed);
            g_audioEditor.selectionStart = 0.0f;
            g_audioEditor.selectionEnd = g_audioEditor.buffer.DurationSeconds();
        }
        ImGui::SameLine();
        if (ImGui::Button("Reverse Selection")) {
            PushAudioEditUndo();
            const std::size_t channels = g_audioEditor.buffer.channels;
            for (std::size_t left = selectionBegin, right = selectionEnd - 1; left < right; ++left, --right) {
                for (std::size_t channel = 0; channel < channels; ++channel)
                    std::swap(g_audioEditor.buffer.samples[left * channels + channel],
                              g_audioEditor.buffer.samples[right * channels + channel]);
            }
        }
        if (ImGui::Button("Copy")) {
            const std::size_t channels = g_audioEditor.buffer.channels;
            g_audioEditor.clipboard = {};
            g_audioEditor.clipboard.channels = g_audioEditor.buffer.channels;
            g_audioEditor.clipboard.sampleRate = g_audioEditor.buffer.sampleRate;
            g_audioEditor.clipboard.samples.assign(
                g_audioEditor.buffer.samples.begin() + selectionBegin * channels,
                g_audioEditor.buffer.samples.begin() + selectionEnd * channels);
        }
        ImGui::SameLine();
        if (ImGui::Button("Cut")) {
            const std::size_t channels = g_audioEditor.buffer.channels;
            g_audioEditor.clipboard = {};
            g_audioEditor.clipboard.channels = g_audioEditor.buffer.channels;
            g_audioEditor.clipboard.sampleRate = g_audioEditor.buffer.sampleRate;
            g_audioEditor.clipboard.samples.assign(
                g_audioEditor.buffer.samples.begin() + selectionBegin * channels,
                g_audioEditor.buffer.samples.begin() + selectionEnd * channels);
            PushAudioEditUndo();
            g_audioEditor.buffer.samples.erase(
                g_audioEditor.buffer.samples.begin() + selectionBegin * channels,
                g_audioEditor.buffer.samples.begin() + selectionEnd * channels);
            g_audioEditor.selectionEnd = g_audioEditor.selectionStart;
        }
        ImGui::SameLine();
        if (ImGui::Button("Delete")) {
            const std::size_t channels = g_audioEditor.buffer.channels;
            PushAudioEditUndo();
            g_audioEditor.buffer.samples.erase(
                g_audioEditor.buffer.samples.begin() + selectionBegin * channels,
                g_audioEditor.buffer.samples.begin() + selectionEnd * channels);
            g_audioEditor.selectionEnd = g_audioEditor.selectionStart;
        }
        ImGui::SameLine();
        if (ImGui::Button("Silence")) {
            PushAudioEditUndo();
            std::fill(g_audioEditor.buffer.samples.begin()
                    + selectionBegin * g_audioEditor.buffer.channels,
                g_audioEditor.buffer.samples.begin()
                    + selectionEnd * g_audioEditor.buffer.channels, 0.0f);
        }
        if (!g_audioEditor.clipboard.Empty()
            && g_audioEditor.clipboard.channels == g_audioEditor.buffer.channels
            && g_audioEditor.clipboard.sampleRate == g_audioEditor.buffer.sampleRate) {
            if (ImGui::Button("Paste at Selection Start")) {
                PushAudioEditUndo();
                const auto at = g_audioEditor.buffer.samples.begin()
                    + selectionBegin * g_audioEditor.buffer.channels;
                g_audioEditor.buffer.samples.insert(at, g_audioEditor.clipboard.samples.begin(),
                    g_audioEditor.clipboard.samples.end());
            }
        }
        ImGui::DragFloat("Gain", &g_audioEditor.gainDb, 0.1f, -60.0f, 24.0f, "%.1f dB");
        if (ImGui::Button("Apply Gain")) {
            PushAudioEditUndo();
            const float gain = std::pow(10.0f, g_audioEditor.gainDb / 20.0f);
            for (std::size_t i = selectionBegin * g_audioEditor.buffer.channels;
                 i < selectionEnd * g_audioEditor.buffer.channels; ++i)
                g_audioEditor.buffer.samples[i] = std::clamp(g_audioEditor.buffer.samples[i] * gain, -1.0f, 1.0f);
        }
        ImGui::SameLine();
        if (ImGui::Button("Normalize")) {
            float peak = 0.0f;
            for (std::size_t i = selectionBegin * g_audioEditor.buffer.channels;
                 i < selectionEnd * g_audioEditor.buffer.channels; ++i)
                peak = std::max(peak, std::abs(g_audioEditor.buffer.samples[i]));
            if (peak > 0.000001f) {
                PushAudioEditUndo();
                const float gain = 0.98f / peak;
                for (std::size_t i = selectionBegin * g_audioEditor.buffer.channels;
                     i < selectionEnd * g_audioEditor.buffer.channels; ++i)
                    g_audioEditor.buffer.samples[i] *= gain;
            }
        }
        ImGui::DragFloat("Fade In", &g_audioEditor.fadeInSeconds, 0.01f, 0.0f, duration, "%.2f s");
        ImGui::DragFloat("Fade Out", &g_audioEditor.fadeOutSeconds, 0.01f, 0.0f, duration, "%.2f s");
        if (ImGui::Button("Apply Fades")) {
            PushAudioEditUndo();
            const std::size_t channels = g_audioEditor.buffer.channels;
            const std::size_t fadeInFrames = std::min(selectionEnd - selectionBegin,
                static_cast<std::size_t>(g_audioEditor.fadeInSeconds * g_audioEditor.buffer.sampleRate));
            const std::size_t fadeOutFrames = std::min(selectionEnd - selectionBegin,
                static_cast<std::size_t>(g_audioEditor.fadeOutSeconds * g_audioEditor.buffer.sampleRate));
            for (std::size_t frame = 0; frame < fadeInFrames; ++frame) {
                const float gain = fadeInFrames > 1 ? static_cast<float>(frame) / (fadeInFrames - 1) : 1.0f;
                for (std::size_t channel = 0; channel < channels; ++channel)
                    g_audioEditor.buffer.samples[(selectionBegin + frame) * channels + channel] *= gain;
            }
            for (std::size_t frame = 0; frame < fadeOutFrames; ++frame) {
                const float gain = fadeOutFrames > 1 ? 1.0f - static_cast<float>(frame) / (fadeOutFrames - 1) : 1.0f;
                const std::size_t target = selectionEnd - fadeOutFrames + frame;
                for (std::size_t channel = 0; channel < channels; ++channel)
                    g_audioEditor.buffer.samples[target * channels + channel] *= gain;
            }
        }
        if (!validSelection) ImGui::EndDisabled();
        ImGui::Separator();
        const bool hasUndo = !g_audioEditor.undoStack.empty();
        if (!hasUndo) ImGui::BeginDisabled();
        if (ImGui::Button("Undo")) {
            g_audioEditor.redoStack.push_back(g_audioEditor.buffer);
            g_audioEditor.buffer = std::move(g_audioEditor.undoStack.back());
            g_audioEditor.undoStack.pop_back();
            g_audioEditor.selectionStart = 0.0f;
            g_audioEditor.selectionEnd = g_audioEditor.buffer.DurationSeconds();
            g_audioEditor.dirty = true;
        }
        if (!hasUndo) ImGui::EndDisabled();
        ImGui::SameLine();
        const bool hasRedo = !g_audioEditor.redoStack.empty();
        if (!hasRedo) ImGui::BeginDisabled();
        if (ImGui::Button("Redo")) {
            g_audioEditor.undoStack.push_back(g_audioEditor.buffer);
            g_audioEditor.buffer = std::move(g_audioEditor.redoStack.back());
            g_audioEditor.redoStack.pop_back();
            g_audioEditor.selectionStart = 0.0f;
            g_audioEditor.selectionEnd = g_audioEditor.buffer.DurationSeconds();
            g_audioEditor.dirty = true;
        }
        if (!hasRedo) ImGui::EndDisabled();
        ImGui::SameLine();
        if (ImGui::Button("Reset Original") && !g_audioEditor.original.Empty()) {
            PushAudioEditUndo();
            g_audioEditor.buffer = g_audioEditor.original;
            g_audioEditor.selectionStart = 0.0f;
            g_audioEditor.selectionEnd = g_audioEditor.buffer.DurationSeconds();
        }
    }

    if (ImGui::CollapsingHeader("Preview and Export", ImGuiTreeNodeFlags_DefaultOpen)) {
        if (ImGui::Button("Preview Edited Clip")) {
            std::string error;
            const std::filesystem::path previewPath = std::filesystem::temp_directory_path()
                / "3dg_audio_editor_preview.wav";
            if (engine::WriteAudioWav(previewPath.string(), g_audioEditor.buffer, &error)) {
                context.previewAudioRequested = true;
                context.previewAudioPath = previewPath.string();
                context.previewAudioVolume = 1.0f;
                context.previewAudioPitch = 1.0f;
                context.previewAudioSpatial = false;
                context.previewAudioLoop = false;
            } else if (context.log) context.log->Error("Audio Editor preview failed: " + error);
        }
        ImGui::SameLine();
        if (ImGui::Button("Preview Selection")) {
            const auto [begin, end] = AudioSelectionFrames();
            engine::AudioBuffer selection;
            selection.sampleRate = g_audioEditor.buffer.sampleRate;
            selection.channels = g_audioEditor.buffer.channels;
            selection.samples.assign(g_audioEditor.buffer.samples.begin()
                    + begin * selection.channels,
                g_audioEditor.buffer.samples.begin() + end * selection.channels);
            std::string error;
            const std::filesystem::path previewPath = std::filesystem::temp_directory_path()
                / "3dg_audio_editor_selection.wav";
            if (engine::WriteAudioWav(previewPath.string(), selection, &error)) {
                context.previewAudioRequested = true;
                context.previewAudioPath = previewPath.string();
                context.previewAudioSpatial = false;
                context.previewAudioLoop = false;
            } else if (context.log) context.log->Error("Audio Editor preview failed: " + error);
        }
        ImGui::SameLine();
        if (ImGui::Button("Stop")) context.stopAudioPreviewRequested = true;
        ImGui::InputText("Export WAV", g_audioEditor.outputPath.data(), g_audioEditor.outputPath.size());
        if (ImGui::Button("Export to Project")) {
            std::string error;
            if (engine::WriteAudioWav(g_audioEditor.outputPath.data(), g_audioEditor.buffer, &error)) {
                g_audioEditor.dirty = false;
                if (context.assets) {
                    std::string refreshError;
                    context.assets->Refresh(context.assets->RootPath(), &refreshError);
                }
                if (context.log) context.log->Info("Audio Editor exported: " + std::string(g_audioEditor.outputPath.data()));
            } else if (context.log) context.log->Error("Audio Editor export failed: " + error);
        }
    }

    ImGui::End();
}

void DrawAudioMixer(EditorDockspace::Context& context, bool* open) {
    if (!ImGui::Begin(EditorPanels::Name(EditorPanels::Panel::AudioMixer), open)) {
        ImGui::End();
        return;
    }
    ImGui::TextUnformatted("Runtime Mixer");
    ImGui::TextDisabled("Bus levels affect previews and Play mode immediately.");
    ImGui::Text("Device: %s | %u Hz | %u channels",
        context.audioDeviceInfo.backend.c_str(), context.audioDeviceInfo.sampleRate,
        context.audioDeviceInfo.channels);
    int voiceLimit = static_cast<int>(context.audioMaxVoices);
    if (ImGui::SliderInt("Voice Budget", &voiceLimit, 8, 256)) {
        context.audioMaxVoices = static_cast<std::size_t>(voiceLimit);
        context.audioMaxVoicesChanged = true;
    }
    const auto& stats = context.audioDebugStats;
    ImGui::Text("Active %d / %d | Managed %d | Streamed %d | Assets %d",
        static_cast<int>(stats.activeVoices), voiceLimit,
        static_cast<int>(stats.managedSources), static_cast<int>(stats.streamedVoices),
        static_cast<int>(stats.pooledAssets));
    ImGui::Text("Voice stealing: %d | Rejected: %d",
        static_cast<int>(stats.stolenVoices), static_cast<int>(stats.rejectedVoices));
    ImGui::Separator();
    for (int i = static_cast<int>(engine::AudioBus::Master);
         i <= static_cast<int>(engine::AudioBus::Ambient); ++i) {
        const engine::AudioBus bus = static_cast<engine::AudioBus>(i);
        ImGui::PushID(i);
        ImGui::TextUnformatted(engine::AudioBusName(bus));
        ImGui::SameLine(90.0f);
        ImGui::SetNextItemWidth(std::max(ImGui::GetContentRegionAvail().x - 72.0f, 80.0f));
        ImGui::SliderFloat("##Volume", &context.audioBusVolumes[static_cast<std::size_t>(i)],
                           0.0f, 2.0f, "%.2f");
        ImGui::SameLine();
        ImGui::Checkbox("Mute", &context.audioBusMuted[static_cast<std::size_t>(i)]);
        ImGui::PopID();
    }
    ImGui::Separator();
    ImGui::TextUnformatted("Snapshots");
    ImGui::SetNextItemWidth(140.0f);
    if (ImGui::BeginCombo("Preset", engine::AudioSnapshotPresetName(context.activeAudioSnapshot))) {
        for (int i = static_cast<int>(engine::AudioSnapshotPreset::Default);
             i <= static_cast<int>(engine::AudioSnapshotPreset::Cinematic); ++i) {
            const auto preset = static_cast<engine::AudioSnapshotPreset>(i);
            const bool selected = preset == context.activeAudioSnapshot;
            if (ImGui::Selectable(engine::AudioSnapshotPresetName(preset), selected)) {
                context.requestedAudioSnapshot = preset;
                context.audioSnapshotRequested = true;
            }
            if (selected) ImGui::SetItemDefaultFocus();
        }
        ImGui::EndCombo();
    }
    ImGui::DragFloat("Transition", &context.audioSnapshotTransition,
                     0.05f, 0.0f, 10.0f, "%.2f s");
    ImGui::Checkbox("Dialogue ducks Music", &context.dialogueDucking);

    ImGui::Separator();
    ImGui::TextUnformatted("Bus Processing");
    static int selectedEffectsBus = static_cast<int>(engine::AudioBus::SFX);
    engine::AudioBus effectsBus = static_cast<engine::AudioBus>(selectedEffectsBus);
    if (ImGui::BeginCombo("Process Bus", engine::AudioBusName(effectsBus))) {
        for (int i = static_cast<int>(engine::AudioBus::Music);
             i <= static_cast<int>(engine::AudioBus::Ambient); ++i) {
            const bool selected = i == selectedEffectsBus;
            if (ImGui::Selectable(engine::AudioBusName(static_cast<engine::AudioBus>(i)), selected))
                selectedEffectsBus = i;
            if (selected) ImGui::SetItemDefaultFocus();
        }
        ImGui::EndCombo();
    }
    effectsBus = static_cast<engine::AudioBus>(selectedEffectsBus);
    engine::AudioBusEffects& fx = context.audioBusEffects[static_cast<std::size_t>(effectsBus)];
    ImGui::SliderFloat("Low Pass", &fx.lowPassHz, 20.0f, 20000.0f, "%.0f Hz",
                       ImGuiSliderFlags_Logarithmic);
    ImGui::SliderFloat("High Pass", &fx.highPassHz, 20.0f, 20000.0f, "%.0f Hz",
                       ImGuiSliderFlags_Logarithmic);
    ImGui::SliderFloat("Reverb Wet", &fx.reverbWet, 0.0f, 1.0f, "%.2f");
    ImGui::SliderFloat("Reverb Decay", &fx.reverbDecay, 0.0f, 0.95f, "%.2f");
    ImGui::SliderFloat("Comp Threshold", &fx.compressorThresholdDb, -60.0f, 0.0f, "%.1f dB");
    ImGui::SliderFloat("Comp Ratio", &fx.compressorRatio, 1.0f, 20.0f, "%.1f:1");
    if (ImGui::Button("Reset Processing")) fx = engine::AudioBusEffects{};

    ImGui::Separator();
    ImGui::TextUnformatted("Mixer Preset");
    static std::array<char, 320> mixerPath = [] {
        std::array<char, 320> value{};
        std::snprintf(value.data(), value.size(), "%s",
                      "Content/Audio/project_mixer.3dgmixer");
        return value;
    }();
    ImGui::InputText("Preset Path", mixerPath.data(), mixerPath.size());
    if (ImGui::Button("Save Mixer Preset")) {
        context.audioMixerPresetPath = mixerPath;
        context.saveAudioMixerPresetRequested = true;
    }
    ImGui::SameLine();
    if (ImGui::Button("Load Mixer Preset")) {
        context.audioMixerPresetPath = mixerPath;
        context.loadAudioMixerPresetRequested = true;
    }
    ImGui::End();
}

void DrawCreationPalette(EditorDockspace::Context& context) {
    if (g_creationPaletteOpenRequested) {
        g_creationSearch.fill('\0');
        ImGui::OpenPopup("Create Object");
        g_creationPaletteOpenRequested = false;
    }
    ImGui::SetNextWindowSize(ImVec2(470.0f, 430.0f), ImGuiCond_Appearing);
    if (!ImGui::BeginPopup("Create Object")) return;

    ImGui::TextUnformatted("Create Object");
    ImGui::TextDisabled("Search primitives, lights, physics, and gameplay objects");
    ImGui::SetNextItemWidth(-1.0f);
    if (ImGui::IsWindowAppearing()) ImGui::SetKeyboardFocusHere();
    ImGui::InputTextWithHint("##CreationSearch", "Search...", g_creationSearch.data(), g_creationSearch.size());
    ImGui::Separator();

    enum class Action {
        Empty, Cube, Plane, Sphere, Capsule, Cylinder, Cone, Pyramid, Torus, Staircase,
        DynamicCube, StaticFloor, TriggerVolume,
        NavMeshBoundsVolume,
        DirectionalLight, PointLight, SpotLight, AreaLight,
        PlayerStart, Door, Pickup, DamageZone, MovingPlatform
    };
    struct Entry { const char* label; const char* description; Action action; };
    constexpr Entry systems[] = {
        {"Empty Object", "Non-rendering host for scripts and world systems", Action::Empty}
    };
    constexpr Entry geometry[] = {
        {"Cube", "Box-shaped mesh", Action::Cube}, {"Plane", "Flat surface", Action::Plane},
        {"Sphere", "Round mesh", Action::Sphere}, {"Capsule", "Rounded vertical body", Action::Capsule},
        {"Cylinder", "Circular column", Action::Cylinder}, {"Cone", "Tapered circular mesh", Action::Cone},
        {"Pyramid", "Tapered square mesh", Action::Pyramid}, {"Torus", "Ring-shaped mesh", Action::Torus},
        {"Staircase", "Stepped mesh", Action::Staircase}
    };
    constexpr Entry physics[] = {
        {"Dynamic Cube", "Rigid body ready for simulation", Action::DynamicCube},
        {"Static Floor", "Static collision floor", Action::StaticFloor},
        {"Trigger Volume", "Non-solid event volume", Action::TriggerVolume}
    };
    constexpr Entry navigation[] = {
        {"Nav Mesh Bounds Volume", "Defines the level area used for navigation baking", Action::NavMeshBoundsVolume}
    };
    constexpr Entry lights[] = {
        {"Directional Light", "Scene-wide directional lighting", Action::DirectionalLight},
        {"Point Light", "Omnidirectional local light", Action::PointLight},
        {"Spot Light", "Focused cone light", Action::SpotLight},
        {"Area Light", "Rectangular soft light", Action::AreaLight}
    };
    constexpr Entry gameplay[] = {
        {"Player Start", "Player spawn position", Action::PlayerStart},
        {"Door", "Interactive door setup", Action::Door},
        {"Pickup", "Collectible gameplay object", Action::Pickup},
        {"Damage Zone", "Trigger that applies damage", Action::DamageZone},
        {"Moving Platform", "Animated gameplay platform", Action::MovingPlatform}
    };

    bool close = false;
    auto execute = [&](Action action) {
        switch (action) {
        case Action::Empty:
            context.addEmptyRequested = true;
            context.frameSelectedRequested = true;
            break;
        case Action::Cube: ResetPrimitiveCreator(EditorScene::Primitive::Cube); break;
        case Action::Plane: ResetPrimitiveCreator(EditorScene::Primitive::Plane); break;
        case Action::Sphere: ResetPrimitiveCreator(EditorScene::Primitive::Sphere); break;
        case Action::Capsule: ResetPrimitiveCreator(EditorScene::Primitive::Capsule); break;
        case Action::Cylinder: ResetPrimitiveCreator(EditorScene::Primitive::Cylinder); break;
        case Action::Cone: ResetPrimitiveCreator(EditorScene::Primitive::Cone); break;
        case Action::Pyramid: ResetPrimitiveCreator(EditorScene::Primitive::Pyramid); break;
        case Action::Torus: ResetPrimitiveCreator(EditorScene::Primitive::Torus); break;
        case Action::Staircase: ResetPrimitiveCreator(EditorScene::Primitive::Staircase); break;
        case Action::DynamicCube: context.addDynamicCubeRequested = true; break;
        case Action::StaticFloor: context.addStaticFloorRequested = true; break;
        case Action::TriggerVolume: context.addTriggerVolumeRequested = true; break;
        case Action::NavMeshBoundsVolume: context.addNavMeshBoundsVolumeRequested = true; break;
        case Action::DirectionalLight: context.addDirectionalLightRequested = true; break;
        case Action::PointLight: context.addPointLightRequested = true; break;
        case Action::SpotLight: context.addSpotLightRequested = true; break;
        case Action::AreaLight: context.addAreaLightRequested = true; break;
        case Action::PlayerStart: context.addPlayerStartRequested = true; break;
        case Action::Door: context.addDoorRequested = true; break;
        case Action::Pickup: context.addPickupRequested = true; break;
        case Action::DamageZone: context.addDamageZoneRequested = true; break;
        case Action::MovingPlatform: context.addMovingPlatformRequested = true; break;
        }
        if (action >= Action::DynamicCube) context.frameSelectedRequested = true;
        close = true;
    };
    auto drawCategory = [&](const char* category, const Entry* entries, std::size_t count) {
        bool any = false;
        for (std::size_t i = 0; i < count; ++i)
            any |= MatchesCreationSearch(entries[i].label, category);
        if (!any) return;
        ImGui::TextDisabled("%s", category);
        for (std::size_t i = 0; i < count; ++i) {
            const Entry& entry = entries[i];
            if (!MatchesCreationSearch(entry.label, category)) continue;
            ImGui::PushID(static_cast<int>(entry.action));
            if (ImGui::Selectable(entry.label, false, 0, ImVec2(0.0f, 36.0f))) execute(entry.action);
            ImGui::SameLine(190.0f);
            ImGui::TextDisabled("%s", entry.description);
            ImGui::PopID();
        }
        ImGui::Spacing();
    };

    ImGui::BeginChild("##CreationResults", ImVec2(0.0f, 0.0f), false);
    drawCategory("Systems", systems, std::size(systems));
    drawCategory("Geometry", geometry, std::size(geometry));
    drawCategory("Physics", physics, std::size(physics));
    drawCategory("Navigation", navigation, std::size(navigation));
    drawCategory("Lights", lights, std::size(lights));
    drawCategory("Gameplay", gameplay, std::size(gameplay));
    ImGui::EndChild();
    if (close) ImGui::CloseCurrentPopup();
    ImGui::EndPopup();
}

void DrawPrimitiveCreator(EditorDockspace::Context& context) {
    if (g_primitiveCreator.openRequested) {
        ImGui::OpenPopup("Create Primitive");
        g_primitiveCreator.openRequested = false;
    }

    ImGui::SetNextWindowSize(ImVec2(430.0f, 0.0f), ImGuiCond_Appearing);
    if (!ImGui::BeginPopupModal("Create Primitive", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
        return;
    }

    constexpr EditorScene::Primitive types[] = {
        EditorScene::Primitive::Cube,
        EditorScene::Primitive::Plane,
        EditorScene::Primitive::Sphere,
        EditorScene::Primitive::Capsule,
        EditorScene::Primitive::Cylinder,
        EditorScene::Primitive::Cone,
        EditorScene::Primitive::Pyramid,
        EditorScene::Primitive::Torus,
        EditorScene::Primitive::Staircase,
    };
    ImGui::SetNextItemWidth(-1.0f);
    ImGui::InputTextWithHint("##PrimitiveName", "Object name (automatic if empty)",
        g_primitiveCreator.name.data(), g_primitiveCreator.name.size());
    if (ImGui::BeginCombo("Type", PrimitiveName(g_primitiveCreator.type))) {
        for (EditorScene::Primitive type : types) {
            const bool selected = type == g_primitiveCreator.type;
            if (ImGui::Selectable(PrimitiveName(type), selected)) {
                ResetPrimitiveCreator(type);
                g_primitiveCreator.openRequested = false;
            }
            if (selected) {
                ImGui::SetItemDefaultFocus();
            }
        }
        ImGui::EndCombo();
    }

    constexpr float kMinSize = 0.01f;
    switch (g_primitiveCreator.type) {
    case EditorScene::Primitive::Cube:
        ImGui::DragFloat3("Dimensions", &g_primitiveCreator.dimensions.x, 0.05f, kMinSize, 1000.0f);
        break;
    case EditorScene::Primitive::Plane:
        ImGui::DragFloat("Width", &g_primitiveCreator.dimensions.x, 0.05f, kMinSize, 1000.0f);
        ImGui::DragFloat("Depth", &g_primitiveCreator.dimensions.z, 0.05f, kMinSize, 1000.0f);
        break;
    case EditorScene::Primitive::Sphere:
        ImGui::DragFloat("Radius", &g_primitiveCreator.radius, 0.02f, kMinSize, 500.0f);
        break;
    case EditorScene::Primitive::Capsule:
        ImGui::DragFloat("Radius", &g_primitiveCreator.radius, 0.02f, kMinSize, 500.0f);
        ImGui::DragFloat("Height", &g_primitiveCreator.height, 0.05f,
            std::max(g_primitiveCreator.radius * 2.0f, kMinSize), 1000.0f);
        g_primitiveCreator.height = std::max(g_primitiveCreator.height, g_primitiveCreator.radius * 2.0f);
        break;
    case EditorScene::Primitive::Cylinder:
    case EditorScene::Primitive::Cone:
        ImGui::DragFloat("Radius", &g_primitiveCreator.radius, 0.02f, kMinSize, 500.0f);
        ImGui::DragFloat("Height", &g_primitiveCreator.height, 0.05f, kMinSize, 1000.0f);
        break;
    case EditorScene::Primitive::Pyramid:
        ImGui::DragFloat3("Dimensions", &g_primitiveCreator.dimensions.x, 0.05f, kMinSize, 1000.0f);
        break;
    case EditorScene::Primitive::Staircase:
        ImGui::DragFloat3("Dimensions", &g_primitiveCreator.dimensions.x, 0.05f, kMinSize, 1000.0f);
        ImGui::DragInt("Collider Steps", &g_primitiveCreator.staircaseSteps, 0.25f, 1, 64);
        g_primitiveCreator.staircaseSteps = std::clamp(g_primitiveCreator.staircaseSteps, 1, 64);
        break;
    case EditorScene::Primitive::Torus:
        ImGui::DragFloat("Outer Radius", &g_primitiveCreator.radius, 0.02f, kMinSize, 500.0f);
        ImGui::DragFloat("Thickness", &g_primitiveCreator.height, 0.02f, kMinSize, 1000.0f);
        break;
    }

    ImGui::Separator();
    ImGui::TextUnformatted("Transform");
    ImGui::DragFloat3("Position", &g_primitiveCreator.position.x, 0.05f);
    ImGui::DragFloat3("Rotation", &g_primitiveCreator.rotationDegrees.x, 0.5f);
    if (ImGui::Button("At Origin")) g_primitiveCreator.position = glm::vec3(0.0f);
    ImGui::SameLine();
    if (ImGui::Button("Place on Ground")) g_primitiveCreator.position.y = PrimitiveGroundHeight();
    ImGui::SameLine();
    const bool hasSelection = context.scene && context.scene->SelectedObject();
    if (!hasSelection) ImGui::BeginDisabled();
    if (ImGui::Button("Beside Selected") && hasSelection) {
        if (const engine::ecs::Transform* selected = context.scene->SelectedTransform()) {
            g_primitiveCreator.position = selected->position;
            g_primitiveCreator.position.x += std::max(1.0f, selected->scale.x * 0.5f + 0.75f);
        }
    }
    if (!hasSelection) ImGui::EndDisabled();
    ImGui::Checkbox("Add collider", &g_primitiveCreator.addCollider);
    ImGui::SameLine();
    ImGui::Checkbox("Frame after creation", &g_primitiveCreator.frameAfterCreate);

    ImGui::Separator();
    const bool createRequested = ImGui::Button("Create", ImVec2(100.0f, 0.0f));
    ImGui::SameLine();
    const bool createAndContinue = ImGui::Button("Create & New", ImVec2(120.0f, 0.0f));
    if (createRequested || createAndContinue) {
        engine::ecs::Transform transform;
        transform.position = g_primitiveCreator.position;
        transform.rotation = glm::quat(glm::radians(g_primitiveCreator.rotationDegrees));

        engine::ecs::Collider collider;
        switch (g_primitiveCreator.type) {
        case EditorScene::Primitive::Cube:
            transform.scale = glm::max(g_primitiveCreator.dimensions, glm::vec3(kMinSize));
            collider = engine::ecs::Collider::MakeBox(transform.scale * 0.5f);
            break;
        case EditorScene::Primitive::Plane: {
            transform.scale = glm::vec3(std::max(g_primitiveCreator.dimensions.x, kMinSize), 1.0f,
                                        std::max(g_primitiveCreator.dimensions.z, kMinSize));
            const glm::vec3 normal = transform.rotation * glm::vec3(0.0f, 1.0f, 0.0f);
            collider = engine::ecs::Collider::MakePlane(normal, glm::dot(normal, transform.position));
            break;
        }
        case EditorScene::Primitive::Sphere: {
            const float diameter = std::max(g_primitiveCreator.radius * 2.0f, kMinSize);
            transform.scale = glm::vec3(diameter);
            collider = engine::ecs::Collider::MakeSphere(std::max(g_primitiveCreator.radius, kMinSize));
            break;
        }
        case EditorScene::Primitive::Capsule:
            transform.scale = glm::vec3(
                std::max(g_primitiveCreator.radius / 0.4f, kMinSize),
                std::max(g_primitiveCreator.height / 1.8f, kMinSize),
                std::max(g_primitiveCreator.radius / 0.4f, kMinSize));
            collider = engine::ecs::Collider::MakeCapsuleFromHeight(
                std::max(g_primitiveCreator.radius, kMinSize),
                std::max(g_primitiveCreator.height, g_primitiveCreator.radius * 2.0f));
            break;
        case EditorScene::Primitive::Cylinder: {
            const float diameter = std::max(g_primitiveCreator.radius * 2.0f, kMinSize);
            transform.scale = glm::vec3(diameter, std::max(g_primitiveCreator.height, kMinSize), diameter);
            collider = engine::ecs::Collider::MakeCylinder(
                std::max(g_primitiveCreator.radius, kMinSize),
                std::max(g_primitiveCreator.height, kMinSize));
            break;
        }
        case EditorScene::Primitive::Cone: {
            const float diameter = std::max(g_primitiveCreator.radius * 2.0f, kMinSize);
            transform.scale = glm::vec3(diameter, std::max(g_primitiveCreator.height, kMinSize), diameter);
            collider = engine::ecs::Collider::MakeCone(
                std::max(g_primitiveCreator.radius, kMinSize),
                std::max(g_primitiveCreator.height, kMinSize));
            break;
        }
        case EditorScene::Primitive::Pyramid:
            transform.scale = glm::max(g_primitiveCreator.dimensions, glm::vec3(kMinSize));
            collider = engine::ecs::Collider::MakePyramid(transform.scale * 0.5f);
            break;
        case EditorScene::Primitive::Staircase:
            transform.scale = glm::max(g_primitiveCreator.dimensions, glm::vec3(kMinSize));
            collider = engine::ecs::Collider::MakeStaircase(transform.scale * 0.5f,
                g_primitiveCreator.staircaseSteps);
            break;
        case EditorScene::Primitive::Torus: {
            const float outerRadius = std::max(g_primitiveCreator.radius, kMinSize);
            const float thickness = std::max(g_primitiveCreator.height, kMinSize);
            transform.scale = glm::vec3(outerRadius / 0.5f, thickness / 0.3f, outerRadius / 0.5f);
            const float minorRadius = thickness * 0.5f;
            collider = engine::ecs::Collider::MakeTorus(
                std::max(outerRadius - minorRadius, kMinSize), minorRadius);
            break;
        }
        }

        context.addConfiguredPrimitiveRequested = true;
        context.configuredPrimitive = g_primitiveCreator.type;
        context.configuredPrimitiveName = g_primitiveCreator.name.data();
        context.configuredPrimitiveTransform = transform;
        context.configuredPrimitiveColliderEnabled = g_primitiveCreator.addCollider;
        context.configuredPrimitiveCollider = collider;
        context.frameSelectedRequested = g_primitiveCreator.frameAfterCreate;
        if (createAndContinue) {
            g_primitiveCreator.name.fill('\0');
            g_primitiveCreator.position.x += std::max(1.0f, transform.scale.x + 0.25f);
        } else {
            ImGui::CloseCurrentPopup();
        }
    }
    ImGui::SameLine();
    if (ImGui::Button("Cancel", ImVec2(100.0f, 0.0f))) {
        ImGui::CloseCurrentPopup();
    }

    ImGui::EndPopup();
}

void DrawCameraSequences(EditorDockspace::Context& context) {
    EditorScene& scene = *context.scene;
    const auto& cameras = scene.CameraPresets();
    const auto& sequences = scene.CameraSequences();
    if (g_cameraSequenceSelection >= static_cast<int>(sequences.size())) {
        g_cameraSequenceSelection = sequences.empty()
            ? -1 : static_cast<int>(sequences.size()) - 1;
        g_cameraSequenceShotSelection = -1;
        g_cameraSequenceNameSelection = -1;
    }

    ImGui::Separator();
    ImGui::TextUnformatted("Cinematic Sequences");
    if (context.showCameraRails) {
        ImGui::Checkbox("Show Rails In Viewport", context.showCameraRails);
    }
    if (editor::icons::LabeledButton(editor::icons::Add, "New Sequence",
            ImVec2(132.0f, 0.0f))) {
        EditorScene::CameraSequence sequence;
        sequence.name = "Sequence_" + std::to_string(sequences.size() + 1);
        if (!cameras.empty()) {
            sequence.shots.push_back({cameras.front().name, 1.0f, 0.25f, 1});
        }
        g_cameraSequenceSelection = static_cast<int>(scene.AddCameraSequence(sequence));
        g_cameraSequenceShotSelection = sequence.shots.empty() ? -1 : 0;
        g_cameraSequenceNameSelection = -1;
    }

    const char* sequencePreview = g_cameraSequenceSelection >= 0
        && g_cameraSequenceSelection < static_cast<int>(scene.CameraSequences().size())
        ? scene.CameraSequences()[static_cast<std::size_t>(g_cameraSequenceSelection)].name.c_str()
        : "Choose sequence...";
    if (ImGui::BeginCombo("Sequence", sequencePreview)) {
        for (std::size_t i = 0; i < scene.CameraSequences().size(); ++i) {
            const bool selected = static_cast<int>(i) == g_cameraSequenceSelection;
            if (ImGui::Selectable(scene.CameraSequences()[i].name.c_str(), selected)) {
                g_cameraSequenceSelection = static_cast<int>(i);
                g_cameraSequenceShotSelection = -1;
                g_cameraSequenceNameSelection = -1;
            }
        }
        ImGui::EndCombo();
    }

    if (g_cameraSequenceSelection < 0
        || g_cameraSequenceSelection >= static_cast<int>(scene.CameraSequences().size())) {
        ImGui::TextDisabled("Create a sequence to arrange saved cameras into a cinematic.");
        return;
    }

    const std::size_t sequenceIndex = static_cast<std::size_t>(g_cameraSequenceSelection);
    EditorScene::CameraSequence sequence = scene.CameraSequences()[sequenceIndex];
    if (g_cameraSequenceNameSelection != g_cameraSequenceSelection) {
        g_cameraSequenceName.fill('\0');
        std::snprintf(g_cameraSequenceName.data(), g_cameraSequenceName.size(),
                      "%s", sequence.name.c_str());
        g_cameraSequenceNameSelection = g_cameraSequenceSelection;
    }

    bool sequenceChanged = false;
    if (ImGui::InputText("Sequence Name", g_cameraSequenceName.data(),
                         g_cameraSequenceName.size(), ImGuiInputTextFlags_EnterReturnsTrue)) {
        sequence.name = g_cameraSequenceName.data();
        sequenceChanged = true;
    }
    sequenceChanged |= ImGui::Checkbox("Loop Sequence", &sequence.loop);

    ImGui::BeginDisabled(sequence.shots.empty());
    if (editor::icons::LabeledButton(editor::icons::Play, "Play Sequence",
            ImVec2(132.0f, 0.0f))) {
        context.cameraSequence = sequence;
        context.cameraSequencePlayRequested = true;
    }
    ImGui::EndDisabled();
    ImGui::SameLine();
    ImGui::BeginDisabled(!context.cameraSequenceActive);
    if (editor::icons::LabeledButton(editor::icons::Stop, "Stop Sequence",
            ImVec2(132.0f, 0.0f))) {
        context.cameraSequenceStopRequested = true;
    }
    ImGui::EndDisabled();
    ImGui::SameLine();
    ImGui::BeginDisabled(!context.cameraSequenceActive);
    if (ImGui::Button(context.cameraSequencePaused ? "Resume" : "Pause")) {
        context.cameraSequencePauseToggleRequested = true;
    }
    ImGui::EndDisabled();
    ImGui::SameLine();
    if (context.cameraSequenceActive) {
        ImGui::TextColored(ImVec4(0.35f, 0.85f, 0.45f, 1.0f), "Playing");
        if (!context.cameraSequenceActiveName.empty()) {
            ImGui::Text("Active: %s", context.cameraSequenceActiveName.c_str());
        }
        if (context.cameraSequenceInputLocked) {
            ImGui::TextDisabled("Player input is locked for this cinematic.");
        }
        if (context.cameraSequenceSkippable) {
            ImGui::TextDisabled("Press Enter during Play mode to skip.");
        }
    }
    if (context.cameraSequenceActive && context.cameraSequenceDuration > 0.0f) {
        float timeline = context.cameraSequenceTime;
        if (ImGui::SliderFloat("Timeline", &timeline, 0.0f,
                               context.cameraSequenceDuration, "%.2f s")) {
            context.cameraSequenceSeekTime = timeline;
            context.cameraSequenceSeekRequested = true;
        }
        ImGui::Text("%.2f / %.2f seconds",
                    context.cameraSequenceTime, context.cameraSequenceDuration);
    }

    ImGui::BeginDisabled(cameras.empty());
    if (editor::icons::LabeledButton(editor::icons::Add, "Add Shot")) {
        sequence.shots.push_back({cameras.front().name, 1.0f, 0.25f, 1});
        g_cameraSequenceShotSelection = static_cast<int>(sequence.shots.size()) - 1;
        sequenceChanged = true;
    }
    ImGui::EndDisabled();
    if (cameras.empty()) {
        ImGui::SameLine();
        ImGui::TextDisabled("Save a camera before adding shots.");
    }

    if (ImGui::BeginChild("CameraSequenceShots", ImVec2(0.0f, 112.0f), true)) {
        for (std::size_t i = 0; i < sequence.shots.size(); ++i) {
            const EditorScene::CameraSequenceShot& shot = sequence.shots[i];
            const std::string label = std::to_string(i + 1) + ". "
                + (shot.cameraName.empty() ? "[Missing Camera]" : shot.cameraName)
                + "##sequence_shot_" + std::to_string(i);
            if (ImGui::Selectable(label.c_str(),
                                  g_cameraSequenceShotSelection == static_cast<int>(i))) {
                g_cameraSequenceShotSelection = static_cast<int>(i);
            }
        }
    }
    ImGui::EndChild();

    if (g_cameraSequenceShotSelection >= 0
        && g_cameraSequenceShotSelection < static_cast<int>(sequence.shots.size())) {
        const std::size_t shotIndex = static_cast<std::size_t>(g_cameraSequenceShotSelection);
        EditorScene::CameraSequenceShot& shot = sequence.shots[shotIndex];
        const char* cameraPreview = shot.cameraName.empty()
            ? "Choose camera..." : shot.cameraName.c_str();
        if (ImGui::BeginCombo("Shot Camera", cameraPreview)) {
            for (const EditorScene::CameraPreset& camera : cameras) {
                const bool selected = camera.name == shot.cameraName;
                if (ImGui::Selectable(camera.name.c_str(), selected)) {
                    shot.cameraName = camera.name;
                    sequenceChanged = true;
                }
            }
            ImGui::EndCombo();
        }
        sequenceChanged |= ImGui::DragFloat("Travel Time", &shot.travelDuration,
                                            0.05f, 0.0f, 120.0f, "%.2f s");
        sequenceChanged |= ImGui::DragFloat("Hold Time", &shot.holdDuration,
                                            0.05f, 0.0f, 120.0f, "%.2f s");
        const char* easingNames[] = {"Linear", "Smooth Step", "Ease In", "Ease Out"};
        sequenceChanged |= ImGui::Combo("Shot Easing", &shot.easing, easingNames, 4);
        const char* pathNames[] = {"Linear Rail", "Catmull-Rom Spline"};
        sequenceChanged |= ImGui::Combo("Rail Path", &shot.pathMode, pathNames, 2);
        std::array<char, 128> eventName{};
        std::snprintf(eventName.data(), eventName.size(), "%s", shot.eventName.c_str());
        if (ImGui::InputText("Shot Event", eventName.data(), eventName.size())) {
            shot.eventName = eventName.data();
            sequenceChanged = true;
        }
        ImGui::TextDisabled("The event fires when the camera reaches this shot.");

        ImGui::BeginDisabled(shotIndex == 0);
        if (ImGui::Button("Move Up")) {
            std::swap(sequence.shots[shotIndex], sequence.shots[shotIndex - 1]);
            --g_cameraSequenceShotSelection;
            sequenceChanged = true;
        }
        ImGui::EndDisabled();
        ImGui::SameLine();
        ImGui::BeginDisabled(shotIndex + 1 >= sequence.shots.size());
        if (ImGui::Button("Move Down")) {
            std::swap(sequence.shots[shotIndex], sequence.shots[shotIndex + 1]);
            ++g_cameraSequenceShotSelection;
            sequenceChanged = true;
        }
        ImGui::EndDisabled();
        ImGui::SameLine();
        if (editor::icons::LabeledButton(editor::icons::Delete, "Remove Shot")) {
            sequence.shots.erase(sequence.shots.begin()
                + static_cast<std::ptrdiff_t>(shotIndex));
            g_cameraSequenceShotSelection = std::min(
                g_cameraSequenceShotSelection,
                static_cast<int>(sequence.shots.size()) - 1);
            sequenceChanged = true;
        }
    }

    float authoredDuration = 0.0f;
    for (const EditorScene::CameraSequenceShot& shot : sequence.shots) {
        authoredDuration += std::max(shot.travelDuration, 0.0f)
            + std::max(shot.holdDuration, 0.0f);
    }
    ImGui::Separator();
    ImGui::Text("Timeline Tracks (%.2f s)", authoredDuration);
    {
        const ImVec2 start = ImGui::GetCursorScreenPos();
        const float width = std::max(ImGui::GetContentRegionAvail().x, 40.0f);
        ImGui::InvisibleButton("##CinematicTimelineRuler", ImVec2(width, 24.0f));
        ImDrawList* draw = ImGui::GetWindowDrawList();
        const float y = start.y + 12.0f;
        draw->AddLine(ImVec2(start.x, y), ImVec2(start.x + width, y),
                      IM_COL32(100, 120, 150, 255), 2.0f);
        for (const EditorScene::CinematicCue& cue : sequence.cues) {
            const float normalized = authoredDuration > 0.0f
                ? std::clamp(cue.time / authoredDuration, 0.0f, 1.0f) : 0.0f;
            const float x = start.x + normalized * width;
            const ImU32 color = cue.type == EditorScene::CinematicCueType::Audio
                ? IM_COL32(70, 190, 255, 255)
                : cue.type == EditorScene::CinematicCueType::Animation
                    ? IM_COL32(190, 100, 255, 255)
                    : IM_COL32(255, 180, 55, 255);
            draw->AddLine(ImVec2(x, start.y + 3.0f), ImVec2(x, start.y + 21.0f),
                          color, 3.0f);
        }
    }
    if (ImGui::Button("Add Event")) {
        sequence.cues.push_back({
            EditorScene::CinematicCueType::Event, 0.0f, "Event"});
        g_cameraSequenceCueSelection = static_cast<int>(sequence.cues.size()) - 1;
        sequenceChanged = true;
    }
    ImGui::SameLine();
    if (ImGui::Button("Add Audio")) {
        EditorScene::CinematicCue cue;
        cue.type = EditorScene::CinematicCueType::Audio;
        sequence.cues.push_back(cue);
        g_cameraSequenceCueSelection = static_cast<int>(sequence.cues.size()) - 1;
        sequenceChanged = true;
    }
    ImGui::SameLine();
    if (ImGui::Button("Add Animation")) {
        EditorScene::CinematicCue cue;
        cue.type = EditorScene::CinematicCueType::Animation;
        sequence.cues.push_back(cue);
        g_cameraSequenceCueSelection = static_cast<int>(sequence.cues.size()) - 1;
        sequenceChanged = true;
    }

    if (ImGui::BeginChild("CinematicTimelineCues", ImVec2(0.0f, 105.0f), true)) {
        for (std::size_t i = 0; i < sequence.cues.size(); ++i) {
            const EditorScene::CinematicCue& cue = sequence.cues[i];
            const char* type = cue.type == EditorScene::CinematicCueType::Audio
                ? "Audio" : cue.type == EditorScene::CinematicCueType::Animation
                    ? "Animation" : "Event";
            const std::string label = std::to_string(cue.time) + "s  [" + type + "] "
                + (cue.name.empty() ? cue.assetPath : cue.name)
                + "##cinematic_cue_" + std::to_string(i);
            if (ImGui::Selectable(label.c_str(),
                    g_cameraSequenceCueSelection == static_cast<int>(i))) {
                g_cameraSequenceCueSelection = static_cast<int>(i);
            }
        }
    }
    ImGui::EndChild();

    if (g_cameraSequenceCueSelection >= 0
        && g_cameraSequenceCueSelection < static_cast<int>(sequence.cues.size())) {
        const std::size_t cueIndex = static_cast<std::size_t>(g_cameraSequenceCueSelection);
        EditorScene::CinematicCue& cue = sequence.cues[cueIndex];
        int cueType = static_cast<int>(cue.type);
        const char* cueTypes[] = {"Event", "Audio", "Animation"};
        if (ImGui::Combo("Track Type", &cueType, cueTypes, 3)) {
            cue.type = static_cast<EditorScene::CinematicCueType>(cueType);
            sequenceChanged = true;
        }
        sequenceChanged |= ImGui::DragFloat("Cue Time", &cue.time, 0.02f,
                                            0.0f, std::max(authoredDuration, 0.0f), "%.2f s");
        std::array<char, 256> text{};
        if (cue.type == EditorScene::CinematicCueType::Event) {
            std::snprintf(text.data(), text.size(), "%s", cue.name.c_str());
            if (ImGui::InputText("Event Name", text.data(), text.size())) {
                cue.name = text.data();
                sequenceChanged = true;
            }
        } else if (cue.type == EditorScene::CinematicCueType::Audio) {
            std::snprintf(text.data(), text.size(), "%s", cue.assetPath.c_str());
            if (ImGui::InputText("Audio Asset", text.data(), text.size())) {
                cue.assetPath = text.data();
                sequenceChanged = true;
            }
            ImGui::SameLine();
            if (ImGui::Button("Paste Audio")) {
                if (const char* clipboard = ImGui::GetClipboardText()) {
                    cue.assetPath = clipboard;
                    sequenceChanged = true;
                }
            }
            sequenceChanged |= ImGui::SliderFloat("Audio Volume", &cue.volume, 0.0f, 2.0f);
        } else {
            const char* targetPreview = cue.targetObject.empty()
                ? "Choose object..." : cue.targetObject.c_str();
            if (ImGui::BeginCombo("Animation Target", targetPreview)) {
                for (const EditorScene::Object& object : scene.Objects()) {
                    const bool selectedTarget = object.name == cue.targetObject;
                    if (ImGui::Selectable(object.name.c_str(), selectedTarget)) {
                        cue.targetObject = object.name;
                        sequenceChanged = true;
                    }
                }
                ImGui::EndCombo();
            }
            std::snprintf(text.data(), text.size(), "%s", cue.animationClip.c_str());
            if (ImGui::InputText("Animation Clip", text.data(), text.size())) {
                cue.animationClip = text.data();
                sequenceChanged = true;
            }
            ImGui::TextDisabled("Animation cues run against animated objects in Play mode.");
        }
        if (ImGui::Button("Remove Cue")) {
            sequence.cues.erase(sequence.cues.begin()
                + static_cast<std::ptrdiff_t>(cueIndex));
            g_cameraSequenceCueSelection = std::min(
                g_cameraSequenceCueSelection,
                static_cast<int>(sequence.cues.size()) - 1);
            sequenceChanged = true;
        }
    }

    if (sequenceChanged) scene.SetCameraSequence(sequenceIndex, sequence);

    if (editor::icons::LabeledButton(editor::icons::Delete, "Delete Sequence")) {
        scene.RemoveCameraSequence(sequenceIndex);
        g_cameraSequenceSelection = std::min(
            g_cameraSequenceSelection,
            static_cast<int>(scene.CameraSequences().size()) - 1);
        g_cameraSequenceShotSelection = -1;
        g_cameraSequenceNameSelection = -1;
    }
}

void DrawCameraManager(EditorDockspace::Context& context, bool* open) {
    if (!context.scene) return;
    if (!ImGui::Begin(EditorPanels::Name(EditorPanels::Panel::CameraManager), open)) {
        ImGui::End();
        return;
    }

    EditorScene& scene = *context.scene;
    const std::vector<EditorScene::CameraPreset>& cameras = scene.CameraPresets();
    if (g_cameraPresetSelection >= static_cast<int>(cameras.size())) {
        g_cameraPresetSelection = cameras.empty() ? -1 : static_cast<int>(cameras.size()) - 1;
    }

    ImGui::TextDisabled("Saved with the current scene.");
    if (!context.camera) ImGui::TextDisabled("Viewport camera is unavailable.");

    if (editor::icons::LabeledButton(editor::icons::Image, "Capture Current",
            ImVec2(152.0f, 0.0f)) && context.camera) {
        EditorScene::CameraPreset preset;
        preset.name = "Camera_" + std::to_string(cameras.size() + 1);
        preset.position = context.camera->Position();
        preset.target = preset.position + context.camera->Front() * 10.0f;
        preset.fov = context.camera->fov;
        preset.nearPlane = context.camera->nearPlane;
        preset.farPlane = context.camera->farPlane;
        preset.primary = cameras.empty();
        g_cameraPresetSelection = static_cast<int>(scene.AddCameraPreset(preset));
        g_cameraPresetNameSelection = -1;
    }
    ImGui::SameLine();
    if (editor::icons::LabeledButton(editor::icons::Add, "New Default",
            ImVec2(132.0f, 0.0f))) {
        EditorScene::CameraPreset preset;
        preset.name = "Camera_" + std::to_string(cameras.size() + 1);
        preset.primary = cameras.empty();
        g_cameraPresetSelection = static_cast<int>(scene.AddCameraPreset(preset));
        g_cameraPresetNameSelection = -1;
    }

    ImGui::Separator();
    if (ImGui::BeginChild("CameraPresetList", ImVec2(0.0f, 150.0f), true)) {
        for (std::size_t i = 0; i < cameras.size(); ++i) {
            const EditorScene::CameraPreset& preset = cameras[i];
            std::string label;
            if (preset.primary) label += "[Primary] ";
            if (preset.useInPlay) label += "[Play] ";
            label += preset.name;
            label += "##camera_" + std::to_string(i);
            if (ImGui::Selectable(label.c_str(), g_cameraPresetSelection == static_cast<int>(i))) {
                g_cameraPresetSelection = static_cast<int>(i);
                g_cameraPresetNameSelection = -1;
            }
        }
        if (cameras.empty()) {
            ImGui::TextDisabled("No saved cameras. Capture the current viewport.");
        }
    }
    ImGui::EndChild();

    ImGui::Separator();
    ImGui::TextUnformatted("Camera Shake Preview");
    static engine::CameraShakeSettings shake;
    ImGui::DragFloat("Shake Duration", &shake.duration, 0.01f, 0.01f, 10.0f, "%.2f s");
    ImGui::DragFloat("Shake Frequency", &shake.frequency, 0.25f, 0.0f, 120.0f, "%.1f Hz");
    ImGui::DragFloat3("Position Amplitude", &shake.translationAmplitude.x,
                      0.005f, 0.0f, 10.0f, "%.3f");
    ImGui::DragFloat2("Rotation Amplitude", &shake.rotationAmplitudeDegrees.x,
                      0.05f, 0.0f, 45.0f, "%.2f deg");
    ImGui::DragFloat("FOV Amplitude", &shake.fovAmplitude,
                     0.05f, 0.0f, 30.0f, "%.2f deg");
    if (editor::icons::LabeledButton(editor::icons::Play, "Preview Shake",
            ImVec2(132.0f, 0.0f))) {
        context.cameraShakeSettings = shake;
        context.cameraShakeRequested = true;
    }
    ImGui::SameLine();
    ImGui::BeginDisabled(!context.cameraShakeActive);
    if (editor::icons::LabeledButton(editor::icons::Stop, "Stop Shake",
            ImVec2(116.0f, 0.0f))) {
        context.cameraShakeStopRequested = true;
    }
    ImGui::EndDisabled();
    if (context.cameraShakeActive) {
        ImGui::SameLine();
        ImGui::TextColored(ImVec4(0.95f, 0.72f, 0.25f, 1.0f), "Active");
    }

    DrawCameraSequences(context);

    if (g_cameraPresetSelection < 0
        || g_cameraPresetSelection >= static_cast<int>(scene.CameraPresets().size())) {
        ImGui::End();
        return;
    }

    const std::size_t selected = static_cast<std::size_t>(g_cameraPresetSelection);
    EditorScene::CameraPreset preset = scene.CameraPresets()[selected];
    if (g_cameraPresetNameSelection != g_cameraPresetSelection) {
        g_cameraPresetName.fill('\0');
        std::snprintf(g_cameraPresetName.data(), g_cameraPresetName.size(), "%s", preset.name.c_str());
        g_cameraPresetNameSelection = g_cameraPresetSelection;
    }

    ImGui::BeginDisabled(context.playMode);
    if (ImGui::Button("Pilot", ImVec2(82.0f, 0.0f)) && context.camera) {
        context.cameraBlendRequested = true;
        context.cameraBlendPreset = preset;
    }
    ImGui::EndDisabled();
    ImGui::SameLine();
    if (ImGui::Button("Update From View", ImVec2(132.0f, 0.0f)) && context.camera) {
        preset.position = context.camera->Position();
        preset.target = preset.position + context.camera->Front() * 10.0f;
        preset.fov = context.camera->fov;
        preset.nearPlane = context.camera->nearPlane;
        preset.farPlane = context.camera->farPlane;
        scene.SetCameraPreset(selected, preset);
    }
    ImGui::SameLine();
    if (editor::icons::LabeledButton(editor::icons::Copy, "Duplicate",
            ImVec2(108.0f, 0.0f))) {
        const std::size_t duplicate = scene.DuplicateCameraPreset(selected);
        if (duplicate != static_cast<std::size_t>(-1)) {
            g_cameraPresetSelection = static_cast<int>(duplicate);
            g_cameraPresetNameSelection = -1;
        }
    }

    if (ImGui::InputText("Name", g_cameraPresetName.data(), g_cameraPresetName.size(),
                         ImGuiInputTextFlags_EnterReturnsTrue)) {
        preset.name = g_cameraPresetName.data();
        scene.SetCameraPreset(selected, preset);
    }

    bool changed = false;
    changed |= ImGui::DragFloat3("Position", &preset.position.x, 0.05f);
    changed |= ImGui::DragFloat3("Target", &preset.target.x, 0.05f);
    changed |= ImGui::SliderFloat("Field of View", &preset.fov, 10.0f, 120.0f, "%.1f deg");
    changed |= ImGui::DragFloat("Near Plane", &preset.nearPlane, 0.01f, 0.001f, 100.0f, "%.3f");
    changed |= ImGui::DragFloat("Far Plane", &preset.farPlane, 1.0f, 0.1f, 100000.0f, "%.1f");
    changed |= ImGui::DragFloat("Blend Duration", &preset.blendDuration,
                                0.05f, 0.0f, 30.0f, "%.2f s");
    const char* easingNames[] = {"Linear", "Smooth Step", "Ease In", "Ease Out"};
    changed |= ImGui::Combo("Blend Easing", &preset.blendEasing,
                            easingNames, 4);
    changed |= ImGui::Checkbox("Use as fixed camera in Play", &preset.useInPlay);
    if (changed) scene.SetCameraPreset(selected, preset);

    if (preset.primary) {
        ImGui::TextColored(ImVec4(0.35f, 0.85f, 0.45f, 1.0f), "Primary camera");
    } else if (ImGui::Button("Set as Primary")) {
        scene.SetPrimaryCameraPreset(selected);
    }
    ImGui::SameLine();
    ImGui::BeginDisabled(context.playMode);
    if (ImGui::Button("Delete")) {
        scene.RemoveCameraPreset(selected);
        g_cameraPresetSelection = std::min(
            g_cameraPresetSelection,
            static_cast<int>(scene.CameraPresets().size()) - 1);
        g_cameraPresetNameSelection = -1;
    }
    ImGui::EndDisabled();

    ImGui::Separator();
    ImGui::TextWrapped("The primary camera is used in Play only when its Play option is enabled. "
                       "Otherwise the Player Controller camera remains active.");
    ImGui::End();
}

void DrawGizmoToolbar(EditorDockspace::Context& context, bool* open) {
    if (!context.gizmo) {
        return;
    }

    ImGui::SetNextWindowBgAlpha(0.85f);
    if (!ImGui::Begin(EditorPanels::Name(EditorPanels::Panel::Gizmo), open,
        ImGuiWindowFlags_AlwaysAutoResize
        | ImGuiWindowFlags_NoCollapse)) {
        ImGui::End();
        return;
    }

    const EditorGizmo::Mode mode = context.gizmo->CurrentMode();
    if (ImGui::Selectable("W Move", mode == EditorGizmo::Mode::Translate, 0, ImVec2(82.0f, 0.0f))) {
        context.gizmo->SetMode(EditorGizmo::Mode::Translate);
    }
    ImGui::SameLine();
    if (ImGui::Selectable("E Rotate", mode == EditorGizmo::Mode::Rotate, 0, ImVec2(82.0f, 0.0f))) {
        context.gizmo->SetMode(EditorGizmo::Mode::Rotate);
    }
    ImGui::SameLine();
    if (ImGui::Selectable("R Scale", mode == EditorGizmo::Mode::Scale, 0, ImVec2(82.0f, 0.0f))) {
        context.gizmo->SetMode(EditorGizmo::Mode::Scale);
    }

    ImGui::Separator();
    ImGui::TextUnformatted("Orientation");
    const EditorGizmo::Space space = context.gizmo->CurrentSpace();
    const ImGuiSelectableFlags worldFlags = mode == EditorGizmo::Mode::Scale
        ? ImGuiSelectableFlags_Disabled : 0;
    if (ImGui::Selectable("World", space == EditorGizmo::Space::World, worldFlags, ImVec2(104.0f, 0.0f))) {
        context.gizmo->SetSpace(EditorGizmo::Space::World);
    }
    ImGui::SameLine();
    if (ImGui::Selectable("Local", space == EditorGizmo::Space::Local, 0, ImVec2(104.0f, 0.0f))) {
        context.gizmo->SetSpace(EditorGizmo::Space::Local);
    }

    ImGui::Separator();
    ImGui::TextUnformatted("Axis");
    const EditorGizmo::Axis axis = context.gizmo->CurrentAxis();
    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.72f, 0.16f, 0.18f, 1.0f));
    if (ImGui::Button(axis == EditorGizmo::Axis::X ? "X -> *" : "X ->", ImVec2(68.0f, 0.0f))) {
        context.gizmo->SetAxis(EditorGizmo::Axis::X);
    }
    ImGui::PopStyleColor();
    ImGui::SameLine();
    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.16f, 0.55f, 0.22f, 1.0f));
    if (ImGui::Button(axis == EditorGizmo::Axis::Y ? "Y ^ *" : "Y ^", ImVec2(68.0f, 0.0f))) {
        context.gizmo->SetAxis(EditorGizmo::Axis::Y);
    }
    ImGui::PopStyleColor();
    ImGui::SameLine();
    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.16f, 0.34f, 0.76f, 1.0f));
    if (ImGui::Button(axis == EditorGizmo::Axis::Z ? "Z / *" : "Z /", ImVec2(68.0f, 0.0f))) {
        context.gizmo->SetAxis(EditorGizmo::Axis::Z);
    }
    ImGui::PopStyleColor();

    if (mode == EditorGizmo::Mode::Scale) {
        ImGui::SameLine();
        if (ImGui::Button(axis == EditorGizmo::Axis::All ? "G All *" : "G All", ImVec2(68.0f, 0.0f))) {
            context.gizmo->SetAxis(EditorGizmo::Axis::All);
        }
    }

    ImGui::Separator();
    bool snapping = context.gizmo->SnappingEnabled();
    if (ImGui::Checkbox("Snap", &snapping)) context.gizmo->SetSnappingEnabled(snapping);
    float snapValue = mode == EditorGizmo::Mode::Translate ? context.gizmo->TranslationSnap()
        : mode == EditorGizmo::Mode::Rotate ? context.gizmo->RotationSnap()
        : context.gizmo->ScaleSnap();
    ImGui::SameLine();
    ImGui::SetNextItemWidth(105.0f);
    const char* snapLabel = mode == EditorGizmo::Mode::Translate ? "Units##GizmoSnap"
        : mode == EditorGizmo::Mode::Rotate ? "Degrees##GizmoSnap"
        : "Step##GizmoSnap";
    if (ImGui::DragFloat(snapLabel, &snapValue, mode == EditorGizmo::Mode::Rotate ? 0.5f : 0.01f,
            mode == EditorGizmo::Mode::Rotate ? 0.1f : 0.001f, 1000.0f)) {
        if (mode == EditorGizmo::Mode::Translate) context.gizmo->SetTranslationSnap(snapValue);
        else if (mode == EditorGizmo::Mode::Rotate) context.gizmo->SetRotationSnap(snapValue);
        else context.gizmo->SetScaleSnap(snapValue);
    }

    float visualScale = context.gizmo->VisualScale();
    ImGui::SetNextItemWidth(210.0f);
    if (ImGui::SliderFloat("Size", &visualScale, 0.5f, 2.5f, "%.2fx")) {
        context.gizmo->SetVisualScale(visualScale);
    }

    ImGui::End();
}

} // namespace

bool EditorDockspace::Draw(Context& context) {
    if (!context.panels) {
        return false;
    }

    const ImGuiViewport* viewport = ImGui::GetMainViewport();
    ImGui::SetNextWindowPos(viewport->WorkPos);
    ImGui::SetNextWindowSize(viewport->WorkSize);
    ImGui::SetNextWindowViewport(viewport->ID);

    ImGuiWindowFlags flags = ImGuiWindowFlags_MenuBar
        | ImGuiWindowFlags_NoDocking
        | ImGuiWindowFlags_NoTitleBar
        | ImGuiWindowFlags_NoCollapse
        | ImGuiWindowFlags_NoResize
        | ImGuiWindowFlags_NoMove
        | ImGuiWindowFlags_NoBringToFrontOnFocus
        | ImGuiWindowFlags_NoNavFocus;
    // The scene now lives in the dockable Viewport panel, so the dockspace host stays
    // opaque — the old see-through background scene is gone.

    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 0.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);
    ImGui::Begin("3DGEditorDockspace", nullptr, flags);
    ImGui::PopStyleVar(2);

    const ImGuiIO& io = ImGui::GetIO();
    if (io.KeyCtrl && io.KeyShift && !io.WantTextInput && ImGui::IsKeyPressed(ImGuiKey_A, false)) {
        g_creationPaletteOpenRequested = true;
    }

    const ImGuiID dockspaceId = ImGui::GetID("3DGEditorDockspaceRoot");

    // First run (no saved layout in imgui.ini): build a sensible default so the Viewport
    // lands centered with the tool panels docked around it, instead of opening floating.
    // A saved layout already has a node, so existing user arrangements are preserved.
    static bool s_defaultLayoutBuilt = false;
    if (!s_defaultLayoutBuilt && ImGui::DockBuilderGetNode(dockspaceId) == nullptr) {
        s_defaultLayoutBuilt = true;
        ImGui::DockBuilderRemoveNode(dockspaceId);
        ImGui::DockBuilderAddNode(dockspaceId, ImGuiDockNodeFlags_DockSpace);
        ImGui::DockBuilderSetNodeSize(dockspaceId, viewport->WorkSize);

        ImGuiID center = dockspaceId;
        const ImGuiID left   = ImGui::DockBuilderSplitNode(center, ImGuiDir_Left,  0.18f, nullptr, &center);
        const ImGuiID right  = ImGui::DockBuilderSplitNode(center, ImGuiDir_Right, 0.22f, nullptr, &center);
        const ImGuiID bottom = ImGui::DockBuilderSplitNode(center, ImGuiDir_Down,  0.26f, nullptr, &center);

        using P = EditorPanels::Panel;
        ImGui::DockBuilderDockWindow(EditorPanels::Name(P::Viewport),      center);
        ImGui::DockBuilderDockWindow(EditorPanels::Name(P::Hierarchy),     left);
        ImGui::DockBuilderDockWindow(EditorPanels::Name(P::CameraManager), left);
        ImGui::DockBuilderDockWindow(EditorPanels::Name(P::Inspector),     right);
        ImGui::DockBuilderDockWindow(EditorPanels::Name(P::Gizmo),         right);
        ImGui::DockBuilderDockWindow(EditorPanels::Name(P::Assets),        bottom);
        ImGui::DockBuilderDockWindow(EditorPanels::Name(P::Console),       bottom);
        ImGui::DockBuilderFinish(dockspaceId);
    }

    ImGui::DockSpace(dockspaceId, ImVec2(0.0f, 0.0f), ImGuiDockNodeFlags_PassthruCentralNode);
    if (context.dragDrop && ImGui::BeginDragDropTarget()) {
        if (ImGui::AcceptDragDropPayload("3DGEDITOR_ASSET")) {
            context.viewportDropRequested = true;
        }
        ImGui::EndDragDropTarget();
    }

    if (ImGui::BeginMenuBar()) {
        if (ImGui::BeginMenu(editor::icons::Label(editor::icons::Folder, "Project").c_str())) {
            if (context.project) {
                ImGui::Text("Name: %s", context.project->ProjectName().c_str());
                ImGui::Text("Scene: %s", context.project->ScenePath().c_str());
            }
            ImGui::Text("Mode: %s", context.modeName);
            ImGui::Text("FPS: %.0f", context.fps);
            ImGui::Text("Particles: %zu rendered | %d draws | %d culled | %.3f ms CPU | %.3f ms GPU",
                context.particleRenderedCount, context.particleDrawCalls,
                context.particleCulledEmitters, context.particleCpuMilliseconds,
                context.particleGpuMilliseconds);
            ImGui::Text("Scene dirty: %s", context.sceneDirty ? "yes" : "no");
            if (context.gizmo) {
                ImGui::Text("Gizmo: %s %s (%s)", context.gizmo->ModeName(), context.gizmo->AxisName(), context.gizmo->SpaceName());
            }
            ImGui::Separator();
            if (ImGui::BeginMenu(editor::icons::Label(editor::icons::Folder, "Manage Project").c_str())) {
                if (context.project) {
                    ImGui::TextDisabled("Current: %s", context.project->ProjectName().c_str());
                    ImGui::Separator();
                }
                ImGui::TextDisabled("Create a new empty project");
                if (context.projectNameBuffer && context.projectNameBufferSize > 0) {
                    ImGui::SetNextItemWidth(280.0f);
                    ImGui::InputText("Name", context.projectNameBuffer, context.projectNameBufferSize);
                }
                if (context.projectLocationBuffer && context.projectLocationBuffer[0] != '\0') {
                    ImGui::TextWrapped("Location: %s", context.projectLocationBuffer);
                } else {
                    ImGui::TextDisabled("Location: (none chosen)");
                }
                if (editor::icons::MenuItem(editor::icons::Folder, "Choose Location...")) {
                    context.browseProjectLocationRequested = true;
                }
                if (editor::icons::MenuItem(editor::icons::Add, "Create Project")) {
                    context.newProjectRequested = true;
                }
                ImGui::Separator();
                if (editor::icons::MenuItem(editor::icons::Open, "Open Project...")) {
                    context.browseOpenProjectRequested = true;
                }
                ImGui::EndMenu();
            }
            ImGui::Separator();
            if (editor::icons::MenuItem(editor::icons::Document, "New Scene")) {
                context.newSceneRequested = true;
            }
            if (editor::icons::MenuItem(editor::icons::Play, "Play", "P", false, !context.playMode)) {
                context.enterPlayModeRequested = true;
            }
            if (editor::icons::MenuItem(editor::icons::Stop, "Stop", "P", false, context.playMode)) {
                context.exitPlayModeRequested = true;
            }
            ImGui::Separator();
            if (editor::icons::MenuItem(editor::icons::Save, "Save")) {
                context.saveSceneRequested = true;
            }
            if (context.scenePathBuffer && context.scenePathBufferSize > 0) {
                ImGui::SetNextItemWidth(280.0f);
                ImGui::InputText("Scene Path", context.scenePathBuffer, context.scenePathBufferSize);
            }
            if (editor::icons::MenuItem(editor::icons::Save, "Save As")) {
                context.saveAsSceneRequested = true;
            }
            if (editor::icons::MenuItem(editor::icons::Open, "Load")) {
                context.loadSceneRequested = true;
            }
            if (editor::icons::MenuItem(editor::icons::Download, "Export Runtime")) {
                context.exportRuntimeRequested = true;
            }
            if (editor::icons::MenuItem(editor::icons::Archive, "Cook Project")) {
                context.cookProjectRequested = true;
            }
            if (editor::icons::MenuItem(editor::icons::Archive, "Package Project...")) {
                context.packageSettingsRequested = true;
            }
            if (editor::icons::MenuItem(editor::icons::Settings, "Validate Runtime")) {
                context.validateRuntimeRequested = true;
            }
            if (context.project && !context.project->RecentScenes().empty()) {
                ImGui::Separator();
                if (ImGui::BeginMenu("Recent Scenes")) {
                    const std::vector<std::string>& recentScenes = context.project->RecentScenes();
                    for (int i = 0; i < static_cast<int>(recentScenes.size()); ++i) {
                        if (ImGui::MenuItem(recentScenes[static_cast<std::size_t>(i)].c_str())) {
                            context.recentSceneRequested = i;
                        }
                    }
                    ImGui::EndMenu();
                }
            }
            ImGui::EndMenu();
        }

        if (ImGui::BeginMenu(editor::icons::Label(editor::icons::Edit, "Edit").c_str())) {
            if (ImGui::MenuItem("Undo", "Ctrl+Z")) {
                context.undoRequested = true;
            }
            if (ImGui::MenuItem("Redo", "Ctrl+Y")) {
                context.redoRequested = true;
            }
            ImGui::Separator();
            if (ImGui::MenuItem("Duplicate", "Ctrl+D", false, context.scene && context.scene->SelectedObject())) {
                context.duplicateSelectedRequested = true;
            }
            if (ImGui::MenuItem("Merge to Single Mesh", nullptr, false,
                    context.scene && context.scene->SelectedIndices().size() >= 2)) {
                context.mergeSelectedRequested = true;
            }
            if (ImGui::MenuItem("Delete", "Del", false, context.scene && context.scene->SelectedObject())) {
                context.deleteSelectedRequested = true;
            }
            if (ImGui::MenuItem("Frame Selected", "F", false, context.scene && context.scene->SelectedObject())) {
                context.frameSelectedRequested = true;
            }
            ImGui::EndMenu();
        }

        if (ImGui::BeginMenu(editor::icons::Label(editor::icons::Add, "Add").c_str())) {
            if (ImGui::MenuItem("Create Object...", "Ctrl+Shift+A")) {
                g_creationPaletteOpenRequested = true;
            }
            if (ImGui::BeginMenu("Component", context.scene && context.scene->SelectedObject()
                    && !context.scene->SelectedObject()->navMeshBoundsVolume)) {
                DrawComponentMenuItems(context);
                ImGui::EndMenu();
            }
            ImGui::Separator();
            if (ImGui::MenuItem("Empty Object")) {
                context.addEmptyRequested = true;
                context.frameSelectedRequested = true;
            }
            if (ImGui::BeginMenu("Primitives")) {
                if (ImGui::MenuItem("Cube")) {
                    ResetPrimitiveCreator(EditorScene::Primitive::Cube);
                }
                if (ImGui::MenuItem("Plane")) {
                    ResetPrimitiveCreator(EditorScene::Primitive::Plane);
                }
                if (ImGui::MenuItem("Sphere")) {
                    ResetPrimitiveCreator(EditorScene::Primitive::Sphere);
                }
                if (ImGui::MenuItem("Capsule")) {
                    ResetPrimitiveCreator(EditorScene::Primitive::Capsule);
                }
                if (ImGui::MenuItem("Cylinder")) {
                    ResetPrimitiveCreator(EditorScene::Primitive::Cylinder);
                }
                if (ImGui::MenuItem("Cone")) {
                    ResetPrimitiveCreator(EditorScene::Primitive::Cone);
                }
                if (ImGui::MenuItem("Pyramid")) {
                    ResetPrimitiveCreator(EditorScene::Primitive::Pyramid);
                }
                if (ImGui::MenuItem("Torus")) {
                    ResetPrimitiveCreator(EditorScene::Primitive::Torus);
                }
                if (ImGui::MenuItem("Staircase")) {
                    ResetPrimitiveCreator(EditorScene::Primitive::Staircase);
                }
                ImGui::EndMenu();
            }
            if (ImGui::MenuItem("Foliage Actor")) {
                context.addFoliageRequested = true;
                context.frameSelectedRequested = true;
            }
            if (ImGui::BeginMenu("Water")) {
                if (ImGui::MenuItem("Lake")) {
                    context.addWaterRequested = true; context.addWaterPreset = 1;
                    context.frameSelectedRequested = true;
                }
                if (ImGui::MenuItem("Ocean")) {
                    context.addWaterRequested = true; context.addWaterPreset = 2;
                    context.frameSelectedRequested = true;
                }
                if (ImGui::MenuItem("River")) {
                    context.addWaterRequested = true; context.addWaterPreset = 3;
                    context.frameSelectedRequested = true;
                }
                ImGui::Separator();
                if (ImGui::MenuItem("Custom Water")) {
                    context.addWaterRequested = true; context.addWaterPreset = 0;
                    context.frameSelectedRequested = true;
                }
                ImGui::EndMenu();
            }
            if (ImGui::BeginMenu("Spline")) {
                if (ImGui::MenuItem("Path Spline")) {
                    context.addSplineRequested = true; context.addSplineType = 0;
                    context.frameSelectedRequested = true;
                }
                if (ImGui::MenuItem("River Spline")) {
                    context.addSplineRequested = true; context.addSplineType = 1;
                    context.frameSelectedRequested = true;
                }
                if (ImGui::MenuItem("Camera Rail")) {
                    context.addSplineRequested = true; context.addSplineType = 2;
                    context.frameSelectedRequested = true;
                }
                ImGui::EndMenu();
            }
            if (ImGui::BeginMenu("Physics")) {
                if (ImGui::MenuItem("Dynamic Cube")) {
                    context.addDynamicCubeRequested = true;
                }
                if (ImGui::MenuItem("Static Floor")) {
                    context.addStaticFloorRequested = true;
                }
                if (ImGui::MenuItem("Trigger Volume")) {
                    context.addTriggerVolumeRequested = true;
                }
                ImGui::EndMenu();
            }
            if (ImGui::BeginMenu("Navigation")) {
                if (ImGui::MenuItem("Nav Mesh Bounds Volume")) {
                    context.addNavMeshBoundsVolumeRequested = true;
                    context.frameSelectedRequested = true;
                }
                ImGui::EndMenu();
            }
            if (ImGui::BeginMenu("Gameplay")) {
                if (ImGui::MenuItem("Player Start")) {
                    context.addPlayerStartRequested = true;
                }
                if (ImGui::MenuItem("Door")) {
                    context.addDoorRequested = true;
                }
                if (ImGui::MenuItem("Pickup")) {
                    context.addPickupRequested = true;
                }
                if (ImGui::MenuItem("Damage Zone")) {
                    context.addDamageZoneRequested = true;
                }
                if (ImGui::MenuItem("Moving Platform")) {
                    context.addMovingPlatformRequested = true;
                }
                if (ImGui::MenuItem("Trigger Mover Test")) {
                    context.addTriggerMoverTestRequested = true;
                }
                ImGui::EndMenu();
            }
            if (ImGui::BeginMenu("Lights")) {
                if (ImGui::MenuItem("Directional Light")) {
                    context.addDirectionalLightRequested = true;
                }
                if (ImGui::MenuItem("Point Light")) {
                    context.addPointLightRequested = true;
                }
                if (ImGui::MenuItem("Spot Light")) {
                    context.addSpotLightRequested = true;
                }
                if (ImGui::MenuItem("Area Light")) {
                    context.addAreaLightRequested = true;
                }
                ImGui::EndMenu();
            }
            ImGui::EndMenu();
        }

        if (context.gizmo && ImGui::BeginMenu(editor::icons::Label(editor::icons::Edit, "Gizmo").c_str())) {
            if (ImGui::BeginMenu("Mode")) {
                const EditorGizmo::Mode mode = context.gizmo->CurrentMode();
                if (ImGui::MenuItem("Move", "W", mode == EditorGizmo::Mode::Translate)) {
                    context.gizmo->SetMode(EditorGizmo::Mode::Translate);
                }
                if (ImGui::MenuItem("Rotate", "E", mode == EditorGizmo::Mode::Rotate)) {
                    context.gizmo->SetMode(EditorGizmo::Mode::Rotate);
                }
                if (ImGui::MenuItem("Scale", "R", mode == EditorGizmo::Mode::Scale)) {
                    context.gizmo->SetMode(EditorGizmo::Mode::Scale);
                }
                if (ImGui::MenuItem("Uniform Scale", "G",
                        mode == EditorGizmo::Mode::Scale
                            && context.gizmo->CurrentAxis() == EditorGizmo::Axis::All)) {
                    context.gizmo->SetMode(EditorGizmo::Mode::Scale);
                    context.gizmo->SetAxis(EditorGizmo::Axis::All);
                }
                ImGui::EndMenu();
            }
            if (ImGui::BeginMenu("Axis")) {
                const EditorGizmo::Axis axis = context.gizmo->CurrentAxis();
                if (ImGui::MenuItem("X", "X", axis == EditorGizmo::Axis::X)) {
                    context.gizmo->SetAxis(EditorGizmo::Axis::X);
                }
                if (ImGui::MenuItem("Y", "Y", axis == EditorGizmo::Axis::Y)) {
                    context.gizmo->SetAxis(EditorGizmo::Axis::Y);
                }
                if (ImGui::MenuItem("Z", "Z", axis == EditorGizmo::Axis::Z)) {
                    context.gizmo->SetAxis(EditorGizmo::Axis::Z);
                }
                if (context.gizmo->CurrentMode() == EditorGizmo::Mode::Scale &&
                    ImGui::MenuItem("All (Uniform)", nullptr, axis == EditorGizmo::Axis::All)) {
                    context.gizmo->SetAxis(EditorGizmo::Axis::All);
                }
                ImGui::EndMenu();
            }
            if (ImGui::BeginMenu("Orientation")) {
                const EditorGizmo::Space space = context.gizmo->CurrentSpace();
                if (ImGui::MenuItem("World", nullptr, space == EditorGizmo::Space::World,
                        context.gizmo->CurrentMode() != EditorGizmo::Mode::Scale))
                    context.gizmo->SetSpace(EditorGizmo::Space::World);
                if (ImGui::MenuItem("Local", nullptr, space == EditorGizmo::Space::Local))
                    context.gizmo->SetSpace(EditorGizmo::Space::Local);
                ImGui::EndMenu();
            }
            bool snapping = context.gizmo->SnappingEnabled();
            if (ImGui::MenuItem("Snapping", nullptr, snapping))
                context.gizmo->SetSnappingEnabled(!snapping);
            ImGui::EndMenu();
        }

        if (ImGui::BeginMenu(editor::icons::Label(editor::icons::Settings, "Debug").c_str())) {
            if (ImGui::BeginMenu("Physics")) {
                if (context.showPhysicsEventGuides) {
                    ImGui::MenuItem("Show Play Event Lines", nullptr,
                        context.showPhysicsEventGuides);
                }
                if (ImGui::MenuItem("Clear Recent Event Lines")) {
                    context.clearPhysicsEventGuidesRequested = true;
                }
                if (!context.playMode) {
                    ImGui::Separator();
                    ImGui::TextDisabled("Event lines are drawn during Play mode.");
                }
                ImGui::EndMenu();
            }
            if (ImGui::BeginMenu("Navigation")) {
                if (context.showNavigationPreview) {
                    const bool shown = *context.showNavigationPreview;
                    if (ImGui::MenuItem("Show Walkable Areas", nullptr, shown)) {
                        *context.showNavigationPreview = !shown;
                        if (!shown) context.rebuildNavigationPreviewRequested = true;
                    }
                }
                if (ImGui::MenuItem("Rebuild Navigation")) {
                    context.rebuildNavigationPreviewRequested = true;
                }
                ImGui::Separator();
                ImGui::TextDisabled("%d walkable polygons", context.navigationPreviewPolygons);
                ImGui::EndMenu();
            }
            if (context.showGrid) {
                bool shown = *context.showGrid;
                if (ImGui::MenuItem("Grid & Axes", nullptr, shown)) {
                    *context.showGrid = !shown;
                }
            }
            if (context.previewAnimations) {
                bool on = *context.previewAnimations;
                if (ImGui::MenuItem("Animate Characters in Editor", nullptr, on)) {
                    *context.previewAnimations = !on;
                }
            }
            if (context.playFootIK) {
                bool on = *context.playFootIK;
                if (ImGui::MenuItem("Foot IK in Play (experimental)", nullptr, on)) {
                    *context.playFootIK = !on;
                }
                if (ImGui::IsItemHovered()) {
                    ImGui::SetTooltip("Grounds character feet on the surface during Play "
                                      "(raycasts the scene). Auto-detects leg bones by name.");
                }
            }
            if (context.showAiDebug) {
                bool shown = *context.showAiDebug;
                if (ImGui::MenuItem("AI Agent Debug", nullptr, shown)) {
                    *context.showAiDebug = !shown;
                }
            }
            if (ImGui::BeginMenu("Particles")) {
                if (context.showParticleDebug) {
                    ImGui::MenuItem("Show Guides", nullptr, context.showParticleDebug);
                }
                const bool enabled = !context.showParticleDebug || *context.showParticleDebug;
                ImGui::BeginDisabled(!enabled);
                if (context.particleDebugSelectedOnly) {
                    ImGui::MenuItem("Selected Only", nullptr, context.particleDebugSelectedOnly);
                }
                ImGui::Separator();
                if (context.particleDebugShapes) {
                    ImGui::MenuItem("Emitter Shapes", nullptr, context.particleDebugShapes);
                }
                if (context.particleDebugDirections) {
                    ImGui::MenuItem("Emission Directions", nullptr, context.particleDebugDirections);
                }
                if (context.particleDebugBounds) {
                    ImGui::MenuItem("Culling Bounds", nullptr, context.particleDebugBounds);
                }
                if (context.particleDebugCullingState) {
                    ImGui::MenuItem("Culling Status", nullptr, context.particleDebugCullingState);
                }
                ImGui::Separator();
                ImGui::TextColored(ImVec4(0.15f, 0.85f, 1.0f, 1.0f), "Cyan: culling enabled");
                ImGui::TextColored(ImVec4(0.72f, 0.32f, 0.92f, 1.0f), "Purple: culling disabled");
                ImGui::EndDisabled();
                ImGui::EndMenu();
            }
            ImGui::EndMenu();
        }

        if (ImGui::BeginMenu(editor::icons::Label(editor::icons::Layers, "Panels").c_str())) {
            if (editor::icons::MenuItem(editor::icons::Layers, "Show All")) {
                context.panels->ShowAll();
            }
            if (editor::icons::MenuItem(editor::icons::Stop, "Hide All")) {
                context.panels->HideAll();
            }
            if (editor::icons::MenuItem(editor::icons::Refresh, "Reset Defaults")) {
                context.panels->ResetDefaults();
            }
            ImGui::Separator();
            for (int groupIndex = 0;
                 groupIndex < static_cast<int>(EditorPanels::Group::Count); ++groupIndex) {
                const EditorPanels::Group group = static_cast<EditorPanels::Group>(groupIndex);
                if (ImGui::BeginMenu(EditorPanels::GroupName(group))) {
                    for (int panelIndex = 0;
                         panelIndex < static_cast<int>(EditorPanels::Panel::Count); ++panelIndex) {
                        const EditorPanels::Panel panel =
                            static_cast<EditorPanels::Panel>(panelIndex);
                        if (EditorPanels::GroupOf(panel) != group) continue;
                        const bool open = context.panels->IsOpen(panel);
                        if (ImGui::MenuItem(EditorPanels::Name(panel), nullptr, open)) {
                            context.panels->SetOpen(panel, !open);
                        }
                    }
                    ImGui::EndMenu();
                }
            }
            ImGui::EndMenu();
        }
        ImGui::EndMenuBar();
    }

    DrawCreationPalette(context);
    DrawPrimitiveCreator(context);

    for (int i = 0; i < static_cast<int>(EditorPanels::Panel::Count); ++i) {
        const EditorPanels::Panel panel = static_cast<EditorPanels::Panel>(i);
        bool open = context.panels->IsOpen(panel);
        if (!open) {
            continue;
        }

        switch (panel) {
        case EditorPanels::Panel::Hierarchy:
            DrawHierarchy(context, &open);
            break;
        case EditorPanels::Panel::Inspector:
            DrawInspector(context, &open);
            break;
        case EditorPanels::Panel::WorldSettings:
            if (context.scene) {
                DrawWorldSettings(*context.scene, context, &open);
            }
            break;
        case EditorPanels::Panel::GameModeSettings:
            if (context.scene) {
                DrawGameModeSettings(*context.scene, &open);
            }
            break;
        case EditorPanels::Panel::Assets:
            DrawAssets(context, &open);
            break;
        case EditorPanels::Panel::Console:
            DrawConsole(context, &open);
            break;
        case EditorPanels::Panel::ScriptApi:
            DrawScriptApiBrowser(context, &open);
            break;
        case EditorPanels::Panel::MaterialMaker:
            break;
        case EditorPanels::Panel::BehaviorGraph:
            break;   // drawn by EditorApp::DrawBehaviorGraphPanel (needs app-owned state)
        case EditorPanels::Panel::AudioEditor:
            DrawAudioEditor(context, &open);
            break;
        case EditorPanels::Panel::AudioMixer:
            DrawAudioMixer(context, &open);
            break;
        case EditorPanels::Panel::ParticleEditor:
            break; // drawn by EditorApp (owns the isolated preview renderer)
        case EditorPanels::Panel::ShaderEditor:
            break; // drawn by EditorApp (owns isolated shader preview resources)
        case EditorPanels::Panel::Hud:
            break; // drawn by EditorApp::DrawHudEditorPanel (owns the HUD document)
        case EditorPanels::Panel::CharacterEditor:
            break; // drawn by EditorApp (owns the reusable character asset)
        case EditorPanels::Panel::ClipEditor:
            break; // drawn by EditorApp (owns the clip preview renderer)
        case EditorPanels::Panel::GraphEditor:
            break; // drawn by EditorApp (owns the graph preview renderer)
        case EditorPanels::Panel::RuntimePropertyInspector:
            break; // drawn by EditorApp (requires the isolated Play registry)
        case EditorPanels::Panel::AssetDependencyViewer:
            break; // drawn by EditorApp (owns the project asset registry)
        case EditorPanels::Panel::WeatherEditor:
            break; // drawn by EditorApp (owns weather authoring and scene application)
        case EditorPanels::Panel::ProceduralBuilding:
            break; // drawn by EditorApp (owns procedural building generation)
        case EditorPanels::Panel::RoadGenerator:
            break; // drawn by EditorApp (owns spline road generation)
        case EditorPanels::Panel::LevelInstances:
            break; // drawn by EditorApp (owns linked streamed-level instances)
        case EditorPanels::Panel::WorldPartition:
            break; // drawn by EditorApp (owns world partition authoring)
        case EditorPanels::Panel::ProceduralScatterGraph:
            break; // drawn by EditorApp (owns deterministic scatter authoring and baking)
        case EditorPanels::Panel::BiomeEditor:
            break; // drawn by EditorApp (owns biome authoring and landscape application)
        case EditorPanels::Panel::DayNightTimeline:
            break; // drawn by EditorApp (owns environment timeline authoring and preview)
        case EditorPanels::Panel::CaveTunnel:
            break; // drawn by EditorApp (owns cave authoring and baked scene generation)
        case EditorPanels::Panel::MeshEditor:
            break; // drawn by EditorApp (owns native mesh editing state)
        case EditorPanels::Panel::DecalPlacement:
            break; // drawn by EditorApp (owns surface picking and placement)
        case EditorPanels::Panel::OptimizationAuditor:
            break; // drawn by EditorApp (owns on-demand scene analysis)
        case EditorPanels::Panel::LightingAnalysis:
            break; // drawn by EditorApp (owns lighting sampling and viewport overlays)
        case EditorPanels::Panel::ModularPlacement:
            break; // drawn by EditorApp (owns viewport placement interaction)
        case EditorPanels::Panel::PrefabPalette:
            break; // drawn by EditorApp (owns prefab browsing and placement)
        case EditorPanels::Panel::RoomBuilder:
            break; // drawn by EditorApp (owns procedural room generation)
        case EditorPanels::Panel::ScatterPaint:
            break; // drawn by EditorApp (owns surface scatter painting)
        case EditorPanels::Panel::ArrayTool:
            break; // drawn by EditorApp (owns smart duplication previews)
        case EditorPanels::Panel::Measurement:
            break; // drawn by EditorApp (owns editor-only measurements)
        case EditorPanels::Panel::LevelValidation:
            break; // drawn by EditorApp (owns scene validation and cleanup)
        case EditorPanels::Panel::LevelVariants:
            break; // drawn by EditorApp (owns persistent scene variants)
        case EditorPanels::Panel::LevelLayers:
            break; // drawn by EditorApp (owns scene organization)
        case EditorPanels::Panel::ViewportBookmarks:
            break; // drawn by EditorApp (owns editor camera navigation)
        case EditorPanels::Panel::Blockout:
            break; // drawn by EditorApp (owns blockout generation)
        case EditorPanels::Panel::Alignment:
            break; // drawn by EditorApp (owns batch transform operations)
        case EditorPanels::Panel::SplineBuilder:
            break; // drawn by EditorApp (owns spline construction)
        case EditorPanels::Panel::Viewport:
            break; // drawn by EditorApp::DrawViewportPanel (owns the scene FBO)
        case EditorPanels::Panel::Prefab:
            break; // drawn by EditorApp::DrawPrefabEditorPanel (owns the prefab asset)
        case EditorPanels::Panel::ScriptDebug:
            break; // drawn by EditorApp::DrawScriptDebugPanel (needs the play registry)
        case EditorPanels::Panel::WorldEditor:
            break; // drawn by EditorApp::DrawWorldEditorPanel (owns the world authoring state)
        case EditorPanels::Panel::TerrainCreator:
            break; // drawn by EditorApp (owns reusable terrain authoring state)
        case EditorPanels::Panel::RagdollPhysics:
            break; // drawn by EditorApp (owns ragdoll asset authoring state)
        case EditorPanels::Panel::AnimationRetargeting:
            break; // drawn by EditorApp (owns retarget profile authoring state)
        case EditorPanels::Panel::AbilityEditor:
            break; // drawn by EditorApp (owns ability asset authoring state)
        case EditorPanels::Panel::PhysicsStatus:
            DrawPhysicsStatus(context, &open);
            break;
        case EditorPanels::Panel::GameplayDebug:
            DrawGameplayDebug(context, &open);
            break;
        case EditorPanels::Panel::AnimationPreview:
            DrawAnimationPreview(context, &open);
            break;
        case EditorPanels::Panel::Gizmo:
            DrawGizmoToolbar(context, &open);
            break;
        case EditorPanels::Panel::CameraManager:
            DrawCameraManager(context, &open);
            break;
        case EditorPanels::Panel::Count:
            break;
        }

        context.panels->SetOpen(panel, open);
    }

    DrawStandaloneScriptEditor(context);
    DrawScriptBuildLog(context);
    DrawPackageSettings(context);

    ImGui::End();
    return true;
}

bool EditorDockspace::IsCompiledWithImGui() const {
    return true;
}
