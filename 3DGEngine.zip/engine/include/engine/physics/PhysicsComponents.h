#pragma once

#include <glm/glm.hpp>
#include <glm/gtc/quaternion.hpp>

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <string>
#include <vector>

namespace engine {
namespace ecs {

// Named collision channels used by editor presets and gameplay queries. Keeping
// these as bits preserves the existing layer/mask format while giving authors
// readable Unreal-style object channels instead of raw integers.
namespace CollisionLayer {
constexpr std::uint32_t Default       = 1u << 0;
constexpr std::uint32_t WorldStatic   = 1u << 1;
constexpr std::uint32_t WorldDynamic  = 1u << 2;
constexpr std::uint32_t Player        = 1u << 3;
constexpr std::uint32_t Enemy         = 1u << 4;
constexpr std::uint32_t Collectible   = 1u << 5;
constexpr std::uint32_t Projectile    = 1u << 6;
constexpr std::uint32_t CameraBlocker = 1u << 7;
constexpr std::uint32_t Trigger       = 1u << 8;
constexpr std::uint32_t All           = 0xFFFFFFFFu;

// Queries use their own response masks. Collectibles and trigger volumes can
// still emit overlap events, but never stop the character or retract the camera.
constexpr std::uint32_t CharacterBlockers = All & ~Collectible & ~Trigger;
constexpr std::uint32_t CameraBlockers =
    Default | WorldStatic | WorldDynamic | CameraBlocker;
} // namespace CollisionLayer

// A body that participates in dynamics. invMass = 0 means infinite mass (static
// or immovable). Velocity is integrated each fixed step; accumForce is applied
// then cleared. Surface material (bounciness, friction) lives on the Collider,
// not here -- a static floor has no RigidBody yet must still be bouncy/grippy.
//
// Sleeping: a body that stays nearly still for a while is put to sleep by the
// solver (skips integration + contact response) until a moving body touches it.
// This makes settled piles almost free and removes resting jitter.
struct RigidBody {
    glm::vec3 velocity{0.0f};
    glm::vec3 accumForce{0.0f};
    float     invMass    = 1.0f;
    bool      useGravity = true;

    // Kinematic: moved only by its own velocity (set by script/animation), never
    // by gravity, forces, or contacts -- but it DOES push dynamic bodies it hits
    // (infinite mass, but its velocity is felt at contacts). Use for moving
    // platforms, elevators, doors. It never sleeps while it has velocity.
    bool      kinematic  = false;

    bool      allowSleep = true;
    bool      sleeping   = false;   // solver-managed
    float     sleepTimer = 0.0f;    // solver-managed (seconds of stillness)

    // Velocity damping, applied every step (v *= 1/(1 + dt*damping)). Bleeds off
    // residual jitter left by the non-warm-started contact solver so resting bodies
    // actually settle and sleep; angular damping also stops slow rocking and lets
    // rolling spheres come to rest. Raise for floatier motion, set 0 to disable.
    float     linearDamping  = 0.05f;
    float     angularDamping = 0.6f;

    // Continuous collision: sweep this body's motion each step so it cannot
    // tunnel through thin geometry. Opt-in (costs an extra sweep) -- for bullets
    // and other fast movers. The moving body is approximated as a sphere.
    bool      ccd = false;

    // Angular dynamics. invInertiaLocal is the body-space inverse inertia tensor;
    // it is (re)computed from the collider's canonical scaled world dimensions whenever
    // massPropertiesDirty is set (unless freezeRotation locks the body against spinning).
    // Set massPropertiesDirty = true after changing mass, collider shape/dimensions, or
    // any transform/collider scale so the inertia is regenerated to match collision.
    // Orientation lives on the entity's Transform.rotation.
    glm::vec3 angularVelocity{0.0f};
    glm::vec3 accumTorque{0.0f};
    glm::mat3 invInertiaLocal{0.0f};        // body-space inverse inertia ABOUT THE COM
    bool      freezeRotation = false;
    bool      massPropertiesDirty = true;   // recompute inertia next step (default: on create)

    // Local center of mass, in the entity's local frame (Pass-3). The entity origin need not
    // be the physical COM -- required for asymmetric colliders, offset shapes, and compounds.
    // The body rotates about its COM and contact/impulse arms are measured from it. When
    // autoCenterOfMass is set it is derived from the collider (a single primitive's centre =
    // its localPosition); clear it to author an explicit COM. Default {0} keeps the COM at the
    // entity origin, so existing bodies are byte-for-byte unchanged.
    glm::vec3 centerOfMassLocal{0.0f};
    bool      autoCenterOfMass = true;

    // Mass source (Pass-4 Phase 55). Manual = invMass is authored directly (legacy behaviour,
    // the default so existing bodies are unchanged). Density = mass is derived from the
    // collider's material density * its scaled world volume whenever massPropertiesDirty is set,
    // so scaling a body or swapping its collider keeps a physically-plausible mass automatically.
    enum class MassMode { Manual, Density };
    MassMode  massMode = MassMode::Manual;

    void AddForce(const glm::vec3& f) { accumForce += f; }
    void AddTorque(const glm::vec3& tq) { accumTorque += tq; }
    // Apply a force at a world point (com = centre of mass): adds the torque too.
    void AddForceAtPoint(const glm::vec3& f, const glm::vec3& point, const glm::vec3& com) {
        accumForce  += f;
        accumTorque += glm::cross(point - com, f);
    }

    static RigidBody Static() { RigidBody b; b.invMass = 0.0f; b.useGravity = false; return b; }
    static RigidBody Dynamic(float mass) { RigidBody b; b.invMass = (mass > 0.0f) ? 1.0f / mass : 0.0f; return b; }

    // Inverse inertia tensors (body space, diagonal) for the primitive shapes.
    static glm::mat3 SolidBoxInvInertia(float mass, const glm::vec3& half) {
        if (mass <= 0.0f) return glm::mat3(0.0f);
        const float x = half.x * 2.0f, y = half.y * 2.0f, z = half.z * 2.0f;   // full extents
        const float ix = (mass / 12.0f) * (y * y + z * z);
        const float iy = (mass / 12.0f) * (x * x + z * z);
        const float iz = (mass / 12.0f) * (x * x + y * y);
        glm::mat3 m(0.0f);
        m[0][0] = 1.0f / ix; m[1][1] = 1.0f / iy; m[2][2] = 1.0f / iz;
        return m;
    }
    static glm::mat3 SolidSphereInvInertia(float mass, float radius) {
        if (mass <= 0.0f || radius <= 0.0f) return glm::mat3(0.0f);
        const float i = (2.0f / 5.0f) * mass * radius * radius;
        glm::mat3 m(0.0f);
        m[0][0] = m[1][1] = m[2][2] = 1.0f / i;
        return m;
    }
    // Capsule aligned with the local +Y axis: radius `r`, and `halfHeight` = the
    // half-length of the central segment (total tip-to-tip height is
    // 2*(halfHeight + r)). Approximated as a solid cylinder of the full height --
    // stable and cheap, exact enough for gameplay bodies.
    static glm::mat3 CapsuleInvInertia(float mass, float r, float halfHeight) {
        if (mass <= 0.0f || r <= 0.0f) return glm::mat3(0.0f);
        const float H  = 2.0f * (halfHeight + r);                  // full height
        const float iy = 0.5f * mass * r * r;                     // about the capsule axis
        const float ix = (mass / 12.0f) * (3.0f * r * r + H * H); // perpendicular
        glm::mat3 m(0.0f);
        m[0][0] = 1.0f / ix; m[1][1] = 1.0f / iy; m[2][2] = 1.0f / ix;
        return m;
    }
    // Solid cylinder aligned with local +Y. `halfHeight` excludes no caps: the
    // total flat-ended height is exactly 2 * halfHeight.
    static glm::mat3 CylinderInvInertia(float mass, float r, float halfHeight) {
        if (mass <= 0.0f || r <= 0.0f || halfHeight <= 0.0f) return glm::mat3(0.0f);
        const float h = 2.0f * halfHeight;
        const float iy = 0.5f * mass * r * r;
        const float ix = (mass / 12.0f) * (3.0f * r * r + h * h);
        glm::mat3 m(0.0f);
        m[0][0] = 1.0f / ix; m[1][1] = 1.0f / iy; m[2][2] = 1.0f / ix;
        return m;
    }
};

// How two colliders' material values (friction, restitution) combine at a contact (Pass-4
// Phase 57). GeometricMean (sqrt(a*b)) is the legacy default so existing scenes are unchanged.
enum class MaterialCombine { GeometricMean, Average, Minimum, Maximum, Multiply };

inline float CombineMaterial(float a, float b, MaterialCombine mode) {
    switch (mode) {
        case MaterialCombine::Average:  return 0.5f * (a + b);
        case MaterialCombine::Minimum:  return std::min(a, b);
        case MaterialCombine::Maximum:  return std::max(a, b);
        case MaterialCombine::Multiply: return a * b;
        case MaterialCombine::GeometricMean:
        default:                        return std::sqrt(std::max(a * b, 0.0f));
    }
}

enum class ColliderShape {
    Sphere,
    Plane,
    Box,
    Capsule,
    Cylinder,
    Cone,
    Pyramid,
    Torus,
    Staircase,
    // Appended to preserve the numeric values stored by older scenes.
    ConvexHull,
    TriangleMesh
};

// The collision shape attached to an entity (positioned by its Transform). A
// Plane is an infinite half-space defined in world space by a normal and offset
// (dot(normal, x) = offset), independent of the Transform position. Material is
// a surface property (so it lives here, like Box2D fixtures / PhysX shapes):
// restitution is bounciness (0 = dead, 1 = elastic); friction is the Coulomb
// coefficient. A contact combines the two colliders' values.
struct Collider {
    ColliderShape shape = ColliderShape::Sphere;
    float         radius = 0.5f;                  // Sphere
    glm::vec3     halfExtents{0.5f};              // Box
    glm::vec3     planeNormal{0.0f, 1.0f, 0.0f};  // Plane
    float         planeOffset = 0.0f;             // Plane
    float         halfHeight  = 0.5f;             // Capsule: half-length of the central segment
    float         majorRadius = 0.35f;            // Torus: centre to tube centre
    float         minorRadius = 0.15f;            // Torus: tube radius
    int           steps       = 6;                // Staircase: number of collision steps
    float         restitution = 0.0f;             // material: bounciness. Default 0 (non-bouncy),
                                                  // matching Unity/Unreal/Box2D/PhysX: a bouncy
                                                  // default makes stacked/dropped boxes scatter
                                                  // (restitution re-injects energy on every
                                                  // successive impact). Opt into bounce per body.
    float         friction    = 0.5f;             // material: Coulomb coefficient (legacy single value)
    bool          isTrigger   = false;            // overlap-only: detected but never resolved

    // Pass-4 material model. staticFriction/dynamicFriction default to 0, meaning "derive from the
    // legacy `friction` field" (static = friction, dynamic = 0.8*friction) so existing colliders
    // behave exactly as before. Set them (>0) to author a true stick/slip pair: static is the
    // higher coefficient that resists the onset of sliding, dynamic the lower one once sliding.
    // density (kg/m^3, ~1000 = water) feeds RigidBody::MassMode::Density. The combine modes select
    // how this collider's friction/restitution mix with the other collider's at a shared contact.
    float           staticFriction   = 0.0f;      // 0 => use `friction`
    float           dynamicFriction  = 0.0f;      // 0 => use 0.8 * `friction`
    float           density          = 1000.0f;   // kg/m^3, only used in Density mass mode
    MaterialCombine frictionCombine    = MaterialCombine::GeometricMean;
    MaterialCombine restitutionCombine = MaterialCombine::GeometricMean;

    // Optional PhysicsMaterial asset (.3dgphysmat). When set, the editor/runtime resolves it and
    // stamps its values onto the fields above; empty keeps the inline per-collider values.
    std::string     physicsMaterialPath;

    // Resolved static/dynamic coefficients honouring the legacy-derivation defaults above.
    float ResolvedStaticFriction()  const { return staticFriction  > 0.0f ? staticFriction  : friction; }
    float ResolvedDynamicFriction() const { return dynamicFriction > 0.0f ? dynamicFriction : 0.8f * friction; }

    // Shape-local transform. The owning entity transform is inherited first,
    // then this offset/orientation/scale is applied. Collision dimensions stay
    // in mesh-local units and are scaled exactly once when a world shape is built.
    glm::vec3 localPosition{0.0f};
    glm::quat localRotation{1.0f, 0.0f, 0.0f, 0.0f};
    glm::vec3 localScale{1.0f};
    bool inheritTransformScale = true;

    // Shared mesh-collision reference. Geometry is owned by the collision cache,
    // never copied into each Collider instance.
    std::string collisionAssetPath;
    bool collisionDirty = false;

    // Collision filtering: two colliders interact only if each one's mask
    // includes the other's layer bit -- (A.mask & B.layer) && (B.mask & A.layer).
    // Default: layer 0 (bit 1), collides with everything. Put the player, enemies,
    // props, projectiles, etc. on different layers and mask out the pairs you
    // don't want to test (cheaper broad phase + no unwanted contacts/triggers).
    std::uint32_t layer = CollisionLayer::Default; // this collider's object channel
    std::uint32_t mask  = CollisionLayer::All;     // channels this collider responds to

    static Collider MakeSphere(float r) { Collider c; c.shape = ColliderShape::Sphere; c.radius = r; return c; }
    static Collider MakePlane(const glm::vec3& n, float off) {
        Collider c; c.shape = ColliderShape::Plane; c.planeNormal = glm::normalize(n); c.planeOffset = off; return c;
    }
    static Collider MakeBox(const glm::vec3& he) { Collider c; c.shape = ColliderShape::Box; c.halfExtents = he; return c; }
    // Capsule along local +Y. `r` = radius, `halfHeight` = half-length of the
    // central segment (total height = 2*(halfHeight + r)). Convenience overload
    // takes the total height instead.
    static Collider MakeCapsule(float r, float halfHeight) {
        Collider c; c.shape = ColliderShape::Capsule; c.radius = r; c.halfHeight = halfHeight; return c;
    }
    static Collider MakeCapsuleFromHeight(float r, float totalHeight) {
        return MakeCapsule(r, std::max(0.0f, totalHeight * 0.5f - r));
    }
    static Collider MakeCylinder(float r, float totalHeight) {
        Collider c; c.shape = ColliderShape::Cylinder; c.radius = r;
        c.halfHeight = std::max(totalHeight * 0.5f, 0.0f);
        c.halfExtents = glm::vec3(r, c.halfHeight, r); return c;
    }
    static Collider MakeCone(float r, float totalHeight) {
        Collider c = MakeCylinder(r, totalHeight); c.shape = ColliderShape::Cone; return c;
    }
    static Collider MakePyramid(const glm::vec3& halfExtents) {
        Collider c = MakeBox(halfExtents); c.shape = ColliderShape::Pyramid; return c;
    }
    static Collider MakeTorus(float major, float minor) {
        Collider c; c.shape = ColliderShape::Torus;
        c.majorRadius = std::max(major, 0.0f); c.minorRadius = std::max(minor, 0.0f);
        const float outer = c.majorRadius + c.minorRadius;
        c.halfExtents = glm::vec3(outer, c.minorRadius, outer); return c;
    }
    static Collider MakeStaircase(const glm::vec3& halfExtents, int stepCount) {
        Collider c = MakeBox(halfExtents); c.shape = ColliderShape::Staircase;
        c.steps = std::max(stepCount, 1); return c;
    }
};

// Extra shapes owned by the same entity/rigid body as its primary Collider.
// Keeping the primary Collider component preserves compatibility with existing
// gameplay code while allowing imported meshes to use an authored compound fit.
struct AdditionalColliders {
    std::vector<Collider> values;
};

} // namespace ecs
} // namespace engine
